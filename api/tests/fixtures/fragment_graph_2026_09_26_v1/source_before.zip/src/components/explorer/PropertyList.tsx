import type { DisplayProperty } from '@/lib/types';

/** Shared node/edge presentation; preserves arrays, zero and false. */
export function PropertyList({ properties }: { properties: DisplayProperty[] }) {
  return <dl className="divide-y divide-border/60 rounded-lg border border-border/70 bg-secondary/20 font-sans text-sm overflow-hidden">
    {properties.map((item, index) => <div key={`${item.key}:${index}`} className="px-3 py-2.5 space-y-1">
      <dt className="text-xs font-semibold text-muted-foreground">{item.label}:</dt>
      <dd className="m-0 text-foreground leading-relaxed whitespace-pre-wrap [overflow-wrap:anywhere]">{typeof item.value === 'object' ? JSON.stringify(item.value, null, 2) : String(item.value)}</dd>
    </div>)}
  </dl>;
}
