<?php
require_once __DIR__ . '/ConversationEntities.php';
require_once __DIR__ . '/NodePropertyAnswer.php';

/** Conversational hints only. Every selected subject is resolved against the KG again. */
final class ConversationContext {
    public static function validate($state): array {
        if (!is_array($state) || ($state['version'] ?? null) !== 1) return ['version' => 1];
        $clean = ['version' => 1]; $subject = $state['subject'] ?? [];
        if (is_array($subject) && in_array($subject['type'] ?? '', ConversationEntities::TYPES, true) && is_string($subject['name'] ?? null) && is_string($subject['id'] ?? null)) {
            $node = EntityResolver::resolve($subject['type'], $subject['id'] ?? '');
            if ($node && vertex_label($node) === $subject['name']) $clean['subject'] = ['id' => $node['rid'], 'name' => vertex_label($node), 'type' => $node['@type']];
        }
        foreach (['last_question', 'pending_question'] as $key) if (isset($state[$key]) && is_string($state[$key])) $clean[$key] = mb_substr($state[$key], 0, 500);
        $clean['constraints'] = [];
        foreach (array_slice(is_array($state['constraints'] ?? null) ? $state['constraints'] : [], 0, 3) as $constraint) {
            if (!is_array($constraint)) continue;
            if (in_array($constraint['type'] ?? '', ConversationEntities::TYPES, true) && is_string($constraint['name'] ?? null)) {
                $node = EntityResolver::resolve($constraint['type'], $constraint['name']);
                if ($node) $clean['constraints'][] = ['name' => vertex_label($node), 'type' => $node['@type']];
            }
        }
        if (in_array($state['result_type'] ?? '', ConversationEntities::TYPES, true)) $clean['result_type'] = $state['result_type'];
        return $clean;
    }
    public static function prepare(string $question, array $history, $state): array {
        $state = self::validate($state);
        $matcher = new ConversationEntities(); $found = $matcher->find(NodePropertyAnswer::subjectQuestion($question));
        $followup = preg_match('/^(and\b|what about\b)|\b(it|its|this|that|they|them|these|those)\b/i', $question);
        if (!empty($state['subject']) && $followup && !$found['groups'] && !$found['unresolved']) {
            // Put the active subject last, so incidental names in previous answers cannot replace it.
            $history[] = ['role' => 'user', 'text' => $state['last_question'] ?? $state['subject']['name']];
            $history[] = ['role' => 'user', 'text' => str_replace('_', ' ', $state['subject']['type']) . ' ' . $state['subject']['name']];
        }
        if (isset($state['pending_question']) && $found['groups'] && !SemanticQuery::target($question)) {
            // Resolve an entity-only clarification against the previous requested intent.
            $pendingTarget = SemanticQuery::target($state['pending_question']);
            if ($pendingTarget && count($found['groups']) === 1) {
                $selected = ConversationEntities::select($found['groups'][0], $question);
                if ($selected) $question = 'Which ' . str_replace('_', ' ', $pendingTarget) . ' is associated with ' . str_replace('_', ' ', $selected['inferred_type']) . ' ' . $selected['name'] . '?';
            }
            $history[] = ['role' => 'user', 'text' => $state['pending_question']];
            if (!preg_match('/^(and|what about)\b/i', $question)) $question = 'What about ' . $question;
        }
        return [$question, array_slice($history, -20), $state, $found];
    }
    public static function finish(array $response, string $question, array $previous): array {
        $state = ['version' => 1]; $r = $response['routing'] ?? [];
        if (is_array($r) && isset($r['entity_type'], $r['entity']) && in_array($r['entity_type'], ConversationEntities::TYPES, true)) {
            $node = EntityResolver::resolve($r['entity_type'], $r['entity_id'] ?? $r['entity']);
            if ($node) {
                $state['subject'] = ['id' => $node['rid'], 'name' => vertex_label($node), 'type' => $node['@type']];
                // A self-contained routing question is stored, not answer prose.
                $label = vertex_label($node);
                $state['last_question'] = $question . (stripos($question, $label) === false ? ' for ' . $label : '');
                $state['constraints'] = $r['constraints'] ?? [];
                $state['result_type'] = $r['result_type'] ?? ($response['retrieval']['query_plan']['result_type'] ?? SemanticQuery::target($question));
            }
        } elseif (($response['status'] ?? '') === 'needs_clarification') {
            $state = $previous; $state['pending_question'] = $question;
        } elseif (in_array($response['status'] ?? '', ['unsupported', 'no_data'], true)) {
            $state = $previous;
        }
        return $state;
    }
}
