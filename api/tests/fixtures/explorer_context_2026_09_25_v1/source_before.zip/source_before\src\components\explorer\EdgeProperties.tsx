import type { DisplayProperty } from '@/lib/types';

export function EdgeProperties({ properties, phase }: { properties?: DisplayProperty[]; phase?: string | null }) {
  return <div className="space-y-1 text-xs break-words">
    {phase && <p><span className="font-medium">Treatment phase:</span> {phase}</p>}
    {properties?.map(item => <p key={item.key}><span className="font-medium">{item.label}:</span> {typeof item.value === 'object' ? JSON.stringify(item.value) : String(item.value)}</p>)}
  </div>;
}
