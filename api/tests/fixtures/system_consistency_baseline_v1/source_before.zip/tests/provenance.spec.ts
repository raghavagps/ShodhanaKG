﻿import { test, expect } from '@playwright/test';

test.describe('Provenance Subgraph Feature', () => {
  
  test.describe('API Endpoint', () => {
    test('should return provenance paths for disease', async ({ request }) => {
      const response = await request.get('/api/provenance-subgraph.php?diseaseId=36&limit=10');
      
      expect(response.ok()).toBeTruthy();
      
      const data = await response.json();
      expect(data.ok).toBe(true);
      expect(data.paths).toBeDefined();
      expect(data.meta).toBeDefined();
      expect(data.meta.totalPaths).toBeGreaterThanOrEqual(0);
      
      // Validate path structure if paths exist
      if (data.paths.length > 0) {
        const path = data.paths[0];
        expect(path.disease).toBeDefined();
        expect(path.edge1).toBeDefined();
        expect(path.therapy).toBeDefined();
        expect(path.edge2).toBeDefined();
        expect(path.formulation).toBeDefined();
        expect(path.provenance).toBeDefined();
        
        // Validate provenance
        expect(path.provenance.confidence).toBe('high');
        expect(path.edge1.pubmedId).toBe(path.edge2.pubmedId);
        expect(path.provenance.pubmedId).toBe(path.edge1.pubmedId);
      }
    });

    test('should filter by PubMed ID', async ({ request }) => {
      // First get all paths
      const allResponse = await request.get('/api/provenance-subgraph.php?diseaseId=36');
      const allData = await allResponse.json();
      
      if (allData.paths.length === 0) {
        test.skip('No provenance paths available');
        return;
      }
      
      const pubmedId = allData.meta.uniquePubmedIds[0];
      
      // Filter by specific PMID
      const filteredResponse = await request.get(
        `/api/provenance-subgraph.php?diseaseId=36&pubmedId=${pubmedId}`
      );
      
      expect(filteredResponse.ok()).toBeTruthy();
      
      const filteredData = await filteredResponse.json();
      expect(filteredData.paths.length).toBeLessThanOrEqual(allData.paths.length);
      
      // All returned paths should have the specified PMID
      filteredData.paths.forEach((path: unknown) => {
        expect(path.provenance.pubmedId).toBe(pubmedId);
      });
    });

    test('should return 404 for non-existent disease', async ({ request }) => {
      const response = await request.get('/api/provenance-subgraph.php?diseaseId=999999999');
      
      expect(response.status()).toBe(404);
      
      const data = await response.json();
      expect(data.ok).toBe(false);
      expect(data.error.code).toBe('disease_not_found');
    });

    test('should return 400 for missing diseaseId', async ({ request }) => {
      const response = await request.get('/api/provenance-subgraph.php');
      
      expect(response.status()).toBe(400);
      
      const data = await response.json();
      expect(data.ok).toBe(false);
      expect(data.error.code).toBe('missing_disease_id');
    });
  });

  test.describe('UI Integration', () => {
    test('should display provenance panel when disease selected', async ({ page }) => {
      // Navigate to disease graph view with a specific disease
      await page.goto('/explorer/disease/graph?node=36', { waitUntil: 'domcontentloaded' });
      await page.waitForTimeout(3000);
      
      // Wait for graph to load
      const canvas = page.locator('[data-testid="graph-canvas"], canvas').first();
      try {
        await canvas.waitFor({ state: 'visible', timeout: 10000 });
      } catch {
        test.skip('Graph canvas not available');
        return;
      }
      
      // Look for provenance panel or tab
      const provenanceTab = page.locator('button, [role="tab"]').filter({ hasText: /Provenance/i });
      
      if (await provenanceTab.isVisible().catch(() => false)) {
        await provenanceTab.click();
        await page.waitForTimeout(500);
        
        // Verify provenance panel content
        const panel = page.locator('[data-testid="provenance-panel"], .provenance-panel').first();
        if (await panel.isVisible().catch(() => false)) {
          // Should show path count
          const pathCount = page.locator('text=/\\d+ path/i');
          await expect(pathCount).toBeVisible();
        }
      }
    });

    test('should highlight provenance edges in graph', async ({ page }) => {
      await page.goto('/explorer/disease/graph?node=36', { waitUntil: 'domcontentloaded' });
      await page.waitForTimeout(3000);
      
      // This test verifies that the graph canvas receives provenance highlighting
      // The actual visual verification would require screenshot comparison
      // For now, we just verify the component mounts without errors
      
      const canvas = page.locator('canvas').first();
      try {
        await canvas.waitFor({ state: 'visible', timeout: 10000 });
        expect(await canvas.isVisible()).toBe(true);
      } catch {
        test.skip('Graph canvas not available');
      }
    });
  });

  test.describe('Provenance Data Validation', () => {
    test('all paths should have matching PMIDs', async ({ request }) => {
      const response = await request.get('/api/provenance-subgraph.php?diseaseId=36&limit=50');
      const data = await response.json();
      
      if (data.paths.length === 0) {
        test.skip('No paths to validate');
        return;
      }
      
      data.paths.forEach((path: unknown) => {
        // Both edges must share the same PMID
        expect(path.edge1.pubmedId).toBe(path.edge2.pubmedId);
        
        // Provenance metadata must match
        expect(path.provenance.pubmedId).toBe(path.edge1.pubmedId);
        
        // Confidence must be 'high'
        expect(path.provenance.confidence).toBe('high');
        
        // Node types must be correct
        expect(path.disease.type).toBe('Disease');
        expect(path.therapy.type).toBe('Therapy');
        expect(path.formulation.type).toBe('Formulation');
      });
    });

    test('should return unique PubMed IDs in meta', async ({ request }) => {
      const response = await request.get('/api/provenance-subgraph.php?diseaseId=36');
      const data = await response.json();
      
      if (data.paths.length === 0) {
        test.skip('No paths available');
        return;
      }
      
      const uniquePmids = new Set(data.paths.map((p: unknown) => p.provenance.pubmedId));
      expect(data.meta.uniquePubmedIds.length).toBe(uniquePmids.size);
      
      // All unique PMIDs should be strings
      data.meta.uniquePubmedIds.forEach((pmid: string) => {
        expect(typeof pmid).toBe('string');
        expect(pmid).toMatch(/^\\d+$/); // Should be numeric string
      });
    });
  });
});

