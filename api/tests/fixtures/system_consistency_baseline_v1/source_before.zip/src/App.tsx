import { lazy, Suspense, type ReactNode } from "react";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import { Toaster as Sonner } from "@/components/ui/sonner";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import { AppLayout } from "@/components/layout/AppLayout";
import { ColorblindProvider } from "@/hooks/useColorblind";
import { LanguageProvider } from "@/context/LanguageContext";
import Index from "./pages/Index.tsx";
import DiseaseExplorer from "./pages/explorers/DiseaseExplorer";
import DiseaseTableView from "./pages/explorers/DiseaseTableView";
import CompoundExplorer from "./pages/explorers/CompoundExplorer";
import CompoundTableView from "./pages/explorers/CompoundTableView";
import IntegratedExplorer from "./pages/explorers/IntegratedExplorer";
import IntegratedTableView from "./pages/explorers/IntegratedTableView";
import SearchResults from "./pages/SearchResults.tsx";
import NotFound from "./pages/NotFound.tsx";
import TestProvenance from "./pages/TestProvenance.tsx";
import ApiTester from "./pages/ApiTester.tsx";
import FAQ from "./pages/FAQ.tsx";
import HowToUse from "./pages/HowToUse.tsx";
import Contact from "./pages/Contact.tsx";
import Team from "./pages/Team.tsx";

const queryClient = new QueryClient();
const DiseaseGraphView = lazy(() => import("./pages/explorers/DiseaseGraphView"));
const CompoundGraphView = lazy(() => import("./pages/explorers/CompoundGraphView"));
const IntegratedGraphView = lazy(() => import("./pages/explorers/IntegratedGraphView"));

const RouteFallback = () => (
  <div className="container py-10 text-sm text-muted-foreground">Loading explorer…</div>
);

const lazyRoute = (node: ReactNode) => (
  <Suspense fallback={<RouteFallback />}>{node}</Suspense>
);

const App = () => (
  <QueryClientProvider client={queryClient}>
    <LanguageProvider>
      <ColorblindProvider>
        <TooltipProvider>
          <Toaster />
          <Sonner />
          <BrowserRouter basename={import.meta.env.BASE_URL}>
            <Routes>
              <Route element={<AppLayout />}>
                <Route path="/" element={<Index />} />
                <Route path="/explorer/disease" element={<DiseaseExplorer />} />
                <Route path="/explorer/disease/graph" element={lazyRoute(<DiseaseGraphView />)} />
                <Route path="/explorer/disease/table" element={<DiseaseTableView />} />
                <Route path="/explorer/compound" element={<CompoundExplorer />} />
                <Route path="/explorer/compound/graph" element={lazyRoute(<CompoundGraphView />)} />
                <Route path="/explorer/compound/table" element={<CompoundTableView />} />
                <Route path="/explorer/integrated" element={<IntegratedExplorer />} />
                <Route path="/explorer/integrated/graph" element={lazyRoute(<IntegratedGraphView />)} />
                <Route path="/explorer/integrated/table" element={<IntegratedTableView />} />
                <Route path="/search" element={<SearchResults />} />
                <Route path="/test-provenance" element={<TestProvenance />} />
                <Route path="/api-tester" element={<ApiTester />} />
                <Route path="/faq" element={<FAQ />} />
                <Route path="/how-to-use" element={<HowToUse />} />
                <Route path="/contact" element={<Contact />} />
                <Route path="/team" element={<Team />} />
              </Route>
              <Route path="*" element={<NotFound />} />
            </Routes>
          </BrowserRouter>
        </TooltipProvider>
      </ColorblindProvider>
    </LanguageProvider>
  </QueryClientProvider>
);

export default App;
