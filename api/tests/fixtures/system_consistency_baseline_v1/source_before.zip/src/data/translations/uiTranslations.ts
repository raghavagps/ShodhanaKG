export const uiTranslations = {
  // Navigation Links
  home: { en: "Home", hi: "मुख्य पृष्ठ" },
  explorer: { en: "Explorer", hi: "अन्वेषक" },
  knowledgeGraph: { en: "Knowledge Graph", hi: "ज्ञान आलेख" },
  help: { en: "Help", hi: "सहायता" },
  aboutUs: { en: "About Us", hi: "हमारे बारे में" },
  
  // Explorer Choices
  diseaseExplorer: { en: "Disease Explorer", hi: "रोग अन्वेषक" },
  compoundExplorer: { en: "Compound Explorer", hi: "द्रव्य अन्वेषक" },
  integratedExplorer: { en: "Integrated Explorer", hi: "एकीकृत अन्वेषक" },
  
  // Graph Choices
  diseaseGraph: { en: "Disease Graph", hi: "रोग आलेख" },
  compoundGraph: { en: "Compound Graph", hi: "द्रव्य आलेख" },
  integratedGraph: { en: "Integrated Graph", hi: "एकीकृत आलेख" },
  
  // Extra options
  faqs: { en: "FAQs", hi: "अक्सर पूछे जाने वाले प्रश्न" },
  howToUse: { en: "How to Use", hi: "उपयोग विधि" },
  developers: { en: "Developers", hi: "विकासकर्ता" },
  contact: { en: "Contact", hi: "सम्पर्क करें" },
  colorblindOn: { en: "Colorblind ON", hi: "वर्णान्धता सक्रिय" },
  colorblindMode: { en: "Colorblind Mode", hi: "वर्णान्धता मोड" },
  graphView: { en: "Graph View", hi: "आलेख दृश्य" },
  tableView: { en: "Table View", hi: "तालिका दृश्य" },

  // Disclaimer
  disclaimerTitle: { en: "Disclaimer:", hi: "अस्वीकरण:" },
  disclaimerText: { en: "This platform is strictly for academic and research purposes only. For medical advice and diagnosis, please consult a professional.", hi: "यह मंच केवल शैक्षणिक और अनुसंधान उद्देश्यों के लिए है। चिकित्सा सलाह और निदान के लिए, कृपया एक पेशेवर चिकित्सक से परामर्श लें।" },

  // Hero Section
  ayurvedicBiomedicalKg: { en: "Integrative Ayurvedic purification knowledge graph", hi: "आयुर्वेदिक बायोमेडिकल ज्ञान आलेख" },
  whereClassicalMeetsModern: { en: "Where classical purification meets modern evidence — explore diseases, compounds and the pathways that connect them.", hi: "जहाँ शास्त्रीय शोधन आधुनिक साक्ष्यों से मिलता है — रोगों, द्रव्यों और उन्हें जोड़ने वाले मार्गों का अन्वेषण करें।" },
  
  // Search Bar
  searchPlaceholder: { en: "Search diseases, compounds, formulations...", hi: "रोग, यौगिक, योग खोजें..." },
  searchButton: { en: "Search", hi: "खोजें" },
  trySearching: { en: "Try searching:", hi: "खोजने का प्रयास करें:" },

  // Stats Card labels
  totalNodes: { en: "Total Nodes", hi: "कुल नोड्स" },
  totalRelations: { en: "Total Relations", hi: "कुल संबंध" },
  totalStudies: { en: "Total Studies", hi: "कुल अध्ययन" },
  nodesDescription: { en: "Vertices across all knowledge domains", hi: "सभी ज्ञान क्षेत्रों में फैले हुए नोड्स" },
  relationsDescription: { en: "Edges connecting entities in the graph", hi: "आलेख में संस्थाओं को जोड़ने वाले संबंध" },
  studiesDescription: { en: "Evidence-backed relationships with source references", hi: "स्रोतों के साथ साक्ष्य-समर्थित संबंध" },

  // Explorer Selection
  chooseModeHeader: { en: "Select Your Exploration Mode", hi: "अपना अन्वेषण मार्ग चुनें" },
  chooseModeSubtitle: { en: "Choose a domain path below to start visualizing classical Ayurvedic pathways, clinical evidence, and molecular properties.", hi: "शास्त्रीय आयुर्वेदिक मार्गों, नैदानिक साक्ष्यों और आणविक गुणों की कल्पना शुरू करने के लिए नीचे एक डोमेन मार्ग चुनें।" },
  
  // Explorer Cards Prompts
  diseaseCardPrompt: { en: "Do you want to start with a clinical condition or Ayurvedic diagnosis?", hi: "क्या आप नैदानिक स्थिति या आयुर्वेदिक निदान से शुरुआत करना चाहते हैं?" },
  compoundCardPrompt: { en: "Do you want to trace toxic substances, purification methods, and safe compounds?", hi: "क्या आप विषाक्त पदार्थों, शोधन विधियों और सुरक्षित द्रव्यों का पता लगाना चाहते हैं?" },
  integratedCardPrompt: { en: "Do you want to bridge clinical diseases and molecular chemical pathways?", hi: "क्या आप नैदानिक रोगों और आणविक रासायनिक मार्गों को जोड़ना चाहते हैं?" },

  // Card Navigation action
  openMode: { en: "Open mode", hi: "मोड खोलें" },
  openDisease: { en: "Open Disease mode", hi: "रोग मोड खोलें" },
  openCompound: { en: "Open Compound mode", hi: "द्रव्य मोड खोलें" },
  openIntegrated: { en: "Open Integrated mode", hi: "एकीकृत मोड खोलें" },

  // Autocomplete
  searchingSuggestions: { en: "Searching suggestions...", hi: "सुझाव खोजे जा रहे हैं..." },

  // Details Panel
  nothingSelected: { en: "Nothing selected", hi: "कुछ भी चयनित नहीं है" },
  inspectProperties: { en: "Click a node or edge in the graph to inspect its properties and source evidence.", hi: "ग्राफ में किसी नोड या किनारे पर क्लिक करके उसके गुणों और साक्ष्य-समर्थित संदर्भों को देखें।" },
  properties: { en: "Properties", hi: "विशेषताएं / गुण" },
  node: { en: "Node", hi: "नोड" },
  relationship: { en: "Relationship", hi: "संबंध" },

  // Graph Views side panels and buttons
  filters: { en: "Filters", hi: "फ़िल्टर" },
  reset: { en: "Reset", hi: "रीसेट" },
  selectedFilters: { en: "Selected filters", hi: "चयनित फ़िल्टर" },
  noFiltersSelected: { en: "No filters selected yet.", hi: "अभी तक कोई फ़िल्टर चयनित नहीं है।" },
  nodeVisibility: { en: "Node visibility", hi: "नोड दृश्यता" },
  all: { en: "All", hi: "सभी" },
  none: { en: "None", hi: "कोई नहीं" },
  focusGraph: { en: "Focus graph", hi: "पूर्ण स्क्रीन आलेख" },
  exitFocus: { en: "Exit focus", hi: "सामान्य स्क्रीन" },
  export: { en: "Export", hi: "निर्यात करें" },
  startExploringGraph: { en: "Start exploring the graph", hi: "अन्वेषण शुरू करें" },
  pickAnEntity: { en: "Pick a disease, symptom, or any entity from the left panel to load its connected subgraph here.", hi: "कनेक्टेड सबग्राफ लोड करने के लिए बाएं पैनल से किसी रोग, लक्षण या किसी संस्था को चुनें।" },
  provenance: { en: "Provenance", hi: "उत्पत्ति साक्ष्य" },
  browseByCategory: { en: "Browse by category", hi: "श्रेणी के अनुसार ब्राउज़ करें" },
  browseCategoryBlurb: { en: "Open any category to view its table with relationship & connection statistics.", hi: "संबंध और कनेक्शन आंकड़ों के साथ इसकी तालिका देखने के लिए किसी भी श्रेणी को खोलें।" },
  entries: { en: "entries", hi: "प्रविष्टियां" },
  opensTable: { en: "Opens table · relationships", hi: "तालिका खोलता है · संबंध" },

  // Table view — loading / error states
  loading: { en: "Loading...", hi: "लोड हो रहा है..." },
  failedToLoad: { en: "Failed to load data", hi: "डेटा लोड नहीं हो सका" },
  translating: { en: "Translating...", hi: "अनुवाद हो रहा है..." },

  // Table view — row actions
  openGraph: { en: "Open graph", hi: "आलेख खोलें" },
  openingGraph: { en: "Opening graph filtered to", hi: "आलेख खोला जा रहा है:" },

  // Table view — pagination
  previous: { en: "Previous", hi: "पिछला" },
  next: { en: "Next", hi: "अगला" },
  pageOf: { en: "Page {n} of {total}", hi: "पृष्ठ {n} / {total}" },
  showing: { en: "Showing {from}–{to} of {total}", hi: "{from}–{to} में से {total} दिखाए जा रहे हैं" },
  countsFooter: { en: "Counts reflect direct relationships in the current knowledge graph.", hi: "गिनती वर्तमान ज्ञान आलेख में प्रत्यक्ष संबंधों को दर्शाती है।" },
  noResults: { en: "No {category}s match \"{query}\".", hi: "कोई {category} \"{query}\" से मेल नहीं खाता।" },

  // Table view — column headers (disease)
  colSymptoms: { en: "Symptoms", hi: "लक्षण" },
  colAyurvedicDiagnosis: { en: "Ayurvedic Diagnosis", hi: "आयुर्वेदिक निदान" },
  colDoshas: { en: "Doshas", hi: "दोष" },
  colTherapy: { en: "Therapy", hi: "चिकित्सा" },
  colAssessmentParameters: { en: "Assessment Parameter", hi: "आकलन मापदंड" },
  colLinkedDiseases: { en: "Linked Diseases", hi: "संबंधित रोग" },
  colFormulations: { en: "Formulations", hi: "योग" },
  colTherapies: { en: "Therapies", hi: "चिकित्साएं" },

  // Table view — column headers (compound)
  colShodhanaMethod: { en: "Shodhana Method", hi: "शोधन विधि" },
  colToxicSubstance: { en: "Toxic Substance", hi: "विषाक्त द्रव्य" },
  colPurifiedCompound: { en: "Purified Compound", hi: "शोधित द्रव्य" },
  colMedia: { en: "Media", hi: "माध्यम" },
  colProcess: { en: "Process", hi: "प्रक्रिया" },
  colShodhanaType: { en: "Shodhana Type", hi: "शोधन प्रकार" },

  // Table view — column headers (integrated)
  colPurifiedCompoundName: { en: "Purified Compound", hi: "शोधित द्रव्य" },
  colDiseases: { en: "Diseases", hi: "रोग" },
  colStudies: { en: "Studies", hi: "अध्ययन" },

  // Search hint
  searchEnglishHint: { en: "", hi: "खोज अंग्रेज़ी में करें (जैसे: Vatsanabha, Amavata)" }
} as const;

export type TranslationKey = keyof typeof uiTranslations;
