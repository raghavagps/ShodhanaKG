import { afterEach, describe, expect, it, vi } from 'vitest';
import { fetchChatStream } from './chatApi';
import { ReadableStream } from 'node:stream/web';
import { TextEncoder, TextDecoder } from 'node:util';

afterEach(() => vi.unstubAllGlobals());

function mockStream(text: string, type = 'text/event-stream') {
  vi.stubGlobal('TextDecoder', TextDecoder);
  const bytes = new TextEncoder().encode(text);
  const body = new ReadableStream({
    start(controller) {
      // Every byte is a separate chunk, including split UTF-8 and CRLF boundaries.
      for (const byte of bytes) controller.enqueue(new Uint8Array([byte]));
      controller.close();
    },
  });
  vi.stubGlobal('fetch', vi.fn().mockResolvedValue({ ok: true, headers: new Headers({ 'content-type': type }), body }));
}

describe('chatbot transport', () => {
  it('retains authoritative structured answers and citation maps in the final event', async () => {
    const presentation = { status: 'success', answer: 'Recorded association. [1]', answer_intro: 'Available information', answer_blocks: [{ text: 'Recorded association.', citation_ids: ['1'] }], citations: [{ id: '1', record_indices: [0], statement: 'Recorded association.' }] };
    mockStream(`event: done\ndata: ${JSON.stringify(presentation)}\n\n`);
    const result = await fetchChatStream('q', [], '', vi.fn(), vi.fn());
    expect(result.answer_blocks).toEqual(presentation.answer_blocks);
    expect(result.citations).toEqual(presentation.citations);
    expect(result.answer).toBe(presentation.answer);
  });
  it('preserves complete evidence context and replaces rejected text with final fallback', async () => {
    const context = { status: 'success', question: 'q', routing: { endpoint: 'provenance_compound_method_media' }, retrieval: { results: [{ nodes: [{ label: 'ताम्र' }] }] } };
    mockStream(`event: context\r\ndata: ${JSON.stringify(context)}\r\n\r\ndata: {"chunk":"ताम्र unsupported claim"}\r\n\r\nevent: done\r\ndata: {"status":"grounding_error","answer":"Unsupported answer withheld."}`);
    const onContext = vi.fn();
    const tokens = vi.fn();
    const result = await fetchChatStream('q', [], '', tokens, onContext);
    expect(onContext).toHaveBeenCalledWith(context);
    expect(tokens).toHaveBeenCalledWith('ताम्र unsupported claim');
    expect(result.status).toBe('grounding_error');
    expect(result.answer).toBe('Unsupported answer withheld.');
  });

  it('preserves no-correlated-evidence reason', async () => {
    mockStream('event: context\ndata: {"status":"no_data","reason":"no_correlated_evidence","retrieval":{"results":[]}}\n\nevent: done\ndata: {"status":"no_data","answer":"No correlated evidence."}\n\n');
    const result = await fetchChatStream('q', [], '', vi.fn(), vi.fn());
    expect(result.context?.reason).toBe('no_correlated_evidence');
    expect(result.status).toBe('no_data');
  });

  it('accepts JSON FAQ responses from older backends', async () => {
    const payload = { status: 'success', answer: 'FAQ answer' };
    vi.stubGlobal('fetch', vi.fn().mockResolvedValue({ ok: true, headers: new Headers({ 'content-type': 'application/json' }), json: async () => payload }));
    expect((await fetchChatStream('q', [], '', vi.fn(), vi.fn())).answer).toBe('FAQ answer');
  });

  it('rejects an interrupted stream instead of treating partial text as a completed answer', async () => {
    mockStream('data: {"chunk":"partial"}\n\n');
    await expect(fetchChatStream('q', [], '', vi.fn(), vi.fn())).rejects.toThrow('before completion');
  });

  it('rejects an HTML gateway response', async () => {
    mockStream('<html>Gateway error</html>', 'text/html');
    await expect(fetchChatStream('q', [], '', vi.fn(), vi.fn())).rejects.toThrow('format');
  });
});
