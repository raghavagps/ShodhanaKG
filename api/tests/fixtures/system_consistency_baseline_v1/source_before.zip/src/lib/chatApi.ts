﻿import { ChatbotBackendResponse, ChatHistoryTurn, OrchestratorContext } from "./types";

export const API_BASE = import.meta.env.VITE_API_BASE || "";

export async function fetchChatResponse(question: string, history: ChatHistoryTurn[] = [], conversation_id: string = ''): Promise<ChatbotBackendResponse> {
  try {
    const response = await fetch(`${API_BASE}/api/chatbot_response.php`, {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({ question, history, conversation_id }),
    });

    if (!response.ok) {
      return {
        question,
        answer: "Failed to connect to the ShodhanaKG backend.",
        status: "network_error"
      };
    }

    const contentType = response.headers.get("content-type") ?? "";
    if (!contentType.includes("application/json")) {
      return {
        question,
        answer: "The server timed out or is unavailable. Please try again.",
        status: "network_error"
      };
    }

    const data: ChatbotBackendResponse = await response.json();
    
    if (!data.status) {
       return {
        question,
        answer: "Received an invalid response format from the server.",
        status: "network_error"
      };
    }
    
    return data;
  } catch (err: unknown) {
    return {
      question,
      answer: err instanceof Error && err.message 
        ? `Network error: ${err.message}` 
        : "A network error occurred while connecting to ShodhanaKG.",
      status: "network_error"
    };
  }
}

export async function checkChatHealth(): Promise<boolean> {
  try {
    const res = await fetch(`${API_BASE}/api/chatbot_health.php`);
    if (res.ok) {
      const data = await res.json();
      return data.ok === true;
    }
    return false;
  } catch (e) {
    return false;
  }
}
export async function fetchChatStream(
  question: string,
  history: ChatHistoryTurn[] = [],
  conversation_id: string = '',
  onToken: (chunk: string) => void,
  onContext: (context: OrchestratorContext) => void
): Promise<ChatbotBackendResponse> {
  const response = await fetch(`${API_BASE}/api/chatbot_response.php`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ question, history, conversation_id, stream: true }),
  });
  if (!response.ok) throw new Error("Failed to connect to the ShodhanaKG backend.");
  const contentType = response.headers.get("content-type") || "";
  // Compatibility with JSON-only servers and early validation responses.
  if (contentType.includes("application/json")) {
    const result: ChatbotBackendResponse = await response.json();
    if (!result.status) throw new Error("Invalid chatbot response");
    if (result.context) onContext(result.context);
    const answer = result.answer || result.message || "";
    onToken(answer);
    return { ...result, question, answer };
  }
  if (!contentType.includes("text/event-stream")) throw new Error("Unexpected chatbot response format");
  const reader = response.body?.getReader();
  if (!reader) throw new Error("Stream not supported");
  const decoder = new TextDecoder();
  let buffer = "";
  let answer = "";
  let status: ChatbotBackendResponse["status"] = "error";
  let context: OrchestratorContext | undefined;
  let completed = false;
  let presentation: Partial<ChatbotBackendResponse> = {};
  const consume = (frame: string) => {
    let event = "message";
    const lines: string[] = [];
    for (const line of frame.split(/\r?\n/)) {
      if (line.startsWith("event:")) event = line.slice(6).trim();
      if (line.startsWith("data:")) lines.push(line.slice(5).trimStart());
    }
    if (!lines.length) return;
    const payload = JSON.parse(lines.join("\n"));
    if (event === "context" && payload) {
      // Previous deployments emitted retrieval alone.
      context = "retrieval" in payload || "routing" in payload || "reason" in payload
        ? payload : { status: payload.status || "success", question, retrieval: payload };
      onContext(context!);
    } else if (event === "message" && typeof payload.chunk === "string") {
      answer += payload.chunk;
      onToken(payload.chunk);
    } else if (event === "done") {
      if (!payload.status) throw new Error("Missing final chatbot status");
      status = payload.status;
      if (typeof payload.answer === "string") answer = payload.answer;
      presentation = { answer_intro: payload.answer_intro, answer_heading: payload.answer_heading, answer_results: payload.answer_results, answer_blocks: payload.answer_blocks, citations: payload.citations, generation: payload.generation };
      completed = true;
    }
  };
  try {
    while (true) {
      const { value, done } = await reader.read();
      buffer += done ? decoder.decode() : decoder.decode(value, { stream: true });
      let boundary: RegExpExecArray | null;
      while ((boundary = /\r?\n\r?\n/.exec(buffer))) {
        consume(buffer.slice(0, boundary.index));
        buffer = buffer.slice(boundary.index + boundary[0].length);
      }
      if (done) break;
    }
    if (buffer.trim()) consume(buffer);
    if (!completed) throw new Error("Chatbot stream ended before completion");
    return { ...presentation, question, answer, status, context };
  } finally {
    reader.releaseLock();
  }
}
