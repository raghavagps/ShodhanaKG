/**
 * translationService.ts
 *
 * 3-tier translation pipeline for Hindi (en → hi):
 *   Tier 1 — glossary.ts  (instant, no network, covers known Ayurvedic terms)
 *   Tier 2 — SessionStorage cache  (instant after first translation in a tab)
 *   Tier 3 — MyMemory REST API  (free, no key required, parallel batch calls)
 *   Tier 4 — Fallback: return original English text if API fails
 */

import { glossaryTranslations } from "@/data/translations/glossary";

const MYMEMORY_URL = "https://api.mymemory.translated.net/get";
const SESSION_PREFIX = "tl_hi_";
const PARALLEL_BATCH = 8; // concurrent MyMemory requests per flush

// ─── Internal helpers ────────────────────────────────────────────────────────

function glossaryLookup(text: string): string | null {
  if (!text) return null;
  return (
    glossaryTranslations[text] ??
    glossaryTranslations[text.trim()] ??
    null
  );
}

function sessionGet(text: string): string | null {
  try {
    return sessionStorage.getItem(SESSION_PREFIX + text);
  } catch {
    return null;
  }
}

function sessionSet(text: string, translated: string): void {
  try {
    sessionStorage.setItem(SESSION_PREFIX + text, translated);
  } catch {
    // ignore quota errors
  }
}

async function callMyMemory(text: string): Promise<string> {
  const params = new URLSearchParams({ q: text, langpair: "en|hi" });
  const res = await fetch(`${MYMEMORY_URL}?${params.toString()}`);
  if (!res.ok) throw new Error(`MyMemory ${res.status}`);
  const data = await res.json();
  const translated: string = data?.responseData?.translatedText;
  if (!translated || translated === "NO QUERY SPECIFIED") return text;
  return translated;
}

// ─── TranslationService ───────────────────────────────────────────────────────

class TranslationService {
  /** In-memory hot cache — avoids sessionStorage reads on repeat calls */
  private memCache = new Map<string, string>();
  /** In-flight dedup map — prevents identical concurrent API calls */
  private pending = new Map<string, Promise<string>>();

  /**
   * Translate a single string en → hi.
   * Skips API for empty strings, numbers, IDs, and glossary-covered terms.
   */
  async translate(text: string): Promise<string> {
    if (!text || !text.trim()) return text;

    // Skip strings that are numbers, IDs, or very short codes
    if (/^[\d\s.,:;/-]+$/.test(text.trim())) return text;

    // Tier 1: glossary
    const g = glossaryLookup(text);
    if (g) return g;

    // Tier 2: in-memory cache
    if (this.memCache.has(text)) return this.memCache.get(text)!;

    // Tier 2b: session storage
    const cached = sessionGet(text);
    if (cached !== null) {
      this.memCache.set(text, cached);
      return cached;
    }

    // Tier 3: API — dedup in-flight identical calls
    if (this.pending.has(text)) return this.pending.get(text)!;

    const promise = callMyMemory(text)
      .then((translated) => {
        this.memCache.set(text, translated);
        sessionSet(text, translated);
        this.pending.delete(text);
        return translated;
      })
      .catch(() => {
        this.pending.delete(text);
        return text; // Tier 4: fallback
      });

    this.pending.set(text, promise);
    return promise;
  }

  /**
   * Translate a batch of strings efficiently.
   * - Deduplicates identical strings before calling the API
   * - Runs PARALLEL_BATCH concurrent requests at a time
   * - Returns results in the same order as input
   */
  async translateBatch(texts: string[]): Promise<string[]> {
    if (texts.length === 0) return [];

    // Collect unique strings that actually need an API call
    const uniqueNeedingApi: string[] = [];
    const quickResults = new Map<string, string>();

    for (const text of texts) {
      if (quickResults.has(text)) continue; // already resolved this string

      if (!text || !text.trim() || /^[\d\s.,:;/-]+$/.test(text.trim())) {
        quickResults.set(text, text);
        continue;
      }

      const g = glossaryLookup(text);
      if (g) { quickResults.set(text, g); continue; }

      if (this.memCache.has(text)) {
        quickResults.set(text, this.memCache.get(text)!);
        continue;
      }

      const cached = sessionGet(text);
      if (cached !== null) {
        this.memCache.set(text, cached);
        quickResults.set(text, cached);
        continue;
      }

      uniqueNeedingApi.push(text);
    }

    // Process API calls in parallel batches
    for (let i = 0; i < uniqueNeedingApi.length; i += PARALLEL_BATCH) {
      const batch = uniqueNeedingApi.slice(i, i + PARALLEL_BATCH);
      const results = await Promise.all(batch.map((t) => this.translate(t)));
      batch.forEach((t, idx) => quickResults.set(t, results[idx]));
    }

    return texts.map((t) => quickResults.get(t) ?? t);
  }

  /** Clear all caches (useful when switching languages) */
  clearCache(): void {
    this.memCache.clear();
    // Note: we intentionally keep sessionStorage so it survives route changes
  }
}

// Export a singleton — shared across the whole app
export const translationService = new TranslationService();
