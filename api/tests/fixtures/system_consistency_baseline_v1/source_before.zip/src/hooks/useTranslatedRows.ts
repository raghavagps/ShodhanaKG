/**
 * useTranslatedRows.ts
 *
 * Translates the `name` and `description` fields of table rows
 * (CategoryStatsRow / BridgeRow) fetched from the backend.
 *
 * In English mode, returns the original rows unchanged (zero overhead).
 */

import { useState, useEffect, useRef } from "react";
import { useLanguage } from "@/context/LanguageContext";
import { translationService } from "@/lib/translationService";
import type { CategoryStatsRow } from "@/lib/api";

// Generic row shape — covers both CategoryStatsRow and BridgeRow
export interface TranslatableRow {
  name?: string;
  description?: string;
  [key: string]: unknown;
}

interface UseTranslatedRowsResult<T extends TranslatableRow> {
  translatedRows: T[];
  isTranslating: boolean;
}

export function useTranslatedRows<T extends TranslatableRow>(
  rows: T[]
): UseTranslatedRowsResult<T> {
  const { isHindi } = useLanguage();
  const [translatedRows, setTranslatedRows] = useState<T[]>(rows);
  const [isTranslating, setIsTranslating] = useState(false);
  const lastKeyRef = useRef<string>("");

  useEffect(() => {
    if (!isHindi) {
      setTranslatedRows(rows);
      setIsTranslating(false);
      lastKeyRef.current = "";
      return;
    }

    if (rows.length === 0) {
      setTranslatedRows([]);
      return;
    }

    const key = rows.map((r) => `${r.name}|${r.description}`).join("||");
    if (key === lastKeyRef.current) return;
    lastKeyRef.current = key;

    // Immediately show the untranslated rows while translation is in-flight
    setTranslatedRows(rows);

    let cancelled = false;
    setIsTranslating(true);

    (async () => {
      const names = rows.map((r) => r.name ?? "");
      const descs = rows.map((r) => r.description ?? "");
      const allStrings = [...names, ...descs];

      const translated = await translationService.translateBatch(allStrings);
      if (cancelled) return;

      const n = rows.length;
      const tNames = translated.slice(0, n);
      const tDescs = translated.slice(n);

      const result: T[] = rows.map((row, i) => ({
        ...row,
        name: tNames[i] || row.name,
        description: tDescs[i] || row.description,
      }));

      setTranslatedRows(result);
      setIsTranslating(false);
    })();

    return () => { cancelled = true; };
  }, [rows, isHindi]);

  return { translatedRows, isTranslating };
}

// Convenience re-export for typed CategoryStatsRow usage
export function useTranslatedCategoryRows(
  rows: CategoryStatsRow[]
): UseTranslatedRowsResult<CategoryStatsRow> {
  return useTranslatedRows<CategoryStatsRow>(rows);
}
