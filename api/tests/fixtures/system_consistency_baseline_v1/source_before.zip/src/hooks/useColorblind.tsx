import React, { createContext, useContext, useEffect, useState, ReactNode, useMemo } from "react";

interface ColorblindContextType {
  isColorblind: boolean;
  toggleColorblind: () => void;
  /** Resolves a palette based on current mode */
  getPalette: <T extends string>(basePalette: Record<T, string>) => Record<T, string>;
}

const ColorblindContext = createContext<ColorblindContextType | undefined>(undefined);

export const ColorblindProvider = ({ children }: { children: ReactNode }) => {
  const [isColorblind, setIsColorblind] = useState(() => {
    return localStorage.getItem("shodhana-colorblind") === "true";
  });

  useEffect(() => {
    const root = document.documentElement;
    if (isColorblind) {
      root.classList.add("colorblind");
      localStorage.setItem("shodhana-colorblind", "true");
    } else {
      root.classList.remove("colorblind");
      localStorage.setItem("shodhana-colorblind", "false");
    }
  }, [isColorblind]);

  const toggleColorblind = () => setIsColorblind((prev) => !prev);

  // Hardcoded colorblind palette (matches index.css :root.colorblind)
  const getPalette = React.useCallback(<T extends string>(basePalette: Record<T, string>): Record<T, string> => {
    if (!isColorblind) return basePalette;

    // Map of known keys to their colorblind hex codes
    const colorblindMap: Record<string, string> = {
      // Disease side
      Disease: "#D55E00",
      AyurvedicDiagnosis: "#000000",
      Therapy: "#009E73",
      Formulation: "#CC79A7",
      Symptom: "#F0E442",
      AssessmentParameter: "#0072B2",
      Dosha: "#000000",
      // Compound side
      Compound: "#009E73",
      ShodhanaMethod: "#E69F00",
      ToxicSubstance: "#D55E00",
      PurifiedCompound: "#56B4E9",
      ShodhanaType: "#CC79A7",
      Media: "#0072B2",
      ConfirmationStudy: "#F0E442",
      Process: "#A68A59",
      Indication: "#D55E00",
      AyurvedicFormulation: "#CC79A7",
    };

    const newPalette = { ...basePalette };
    for (const key in basePalette) {
      if (colorblindMap[key]) {
        newPalette[key] = colorblindMap[key];
      }
    }

    return newPalette;
  }, [isColorblind]);

  return (
    <ColorblindContext.Provider value={{ isColorblind, toggleColorblind, getPalette }}>
      {children}
    </ColorblindContext.Provider>
  );
};

export const useColorblind = () => {
  const context = useContext(ColorblindContext);
  if (context === undefined) {
    throw new Error("useColorblind must be used within a ColorblindProvider");
  }
  return context;
};
