/**
 * useTranslatedGraph.ts
 *
 * Translates raw ApiNode[] and ApiEdge[] from the backend into Hindi
 * when the active language is "hi".
 *
 * Strategy:
 *  - Collects all unique translatable strings (labels, descriptions, edge types)
 *  - Sends them in a single translateBatch() call
 *  - Returns translated copies of the arrays + an isTranslating flag
 *  - In English mode, returns the original arrays untouched (zero overhead)
 */

import { useState, useEffect, useRef } from "react";
import { useLanguage } from "@/context/LanguageContext";
import { translationService } from "@/lib/translationService";
import type { ApiNode, ApiEdge } from "@/lib/types";

interface TranslatedGraph {
  translatedNodes: ApiNode[];
  translatedEdges: ApiEdge[];
  isTranslating: boolean;
}

export function useTranslatedGraph(
  nodes: ApiNode[],
  edges: ApiEdge[]
): TranslatedGraph {
  const { isHindi } = useLanguage();

  const [translatedNodes, setTranslatedNodes] = useState<ApiNode[]>(nodes);
  const [translatedEdges, setTranslatedEdges] = useState<ApiEdge[]>(edges);
  const [isTranslating, setIsTranslating] = useState(false);

  // Track the last input we translated to avoid redundant work
  const lastKeyRef = useRef<string>("");

  useEffect(() => {
    if (!isHindi) {
      setTranslatedNodes(nodes);
      setTranslatedEdges(edges);
      setIsTranslating(false);
      lastKeyRef.current = "";
      return;
    }

    if (nodes.length === 0 && edges.length === 0) {
      setTranslatedNodes([]);
      setTranslatedEdges([]);
      return;
    }

    // Build a cheap cache-key so we don't re-translate the same data
    const key = nodes.map((n) => n.id).join(",") + "|" + edges.map((e) => e.id).join(",");
    if (key === lastKeyRef.current) return;
    lastKeyRef.current = key;

    // Immediately show the untranslated graph while translation is in-flight
    setTranslatedNodes(nodes);
    setTranslatedEdges(edges);

    let cancelled = false;
    setIsTranslating(true);

    (async () => {
      // ── Collect all strings to translate in one pass ──────────────────────
      // Layout: [node labels... | node descriptions... | edge types...]
      const nodeLabels   = nodes.map((n) => n.label ?? "");
      const nodeDescs    = nodes.map((n) => String(n.description ?? ""));
      const edgeTypes    = edges.map((e) => e.type ?? "");

      const allStrings = [...nodeLabels, ...nodeDescs, ...edgeTypes];

      const translated = await translationService.translateBatch(allStrings);
      if (cancelled) return;

      // ── Split results back into their respective arrays ───────────────────
      const nLen = nodes.length;
      const eLen = edges.length;

      const tLabels = translated.slice(0, nLen);
      const tDescs  = translated.slice(nLen, nLen * 2);
      const tEdgeTypes = translated.slice(nLen * 2, nLen * 2 + eLen);

      const tNodes: ApiNode[] = nodes.map((n, i) => ({
        ...n,
        label: tLabels[i] || n.label,
        description: tDescs[i] || n.description,
      }));

      const tEdges: ApiEdge[] = edges.map((e, i) => ({
        ...e,
        type: tEdgeTypes[i] || e.type,
      }));

      setTranslatedNodes(tNodes);
      setTranslatedEdges(tEdges);
      setIsTranslating(false);
    })();

    return () => { cancelled = true; };
  }, [nodes, edges, isHindi]);

  return { translatedNodes, translatedEdges, isTranslating };
}
