﻿import React, { createContext, useContext, useState, ReactNode } from "react";
import { uiTranslations, TranslationKey } from "../data/translations/uiTranslations";
import { glossaryTranslations } from "../data/translations/glossary";

type Language = "en" | "hi";

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: (key: TranslationKey | string) => string;
  tg: (term: string) => string;
  isHindi: boolean;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export const LanguageProvider = ({ children }: { children: ReactNode }) => {
  const [language, setLanguageState] = useState<Language>(() => {
    const saved = localStorage.getItem("shodhana_lang");
    return (saved === "en" || saved === "hi") ? saved : "en";
  });

  const setLanguage = (lang: Language) => {
    setLanguageState(lang);
    localStorage.setItem("shodhana_lang", lang);
  };

  const t = (key: TranslationKey | string): string => {
    const translations = (uiTranslations as unknown)[key];
    if (translations) {
      return translations[language] || translations["en"] || key;
    }
    return key;
  };

  const tg = (term: string): string => {
    if (language === "en") return term;
    return glossaryTranslations[term] || glossaryTranslations[term.trim()] || term;
  };

  const isHindi = language === "hi";

  return (
    <LanguageContext.Provider value={{ language, setLanguage, t, tg, isHindi }}>
      {children}
    </LanguageContext.Provider>
  );
};

export const useLanguage = () => {
  const context = useContext(LanguageContext);
  if (!context) {
    throw new Error("useLanguage must be used within a LanguageProvider");
  }
  return context;
};

