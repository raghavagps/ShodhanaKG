import { useState } from "react";
import { ProvenancePanel } from "@/components/explorer/ProvenancePanel";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";

/**
 * Test page for Provenance feature
 * Access at: /test-provenance
 */

const TestProvenance = () => {
  const [diseaseId, setDiseaseId] = useState("36");

  return (
    <div className="container mx-auto p-8">
      <h1 className="text-2xl font-bold mb-4">Provenance Feature Test</h1>
      
      <div className="mb-4 flex gap-2">
        <Input 
          value={diseaseId} 
          onChange={(e) => setDiseaseId(e.target.value)}
          placeholder="Enter Disease ID (e.g., 36)"
          className="w-64"
        />
        <Button onClick={() => window.location.reload()}>
          Reload
        </Button>
      </div>

      <div className="border rounded-lg h-[600px]">
        <ProvenancePanel diseaseId={diseaseId} />
      </div>

      <div className="mt-8 p-4 bg-muted rounded">
        <h2 className="font-semibold mb-2">API Test:</h2>
        <code className="text-sm">
          {`${import.meta.env.VITE_API_BASE || ''}/api/provenance-subgraph.php?diseaseId=${diseaseId}`}
        </code>
      </div>
    </div>
  );
};

export default TestProvenance;
