/* eslint-disable @typescript-eslint/no-explicit-any */
import { useState, useRef, useEffect } from "react";
import { 
  Play, Copy, Terminal, Database, Activity, FileText, 
  CheckCircle, XCircle, Clock, Compass, HelpCircle, 
  GitBranch, ArrowRight, Search, Network, Info, Check, 
  RotateCcw, Sliders, Server, Code, Table as TableIcon,
  ChevronDown, ChevronRight, Eye, ShieldAlert, Cpu
} from "lucide-react";
import { toast } from "sonner";
import { cn } from "@/lib/utils";

// Resolve Base URL dynamically
const API_BASE = import.meta.env.VITE_API_BASE || import.meta.env.BASE_URL.replace(/\/$/, "");

interface EndpointParam {
  name: string;
  type: "text" | "number" | "select";
  default: string | number;
  description: string;
  options?: string[];
  required?: boolean;
}

interface Endpoint {
  id: string;
  file: string;
  name: string;
  category: "System & Core" | "Search & Discovery" | "Graph & Paths" | "Stats & Analytics";
  description: string;
  method: "GET" | "POST";
  params: EndpointParam[];
}

const ENDPOINTS: Endpoint[] = [
  {
    id: "health",
    file: "health.php",
    name: "ArcadeDB Health Check",
    category: "System & Core",
    description: "Verifies basic connectivity to ArcadeDB and runs a test query (SELECT 1).",
    method: "GET",
    params: []
  },
  {
    id: "version",
    file: "version.php",
    name: "PHP Engine Version",
    category: "System & Core",
    description: "Returns the current running PHP version and extension support metrics.",
    method: "GET",
    params: []
  },
  {
    id: "test_db",
    file: "test_db.php",
    name: "Direct Database Query Test",
    category: "System & Core",
    description: "Performs a direct SQL command validation against the Disease class using LIKE matching.",
    method: "GET",
    params: []
  },
  {
    id: "kg-stats",
    file: "kg-stats.php",
    name: "Global Knowledge Graph Statistics",
    category: "Stats & Analytics",
    description: "Fetches aggregated statistical metrics, including total node and edge counts in the graph.",
    method: "GET",
    params: []
  },
  {
    id: "counts",
    file: "counts.php",
    name: "Explorer Category Counts",
    category: "Stats & Analytics",
    description: "Gets the active vertex count per schema category for a given explorer domain.",
    method: "GET",
    params: [
      {
        name: "domain",
        type: "select",
        default: "disease",
        description: "The targeted explorer domain context",
        options: ["disease", "compound", "integrated"],
        required: true
      }
    ]
  },
  {
    id: "search",
    file: "search.php",
    name: "Fuzzy Autocomplete Search",
    category: "Search & Discovery",
    description: "Performs full-text auto-complete search over domain vertices using flexible SQL matching.",
    method: "GET",
    params: [
      {
        name: "domain",
        type: "select",
        default: "disease",
        description: "Explorer domain context",
        options: ["disease", "compound", "integrated"],
        required: true
      },
      {
        name: "q",
        type: "text",
        default: "arthritis",
        description: "Fuzzy search search string",
        required: true
      },
      {
        name: "limit",
        type: "number",
        default: 8,
        description: "Maximum search matches to return"
      },
      {
        name: "type",
        type: "text",
        default: "",
        description: "Optional specific schema type filter (e.g. 'Disease', 'Symptom')"
      }
    ]
  },
  {
    id: "node",
    file: "node.php",
    name: "Node Details & Evidence",
    category: "Search & Discovery",
    description: "Retrieves a single node's metadata, connected neighbors, and mapped PubMed research citations.",
    method: "GET",
    params: [
      {
        name: "domain",
        type: "select",
        default: "disease",
        description: "Explorer domain context",
        options: ["disease", "compound", "integrated"],
        required: true
      },
      {
        name: "id",
        type: "text",
        default: "36",
        description: "The unique node ID (or DB @rid)",
        required: true
      },
      {
        name: "neighborLimit",
        type: "number",
        default: 50,
        description: "Maximum neighbors to return"
      }
    ]
  },
  {
    id: "graph",
    file: "graph.php",
    name: "Subgraph Traversal & Crawls",
    category: "Graph & Paths",
    description: "Executes seed-focused graph walks and compiles nodes/edges schemas at variable depth.",
    method: "GET",
    params: [
      {
        name: "domain",
        type: "select",
        default: "disease",
        description: "Explorer domain context",
        options: ["disease", "compound", "integrated"],
        required: true
      },
      {
        name: "seeds",
        type: "text",
        default: "36",
        description: "Comma-separated starting seed IDs (or DB @rids)",
        required: true
      },
      {
        name: "depth",
        type: "select",
        default: "1",
        description: "The graph crawl traversal depth limit",
        options: ["0", "1", "2"]
      },
      {
        name: "limitNodes",
        type: "number",
        default: 120,
        description: "Cap on total returned nodes"
      },
      {
        name: "limitEdges",
        type: "number",
        default: 300,
        description: "Cap on total returned edges"
      },
      {
        name: "integratedMode",
        type: "select",
        default: "1hop",
        description: "Traverse cross-domain bridges (integrated domain only)",
        options: ["bridge", "1hop"]
      }
    ]
  },
  {
    id: "stats",
    file: "stats.php",
    name: "Explorer Schema Index",
    category: "Stats & Analytics",
    description: "Lists disease or compound index tables with pre-computed aggregate relationships count.",
    method: "GET",
    params: [
      {
        name: "domain",
        type: "select",
        default: "disease",
        description: "Explorer domain context",
        options: ["disease", "compound"],
        required: true
      },
      {
        name: "q",
        type: "text",
        default: "",
        description: "Search filter term"
      },
      {
        name: "sort",
        type: "text",
        default: "name",
        description: "Sort fields (e.g. 'name')"
      },
      {
        name: "dir",
        type: "select",
        default: "asc",
        description: "Sort sorting direction",
        options: ["asc", "desc"]
      },
      {
        name: "limit",
        type: "number",
        default: 10,
        description: "Pagination rows count limit"
      },
      {
        name: "offset",
        type: "number",
        default: 0,
        description: "Pagination records offset"
      }
    ]
  },
  {
    id: "category-stats",
    file: "category-stats.php",
    name: "Per-Category Detailed Stats",
    category: "Stats & Analytics",
    description: "Generates paginated analytics counts for a specific schema class (e.g. Symptoms, Doshas).",
    method: "GET",
    params: [
      {
        name: "domain",
        type: "select",
        default: "disease",
        description: "Explorer domain context",
        options: ["disease", "compound"],
        required: true
      },
      {
        name: "category",
        type: "select",
        default: "Disease",
        description: "The specific vertex type class",
        options: [
          "Disease", "Symptom", "AyurvedicDiagnosis", "Therapy", "Formulation", 
          "AssessmentParameter", "Dosha", "Compound", "ShodhanaMethod", 
          "ToxicSubstance", "PurifiedCompound", "ShodhanaType", "Media", 
          "ConfirmationStudy", "Process"
        ],
        required: true
      },
      {
        name: "q",
        type: "text",
        default: "",
        description: "Search filter term"
      },
      {
        name: "sort",
        type: "text",
        default: "name",
        description: "Sort field"
      },
      {
        name: "dir",
        type: "select",
        default: "asc",
        description: "Sorting direction",
        options: ["asc", "desc"]
      },
      {
        name: "limit",
        type: "number",
        default: 10,
        description: "Pagination limit"
      },
      {
        name: "offset",
        type: "number",
        default: 0,
        description: "Pagination offset"
      }
    ]
  },
  {
    id: "bridge-stats",
    file: "bridge-stats.php",
    name: "Integrated Bridge Data",
    category: "Stats & Analytics",
    description: "Fetches Purified Compounds that act as bridges mapping the Compound and Disease subgraphs.",
    method: "GET",
    params: [
      {
        name: "limit",
        type: "number",
        default: 10,
        description: "Pagination limit"
      },
      {
        name: "offset",
        type: "number",
        default: 0,
        description: "Pagination offset"
      }
    ]
  },
  {
    id: "provenance-subgraph",
    file: "provenance-subgraph.php",
    name: "Disease Provenance Paths",
    category: "Graph & Paths",
    description: "Traces Disease → Therapy → Formulation co-citation paths sharing the same PubMed ID.",
    method: "GET",
    params: [
      {
        name: "diseaseId",
        type: "text",
        default: "36",
        description: "Disease ID or RID (e.g. 36 or #5:33)",
        required: true
      },
      {
        name: "pubmedId",
        type: "text",
        default: "",
        description: "Optional PubMed ID to filter paths"
      },
      {
        name: "limit",
        type: "number",
        default: 50,
        description: "Maximum co-citations to check"
      }
    ]
  },
  {
    id: "compound-provenance",
    file: "compound-provenance.php",
    name: "Compound Purification Provenance",
    category: "Graph & Paths",
    description: "Fetches Compound → ShodhanaMethod → Media purification and detox sequences.",
    method: "GET",
    params: [
      {
        name: "compoundId",
        type: "text",
        default: "201",
        description: "Raw compound node ID (e.g. 201)",
        required: true
      },
      {
        name: "limit",
        type: "number",
        default: 50,
        description: "Maximum sequence paths to build"
      }
    ]
  }
];

const PRESETS = [
  {
    name: "Check Database Connection Health",
    endpointId: "health",
    params: {}
  },
  {
    name: "Search Disease 'Arthritis'",
    endpointId: "search",
    params: { domain: "disease", q: "arthritis", limit: 5 }
  },
  {
    name: "Trace 'Eczema' Provenance Pathway",
    endpointId: "provenance-subgraph",
    params: { diseaseId: "36", limit: 20 }
  },
  {
    name: "Get Purified 'Chitraka' Bridge Data",
    endpointId: "node",
    params: { domain: "integrated", id: "250", neighborLimit: 30 }
  },
  {
    name: "Get Global Graph Database Stats",
    endpointId: "kg-stats",
    params: {}
  },
  {
    name: "Fetch Integrated Bridge Records",
    endpointId: "bridge-stats",
    params: { limit: 5 }
  }
];

export default function ApiTester() {
  const [selectedEndpoint, setSelectedEndpoint] = useState<Endpoint>(ENDPOINTS[0]);
  const [paramValues, setParamValues] = useState<Record<string, string | number>>({});
  const [loading, setLoading] = useState(false);
  const [response, setResponse] = useState<any>(null);
  const [responseHeaders, setResponseHeaders] = useState<Record<string, string>>({});
  const [responseMeta, setResponseMeta] = useState<{
    status: number;
    statusText: string;
    duration: number;
    size: string;
    url: string;
  } | null>(null);
  const [activeTab, setActiveTab] = useState<"json" | "table" | "curl" | "raw">("json");
  const [copiedUrl, setCopiedUrl] = useState(false);
  const [copiedCurl, setCopiedCurl] = useState(false);
  const [searchFilter, setSearchFilter] = useState("");

  // Developer Access Control States
  const [isAuthorized, setIsAuthorized] = useState(false);
  const [passcode, setPasscode] = useState("");
  const [passError, setPassError] = useState("");
  const [shake, setShake] = useState(false);

  // Check persistent session storage on mount
  useEffect(() => {
    const authStatus = sessionStorage.getItem("shodhana_dev_authorized");
    if (authStatus === "true") {
      setIsAuthorized(true);
    }
  }, []);

  const handleAuthSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    const correctPass = import.meta.env.VITE_DEV_PASSKEY || "shodhana-dev-2026";
    if (passcode === correctPass) {
      sessionStorage.setItem("shodhana_dev_authorized", "true");
      setIsAuthorized(true);
      setPassError("");
      toast.success("Developer access granted");
    } else {
      setPassError("Invalid developer passcode. Authorization denied.");
      setShake(true);
      setTimeout(() => setShake(false), 500);
      toast.error("Access Denied");
    }
  };

  const handleLogout = () => {
    sessionStorage.removeItem("shodhana_dev_authorized");
    setIsAuthorized(false);
    setPasscode("");
    toast.info("Developer session locked");
  };

  // Populate default params on endpoint load
  useEffect(() => {
    const defaults: Record<string, string | number> = {};
    selectedEndpoint.params.forEach(p => {
      defaults[p.name] = p.default;
    });
    setParamValues(defaults);
    setResponse(null);
    setResponseMeta(null);
  }, [selectedEndpoint]);

  const handleParamChange = (name: string, value: string | number) => {
    setParamValues(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const getQueryUrl = (rawBase = false) => {
    const base = rawBase ? "${API_BASE}" : API_BASE;
    const queryParams = new URLSearchParams();
    
    selectedEndpoint.params.forEach(p => {
      const val = paramValues[p.name];
      if (val !== undefined && val !== "") {
        queryParams.set(p.name, String(val));
      }
    });

    const queryString = queryParams.toString();
    return `${base}/api/${selectedEndpoint.file}${queryString ? `?${queryString}` : ""}`;
  };

  const generateCurl = () => {
    return `curl -X GET "${getQueryUrl(true)}" \\\n  -H "Accept: application/json"`;
  };

  const executeRequest = async () => {
    setLoading(true);
    setResponse(null);
    setResponseMeta(null);
    
    const url = getQueryUrl();
    const startTime = performance.now();

    try {
      const res = await fetch(url, {
        headers: {
          "Accept": "application/json"
        }
      });
      const endTime = performance.now();
      const duration = Math.round(endTime - startTime);
      
      const text = await res.text();
      const sizeBytes = text.length;
      const sizeStr = sizeBytes > 1024 
        ? `${(sizeBytes / 1024).toFixed(2)} KB` 
        : `${sizeBytes} B`;
      
      let parsedResponse: any;
      try {
        parsedResponse = JSON.parse(text);
      } catch {
        parsedResponse = { rawText: text, isHtml: text.trim().startsWith("<") };
      }

      setResponse(parsedResponse);
      
      // Parse headers
      const headersMap: Record<string, string> = {};
      res.headers.forEach((val, key) => {
        headersMap[key] = val;
      });
      setResponseHeaders(headersMap);

      setResponseMeta({
        status: res.status,
        statusText: res.statusText || (res.status === 200 ? "OK" : ""),
        duration,
        size: sizeStr,
        url
      });
      
      if (res.status >= 200 && res.status < 300) {
        toast.success(`Request completed in ${duration}ms`);
      } else {
        toast.error(`Request failed with status ${res.status}`);
      }
    } catch (err: any) {
      const endTime = performance.now();
      setResponse({
        ok: false,
        error: {
          code: "client_request_failed",
          message: err.message || "Failed to make HTTP fetch request",
          details: err
        }
      });
      setResponseMeta({
        status: 0,
        statusText: "Failed",
        duration: Math.round(endTime - startTime),
        size: "0 B",
        url
      });
      toast.error("Network or connectivity error encountered");
    } finally {
      setLoading(false);
    }
  };

  const applyPreset = (preset: typeof PRESETS[0]) => {
    const ep = ENDPOINTS.find(e => e.id === preset.endpointId);
    if (!ep) return;
    setSelectedEndpoint(ep);
    
    // Defer param mapping to allow default state effect to process
    setTimeout(() => {
      const mappedParams = { ...preset.params } as any;
      ep.params.forEach(p => {
        if (mappedParams[p.name] === undefined) {
          mappedParams[p.name] = p.default;
        }
      });
      setParamValues(mappedParams);
      toast.info(`Preset applied: ${preset.name}`);
    }, 20);
  };

  const copyToClipboard = (text: string, type: "url" | "curl") => {
    navigator.clipboard.writeText(text);
    if (type === "url") {
      setCopiedUrl(true);
      setTimeout(() => setCopiedUrl(false), 2000);
    } else {
      setCopiedCurl(true);
      setTimeout(() => setCopiedCurl(false), 2000);
    }
    toast.success("Copied to clipboard");
  };

  const filteredEndpoints = ENDPOINTS.filter(ep => 
    ep.name.toLowerCase().includes(searchFilter.toLowerCase()) ||
    ep.file.toLowerCase().includes(searchFilter.toLowerCase()) ||
    ep.category.toLowerCase().includes(searchFilter.toLowerCase())
  );

  if (!isAuthorized) {
    return (
      <div className="container py-12 flex flex-col items-center justify-center min-h-[75vh] animate-fade-in">
        <div 
          className={cn(
            "w-full max-w-md rounded-2xl border border-border/80 bg-card/70 p-8 shadow-elevated backdrop-blur-md relative overflow-hidden transition-transform duration-300",
            shake && "animate-shake"
          )}
        >
          {/* Subtle decorative glow */}
          <div className="absolute -top-24 -left-24 h-48 w-48 rounded-full bg-gradient-herbal opacity-10 blur-2xl pointer-events-none" />
          <div className="absolute -bottom-24 -right-24 h-48 w-48 rounded-full bg-gradient-warm opacity-10 blur-2xl pointer-events-none" />
          
          <div className="flex flex-col items-center text-center space-y-6">
            <span className="flex h-14 w-14 items-center justify-center rounded-xl bg-gradient-warm shadow-md text-primary-foreground">
              <ShieldAlert className="h-6 w-6" />
            </span>
            
            <div className="space-y-2">
              <h1 className="font-display text-xl font-bold text-foreground">
                Restricted Diagnostics Console
              </h1>
              <p className="text-xs text-muted-foreground leading-relaxed">
                This administration tool triggers direct schema executions against connection fallback tiers. Entrance is strictly restricted to authorized developers.
              </p>
            </div>

            <form onSubmit={handleAuthSubmit} className="w-full space-y-4 pt-1">
              <div className="space-y-1.5 text-left">
                <label htmlFor="passcode-input" className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground">
                  Developer Access Key
                </label>
                <div className="relative">
                  <input
                    id="passcode-input"
                    type="password"
                    value={passcode}
                    onChange={(e) => setPasscode(e.target.value)}
                    placeholder="Enter passphrase..."
                    autoFocus
                    className="w-full rounded-lg border border-border/85 bg-background pl-3.5 pr-10 py-2 text-xs text-foreground font-mono outline-none focus:border-herbal/50 focus:ring-2 focus:ring-herbal/10 transition-smooth"
                  />
                  <span className="absolute right-3 top-1/2 -translate-y-1/2 text-muted-foreground/60">
                    <Terminal className="h-3.5 w-3.5" />
                  </span>
                </div>
                {passError && (
                  <p className="text-[10px] text-rose-500 font-medium mt-1 select-none flex items-center gap-1 animate-fade-in">
                    <XCircle className="h-3 w-3 shrink-0" />
                    {passError}
                  </p>
                )}
              </div>

              <button
                type="submit"
                className="w-full bg-gradient-herbal text-white rounded-lg py-2 text-xs font-semibold shadow-md flex items-center justify-center gap-2 hover:-translate-y-0.5 hover:scale-[1.01] active:translate-y-0 active:scale-100 transition-all cursor-pointer"
              >
                <CheckCircle className="h-3.5 w-3.5" />
                Authorize Session
              </button>
            </form>

            <div className="text-[10px] text-muted-foreground/80 pt-2 flex items-center justify-center gap-1 font-medium select-none">
              <Server className="h-3.5 w-3.5 text-herbal" />
              Secure connection verified via Vite environment
            </div>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="container py-8 max-w-7xl animate-fade-in">
      {/* Page Header */}
      <div className="mb-6 flex flex-col gap-2 md:flex-row md:items-center md:justify-between border-b border-border/50 pb-5">
        <div>
          <div className="flex items-center gap-2 text-xs font-semibold text-herbal uppercase tracking-wider mb-1">
            <Cpu className="h-3.5 w-3.5" />
            Developer Diagnostics
          </div>
          <h1 className="font-display text-2xl md:text-3xl font-bold text-foreground">
            ArcadeDB API Endpoint Explorer
          </h1>
          <p className="text-xs md:text-sm text-muted-foreground mt-1 leading-relaxed">
            Direct high-fidelity visual request builder and schema diagnostics for ShodhanaKG database endpoints.
          </p>
        </div>
        <div className="flex items-center gap-4 mt-4 md:mt-0">
          <div className="flex items-center gap-2 border-r border-border/60 pr-4">
            <span className="flex h-2.5 w-2.5 rounded-full bg-emerald-500 animate-pulse" />
            <span className="text-[11px] font-medium text-muted-foreground">
              Backend: <strong className="text-foreground">Active</strong>
            </span>
          </div>
          <button
            onClick={handleLogout}
            className="inline-flex h-8 items-center gap-1.5 px-3 rounded-lg border border-border bg-secondary hover:bg-secondary/70 hover:text-rose-600 text-xs font-semibold transition-all shadow-xs cursor-pointer"
            title="Lock Developer Console Session"
          >
            <ShieldAlert className="h-3.5 w-3.5 text-rose-500" />
            Lock Session
          </button>
        </div>
      </div>

      {/* Preset Row */}
      <div className="mb-6 rounded-xl border border-border/70 bg-card/65 p-4 shadow-sm backdrop-blur-sm">
        <div className="text-[11px] font-bold uppercase tracking-wider text-muted-foreground mb-3 flex items-center gap-1.5">
          <Sliders className="h-3.5 w-3.5 text-herbal" />
          Quick Test Presets
        </div>
        <div className="flex flex-wrap gap-2">
          {PRESETS.map((p, idx) => (
            <button
              key={idx}
              onClick={() => applyPreset(p)}
              className="inline-flex items-center gap-1.5 rounded-lg border border-border/80 bg-background/80 px-3 py-1.5 text-xs font-medium text-muted-foreground hover:border-herbal/50 hover:bg-secondary/40 hover:text-foreground hover:-translate-y-0.5 transition-all shadow-xs"
            >
              <Activity className="h-3 w-3 text-terracotta" />
              {p.name}
            </button>
          ))}
        </div>
      </div>

      {/* Main Workspace Layout */}
      <div className="grid gap-6 lg:grid-cols-[330px_1fr] items-stretch min-h-[640px]">
        
        {/* Left Column: API Selector & Parameter Form */}
        <aside className="space-y-4 flex flex-col h-full">
          
          {/* Endpoint Selector Search list */}
          <div className="rounded-xl border border-border/70 bg-card shadow-card flex flex-col max-h-[300px] overflow-hidden">
            <div className="p-3 border-b border-border/60 bg-muted/30">
              <div className="relative rounded-md border border-border bg-background focus-within:border-herbal/40 transition-smooth">
                <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-3.5 w-3.5 text-muted-foreground" />
                <input
                  type="text"
                  value={searchFilter}
                  onChange={(e) => setSearchFilter(e.target.value)}
                  placeholder="Filter 13 endpoints..."
                  className="w-full bg-transparent pl-8 pr-2.5 py-1.5 text-xs outline-none placeholder:text-muted-foreground/60"
                />
              </div>
            </div>
            
            <div className="overflow-y-auto flex-1 p-2 space-y-3">
              {["System & Core", "Search & Discovery", "Graph & Paths", "Stats & Analytics"].map((cat) => {
                const eps = filteredEndpoints.filter(e => e.category === cat);
                if (eps.length === 0) return null;
                return (
                  <div key={cat} className="space-y-1">
                    <div className="text-[9px] font-bold uppercase tracking-wider text-muted-foreground/80 px-2.5 py-1">
                      {cat}
                    </div>
                    {eps.map((ep) => {
                      const isSelected = selectedEndpoint.id === ep.id;
                      return (
                        <button
                          key={ep.id}
                          onClick={() => setSelectedEndpoint(ep)}
                          className={cn(
                            "w-full text-left rounded-lg px-2.5 py-1.5 text-xs font-medium transition-smooth flex items-center justify-between group",
                            isSelected
                              ? "bg-primary text-primary-foreground shadow-sm"
                              : "text-muted-foreground hover:bg-secondary/70 hover:text-foreground"
                          )}
                        >
                          <span className="truncate mr-2 flex items-center gap-1.5">
                            <span className={cn(
                              "h-1.5 w-1.5 rounded-full shrink-0",
                              ep.category === "System & Core" && "bg-blue-400",
                              ep.category === "Search & Discovery" && "bg-emerald-400",
                              ep.category === "Graph & Paths" && "bg-orange-400",
                              ep.category === "Stats & Analytics" && "bg-purple-400"
                            )} />
                            {ep.file}
                          </span>
                          <span className={cn(
                            "text-[9px] uppercase font-bold px-1.5 py-0.5 rounded tracking-wide shrink-0",
                            isSelected 
                              ? "bg-white/20 text-white" 
                              : "bg-muted/80 text-muted-foreground group-hover:bg-background/80"
                          )}>
                            {ep.method}
                          </span>
                        </button>
                      );
                    })}
                  </div>
                );
              })}
            </div>
          </div>

          {/* Request Parameter Builder Form */}
          <div className="rounded-xl border border-border/70 bg-card shadow-card flex-1 flex flex-col overflow-hidden">
            <div className="p-4 border-b border-border/60 bg-muted/10">
              <h2 className="font-display font-bold text-sm text-foreground">
                {selectedEndpoint.name}
              </h2>
              <p className="text-[11px] text-muted-foreground mt-1 leading-relaxed">
                {selectedEndpoint.description}
              </p>
            </div>

            <div className="overflow-y-auto flex-1 p-4 space-y-4">
              {selectedEndpoint.params.length > 0 ? (
                selectedEndpoint.params.map((p) => (
                  <div key={p.name} className="space-y-1.5">
                    <div className="flex justify-between items-center text-xs">
                      <label htmlFor={`param-${p.name}`} className="font-semibold text-foreground">
                        {p.name}
                        {p.required && <span className="text-terracotta ml-0.5">*</span>}
                      </label>
                      <span className="text-[10px] text-muted-foreground italic font-mono uppercase">
                        {p.type}
                      </span>
                    </div>
                    
                    {p.type === "select" ? (
                      <select
                        id={`param-${p.name}`}
                        value={paramValues[p.name] ?? ""}
                        onChange={(e) => handleParamChange(p.name, e.target.value)}
                        className="w-full rounded-md border border-border/80 bg-background px-2.5 py-1.5 text-xs text-foreground outline-none focus:border-herbal/50 focus:ring-2 focus:ring-herbal/10 transition-smooth"
                      >
                        {p.options?.map((opt) => (
                          <option key={opt} value={opt}>
                            {opt}
                          </option>
                        ))}
                      </select>
                    ) : (
                      <input
                        id={`param-${p.name}`}
                        type={p.type === "number" ? "number" : "text"}
                        value={paramValues[p.name] ?? ""}
                        onChange={(e) => handleParamChange(p.name, p.type === "number" ? Number(e.target.value) : e.target.value)}
                        placeholder={`default: ${p.default}`}
                        className="w-full rounded-md border border-border/80 bg-background px-2.5 py-1.5 text-xs text-foreground outline-none focus:border-herbal/50 focus:ring-2 focus:ring-herbal/10 transition-smooth"
                      />
                    )}
                    
                    <p className="text-[10px] text-muted-foreground/80 leading-relaxed font-medium">
                      {p.description}
                    </p>
                  </div>
                ))
              ) : (
                <div className="h-full flex flex-col items-center justify-center text-center text-muted-foreground p-6">
                  <Sliders className="h-6 w-6 opacity-30 mb-2" />
                  <p className="text-xs">No configuration parameters needed for this endpoint.</p>
                </div>
              )}
            </div>

            <div className="p-4 border-t border-border/60 bg-muted/10">
              <button
                onClick={executeRequest}
                disabled={loading}
                className={cn(
                  "w-full bg-gradient-herbal text-white rounded-lg py-2.5 text-xs font-semibold shadow-md flex items-center justify-center gap-2 hover:-translate-y-0.5 hover:scale-[1.01] active:translate-y-0 active:scale-100 transition-all cursor-pointer",
                  loading && "opacity-75 pointer-events-none"
                )}
              >
                {loading ? (
                  <>
                    <RotateCcw className="h-3.5 w-3.5 animate-spin" />
                    Fetching Data...
                  </>
                ) : (
                  <>
                    <Play className="h-3.5 w-3.5 fill-current" />
                    Send API Request
                  </>
                )}
              </button>
            </div>
          </div>
        </aside>

        {/* Right Column: API URL, Latency details, Results visualization */}
        <section className="rounded-xl border border-border/70 bg-card shadow-card flex flex-col overflow-hidden h-full">
          
          {/* Query URL display bar */}
          <div className="p-4 border-b border-border/60 bg-muted/10 flex flex-col gap-3 md:flex-row md:items-center justify-between">
            <div className="flex-1 min-w-0 font-mono text-xs text-muted-foreground bg-background border border-border/60 px-3 py-2 rounded-lg flex items-center gap-2">
              <Server className="h-4.5 w-4.5 text-herbal shrink-0" />
              <span className="truncate select-all text-foreground/95">
                {getQueryUrl()}
              </span>
            </div>
            <div className="flex items-center gap-1.5 shrink-0 self-end md:self-auto">
              <button
                onClick={() => copyToClipboard(getQueryUrl(), "url")}
                className="inline-flex h-8 items-center gap-1.5 px-3 rounded-md border border-border bg-background hover:bg-secondary text-xs font-medium text-foreground transition-smooth"
              >
                {copiedUrl ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Copy className="h-3.5 w-3.5" />}
                Copy URL
              </button>
              <button
                onClick={() => copyToClipboard(generateCurl(), "curl")}
                className="inline-flex h-8 items-center gap-1.5 px-3 rounded-md border border-border bg-background hover:bg-secondary text-xs font-medium text-foreground transition-smooth"
              >
                {copiedCurl ? <Check className="h-3.5 w-3.5 text-emerald-500" /> : <Terminal className="h-3.5 w-3.5" />}
                cURL
              </button>
            </div>
          </div>

          {/* Response Meta Header (Status, Timing, Size) */}
          <div className="px-4 py-3 border-b border-border/50 bg-background/50 flex flex-wrap gap-4 items-center justify-between text-xs text-muted-foreground">
            <div className="flex items-center gap-4 flex-wrap">
              <div className="flex items-center gap-1.5">
                <span className="font-semibold text-foreground">Status:</span>
                {responseMeta ? (
                  <span className={cn(
                    "inline-flex items-center gap-1 px-2.5 py-0.5 rounded-full font-semibold text-[10px]",
                    responseMeta.status >= 200 && responseMeta.status < 300 
                      ? "bg-emerald-50 text-emerald-700 border border-emerald-200" 
                      : "bg-rose-50 text-rose-700 border border-rose-200"
                  )}>
                    {responseMeta.status >= 200 && responseMeta.status < 300 ? (
                      <CheckCircle className="h-3 w-3 text-emerald-500" />
                    ) : (
                      <XCircle className="h-3 w-3 text-rose-500" />
                    )}
                    {responseMeta.status} {responseMeta.statusText}
                  </span>
                ) : (
                  <span className="text-[11px] font-medium text-muted-foreground italic">Idle</span>
                )}
              </div>

              {responseMeta && (
                <>
                  <div className="flex items-center gap-1.5">
                    <Clock className="h-3.5 w-3.5 text-muted-foreground/60" />
                    <span className="font-semibold text-foreground">Latency:</span>
                    <span>{responseMeta.duration} ms</span>
                  </div>

                  <div className="flex items-center gap-1.5">
                    <FileText className="h-3.5 w-3.5 text-muted-foreground/60" />
                    <span className="font-semibold text-foreground">Payload Size:</span>
                    <span>{responseMeta.size}</span>
                  </div>
                </>
              )}
            </div>

            <div className="flex rounded-md border border-border p-0.5 bg-background">
              <TabBtn active={activeTab === "json"} onClick={() => setActiveTab("json")} label="JSON Tree" icon={<Sliders className="h-3 w-3" />} />
              <TabBtn active={activeTab === "table"} onClick={() => setActiveTab("table")} label="Data Table" icon={<TableIcon className="h-3 w-3" />} />
              <TabBtn active={activeTab === "curl"} onClick={() => setActiveTab("curl")} label="cURL Command" icon={<Terminal className="h-3 w-3" />} />
              <TabBtn active={activeTab === "raw"} onClick={() => setActiveTab("raw")} label="Raw JSON" icon={<Code className="h-3 w-3" />} />
            </div>
          </div>

          {/* Results Viewer Output */}
          <div className="flex-1 overflow-auto bg-card/45 relative min-h-[300px]">
            {loading ? (
              <div className="absolute inset-0 flex flex-col items-center justify-center bg-card/60 backdrop-blur-xs gap-3">
                <RotateCcw className="h-8 w-8 text-herbal animate-spin" />
                <div className="text-xs text-muted-foreground font-medium animate-pulse">
                  Querying database node server...
                </div>
              </div>
            ) : response ? (
              <div className="p-4 h-full">
                
                {/* 1. JSON TREE VIEWER */}
                {activeTab === "json" && (
                  <div className="font-mono text-[11px] max-w-full overflow-x-auto p-4 rounded-xl border border-border bg-background shadow-xs select-text">
                    <JsonTree root={response} />
                  </div>
                )}

                {/* 2. DYNAMIC TABULAR DATA PREVIEW */}
                {activeTab === "table" && (
                  <div className="h-full rounded-xl border border-border bg-background overflow-hidden shadow-xs">
                    <TablePreview payload={response} />
                  </div>
                )}

                {/* 3. CURL BLOCK */}
                {activeTab === "curl" && (
                  <div className="font-mono text-xs bg-zinc-950 text-zinc-100 p-5 rounded-xl border border-zinc-800 shadow-md h-full relative">
                    <button
                      onClick={() => copyToClipboard(generateCurl(), "curl")}
                      className="absolute top-4 right-4 bg-zinc-900 border border-zinc-800 text-zinc-400 hover:text-zinc-100 hover:bg-zinc-800 p-1.5 rounded transition-all"
                      title="Copy shell block"
                    >
                      <Copy className="h-3.5 w-3.5" />
                    </button>
                    <pre className="whitespace-pre-wrap">{generateCurl()}</pre>
                  </div>
                )}

                {/* 4. RAW TEXT EDITOR */}
                {activeTab === "raw" && (
                  <textarea
                    readOnly
                    value={JSON.stringify(response, null, 2)}
                    className="w-full h-full font-mono text-xs bg-background border border-border rounded-xl p-4 outline-none resize-none shadow-xs text-foreground select-all"
                  />
                )}

              </div>
            ) : (
              <div className="h-full flex flex-col items-center justify-center text-center p-8 max-w-md mx-auto">
                <span className="flex h-14 w-14 items-center justify-center rounded-full bg-secondary text-herbal mb-4">
                  <Compass className="h-6 w-6 animate-pulse" strokeWidth={1.6} />
                </span>
                <h3 className="font-display text-sm font-semibold mb-1.5">
                  Interactive API Console
                </h3>
                <p className="text-xs text-muted-foreground leading-relaxed">
                  Configure query parameters or load a preset, then press **Send API Request** to fetch live ArcadeDB metrics from the Shodhana database.
                </p>
                <div className="mt-4 flex items-center gap-1 text-[10px] text-muted-foreground/80 font-medium">
                  <Sliders className="h-3 w-3" />
                  Supports full-text query, path walks, co-citations, and bridge stats.
                </div>
              </div>
            )}
          </div>
        </section>

      </div>
    </div>
  );
}

// ──────── HELPERS & SUB-COMPONENTS ────────

const TabBtn = ({
  active,
  onClick,
  label,
  icon
}: {
  active: boolean;
  onClick: () => void;
  label: string;
  icon: React.ReactNode;
}) => (
  <button
    onClick={onClick}
    title={label}
    className={cn(
      "inline-flex items-center gap-1 px-3 py-1.5 rounded-md text-[10px] font-semibold transition-smooth cursor-pointer",
      active 
        ? "bg-secondary text-foreground shadow-xs font-bold" 
        : "text-muted-foreground hover:text-foreground"
    )}
  >
    {icon}
    <span className="hidden sm:inline">{label}</span>
  </button>
);

//Collapsible Interactive JSON Tree Component
function JsonTree({ root }: { root: any }) {
  const [expandedKeys, setExpandedKeys] = useState<Record<string, boolean>>({ "root": true });

  const toggleKey = (keyPath: string) => {
    setExpandedKeys(prev => ({
      ...prev,
      [keyPath]: !prev[keyPath]
    }));
  };

  const renderValue = (val: any, path: string, depth = 0): React.ReactNode => {
    const type = typeof val;

    if (val === null) {
      return <span className="text-zinc-400 italic">null</span>;
    }
    if (type === "boolean") {
      return <span className="text-amber-600 font-bold">{String(val)}</span>;
    }
    if (type === "number") {
      return <span className="text-blue-600 font-bold">{val}</span>;
    }
    if (type === "string") {
      return <span className="text-emerald-600 font-medium">"{val}"</span>;
    }

    if (type === "object") {
      const isArray = Array.isArray(val);
      const keys = Object.keys(val);
      const isOpen = expandedKeys[path];

      if (keys.length === 0) {
        return <span>{isArray ? "[]" : "{}"}</span>;
      }

      return (
        <div className="inline-block">
          <button
            onClick={() => toggleKey(path)}
            className="inline-flex items-center text-muted-foreground hover:text-foreground hover:bg-secondary/40 rounded p-0.5 font-bold outline-none cursor-pointer transition-colors"
          >
            {isOpen ? <ChevronDown className="h-3 w-3" /> : <ChevronRight className="h-3 w-3" />}
            <span className="text-zinc-400 font-semibold font-mono text-[10px] ml-0.5">
              {isArray ? `Array(${keys.length})` : `Object`}
            </span>
          </button>

          {isOpen && (
            <div 
              className="pl-4 border-l border-border/80 mt-1 space-y-1"
              style={{ paddingLeft: "14px" }}
            >
              {keys.map((k) => {
                const childPath = `${path}.${k}`;
                const childValue = val[k];
                return (
                  <div key={k} className="flex flex-wrap items-start">
                    <span className="text-purple-600 font-semibold mr-1 font-mono">{k}:</span>
                    {renderValue(childValue, childPath, depth + 1)}
                  </div>
                );
              })}
            </div>
          )}
        </div>
      );
    }

    return <span>{String(val)}</span>;
  };

  return <div className="space-y-1">{renderValue(root, "root")}</div>;
}

// Dynamic Data Table Preview Component
function TablePreview({ payload }: { payload: any }) {
  if (!payload || typeof payload !== "object") {
    return <div className="p-6 text-center text-xs text-muted-foreground font-medium">Invalid data format for Table preview.</div>;
  }

  // Handle case where error response is loaded
  if (payload.ok === false) {
    return (
      <div className="p-6 flex flex-col items-center justify-center text-center max-w-sm mx-auto h-full">
        <ShieldAlert className="h-8 w-8 text-rose-500 mb-2" />
        <h4 className="font-semibold text-xs text-foreground mb-1">API Error Payload</h4>
        <p className="text-[11px] text-muted-foreground leading-relaxed">
          {payload.error?.message || "An error occurred on the database connector endpoint."}
        </p>
      </div>
    );
  }

  // Attempt to extract displayable arrays
  let arrayData: any[] | null = null;
  let arrayName = "";

  if (Array.isArray(payload)) {
    arrayData = payload;
    arrayName = "Items";
  } else if (payload.nodes && Array.isArray(payload.nodes)) {
    arrayData = payload.nodes;
    arrayName = "Nodes";
  } else if (payload.rows && Array.isArray(payload.rows)) {
    arrayData = payload.rows;
    arrayName = "Rows";
  } else if (payload.paths && Array.isArray(payload.paths)) {
    arrayData = payload.paths;
    arrayName = "Paths";
  } else if (payload.edges && Array.isArray(payload.edges)) {
    arrayData = payload.edges;
    arrayName = "Edges";
  } else if (payload.counts && typeof payload.counts === "object") {
    // Convert counts map to array
    arrayData = Object.entries(payload.counts).map(([k, v]) => ({ Category: k, Count: v }));
    arrayName = "Category Counts";
  } else {
    // Try to find any array key inside the payload object
    const arrayKey = Object.keys(payload).find(k => Array.isArray(payload[k]));
    if (arrayKey) {
      arrayData = payload[arrayKey];
      arrayName = arrayKey;
    }
  }

  if (!arrayData || arrayData.length === 0) {
    return (
      <div className="p-8 text-center text-xs text-muted-foreground h-full flex flex-col items-center justify-center">
        <TableIcon className="h-6 w-6 opacity-30 mb-2" />
        <p>No flat list array found in response to display inside a table.</p>
        <span className="text-[10px] text-muted-foreground/75 mt-1">Use the **JSON Tree** tab to browse nested objects.</span>
      </div>
    );
  }

  // Flatten and resolve column headers
  // Only look at the first 3 objects to establish columns, up to 6 keys to keep it readable
  const columnSet = new Set<string>();
  arrayData.slice(0, 3).forEach(item => {
    if (item && typeof item === "object") {
      Object.keys(item).forEach(k => {
        if (typeof item[k] !== "object" || item[k] === null) {
          columnSet.add(k);
        }
      });
    }
  });

  const columns = Array.from(columnSet).slice(0, 6);

  if (columns.length === 0) {
    // Fallback if elements are primitive array
    return (
      <div className="p-4 overflow-y-auto max-h-[400px]">
        <div className="text-[11px] font-bold text-muted-foreground uppercase tracking-wider mb-2">
          {arrayName} ({arrayData.length})
        </div>
        <ol className="list-decimal list-inside space-y-1 font-mono text-[11px] text-foreground">
          {arrayData.map((item, idx) => (
            <li key={idx} className="border-b border-border/40 py-1.5">
              {typeof item === "object" ? JSON.stringify(item) : String(item)}
            </li>
          ))}
        </ol>
      </div>
    );
  }

  return (
    <div className="h-full flex flex-col overflow-hidden">
      <div className="px-4 py-2 border-b border-border bg-muted/20 text-[10px] font-bold text-muted-foreground uppercase tracking-wider flex items-center justify-between shrink-0">
        <span>Table Preview: {arrayName}</span>
        <span>{arrayData.length} records</span>
      </div>
      <div className="flex-1 overflow-auto max-h-[500px]">
        <table className="w-full text-left border-collapse text-xs select-text">
          <thead className="bg-muted/40 font-semibold border-b border-border text-foreground/90">
            <tr>
              {columns.map(c => (
                <th key={c} className="px-4 py-2.5 font-bold uppercase tracking-wider text-[10px]">
                  {c}
                </th>
              ))}
            </tr>
          </thead>
          <tbody className="divide-y divide-border/60">
            {arrayData.map((row, idx) => (
              <tr key={idx} className="hover:bg-secondary/40 transition-colors font-medium">
                {columns.map(col => {
                  const val = row[col];
                  return (
                    <td key={col} className="px-4 py-2 text-foreground/80 font-mono text-[10.5px] max-w-[200px] truncate select-all">
                      {val === null || val === undefined ? (
                        <span className="text-muted-foreground/45 italic">-</span>
                      ) : typeof val === "boolean" ? (
                        String(val)
                      ) : (
                        String(val)
                      )}
                    </td>
                  );
                })}
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
