import { ReferenceLinks } from "./ReferenceLinks";
import type { PublicationReference } from "@/lib/types";
import { ArrowRight, ExternalLink, Info } from "lucide-react";
import { GenericNode, GenericEdge } from "./GraphCanvas";
import { useLanguage } from "@/context/LanguageContext";

interface Props {
  selectedNode?: GenericNode;
  selectedEdge?: { edge: GenericEdge; source: GenericNode; target: GenericNode };
  nodeTypeLabels: Record<string, string>;
  edgeTypeLabels: Record<string, string>;
  nodeColors: Record<string, string>;
  edgeColors: Record<string, string>;
  /** Edge property keys to show in details, with display labels */
  edgePropertyMap?: Record<string, { label: string; key: string }[]>;
}

const Row = ({ k, v }: { k: string; v: React.ReactNode }) => (
  <div className="grid grid-cols-[110px_1fr] gap-2 py-1.5 border-b border-border/50 last:border-0">
    <span className="text-[11px] uppercase tracking-wider text-muted-foreground">{k}</span>
    <span className="text-xs text-foreground break-words">{v}</span>
  </div>
);

export const DetailsPanel = ({
  selectedNode,
  selectedEdge,
  nodeTypeLabels,
  edgeTypeLabels,
  nodeColors,
  edgeColors,
  edgePropertyMap = {},
}: Props) => {
  const { t, tg } = useLanguage();

  if (!selectedNode && !selectedEdge) {
    return (
      <div className="h-full flex flex-col items-center justify-center text-center px-6 text-muted-foreground">
        <Info className="h-6 w-6 mb-3 opacity-60" />
        <p className="text-sm font-medium text-foreground">{t("nothingSelected")}</p>
        <p className="text-xs mt-1 max-w-[220px]">
          {t("inspectProperties")}
        </p>
      </div>
    );
  }

  if (selectedNode) {
    const color = nodeColors[selectedNode.type];
    
    // Check if there's a description
    const hasDescription = selectedNode.description && String(selectedNode.description).trim() !== "";
    
    // Check if there are any properties to display
    const propertyEntries = Object.entries(selectedNode).filter(([k, v]) => {
      if (["id", "label", "type", "description", "@cat"].includes(k)) return false;
      if (v === null || v === undefined || v === "") return false;
      return true;
    });
    const hasProperties = propertyEntries.length > 0;
    
    return (
      <div className="p-5 space-y-4">
        <div>
          <div className="flex items-center gap-2 mb-2">
            <span className="h-2.5 w-2.5 rounded-full" style={{ background: color }} />
            <span className="text-[10px] uppercase tracking-[0.16em] font-semibold text-muted-foreground">
              {t("node")} · {tg(nodeTypeLabels[selectedNode.type] ?? selectedNode.type)}
            </span>
          </div>
          <h3 className="font-display text-lg font-semibold text-foreground leading-tight">
            {tg(selectedNode.label)}
          </h3>
        </div>

        {hasDescription && (
          <div className="rounded-md bg-secondary/50 p-3 text-xs text-foreground/90 leading-relaxed">
            {selectedNode.description}
          </div>
        )}

        {hasProperties && (
          <div>
            <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1.5">{t("properties")}</div>
            {/* Dynamic properties from DB */}
            {propertyEntries.map(([k, v]) => (
              <Row key={k} k={tg(k.replace(/_/g, " "))} v={tg(String(v))} />
            ))}
          </div>
        )}
      </div>
    );
  }

  // Edge
  const { edge, source, target } = selectedEdge!;
  const color = edgeColors[edge.type];
  const props = edgePropertyMap[edge.type] ?? [];
  const definedProps = props.filter((p) => edge[p.key] !== undefined && edge[p.key] !== null && edge[p.key] !== "");

  return (
    <div className="p-5 space-y-4 animate-fade-in">
      <div>
        <div className="flex items-center gap-2 mb-2 flex-wrap">
          <span className="h-2.5 w-2.5 rounded-full" style={{ background: color }} />
          <span className="text-[10px] uppercase tracking-[0.16em] font-semibold text-muted-foreground">
            {t("relationship")}
          </span>
        </div>
        <h3 className="font-mono text-sm font-semibold text-foreground">
          {tg(edgeTypeLabels[edge.type] ?? edge.type)}
        </h3>
      </div>

      <div className="rounded-lg bg-secondary/50 border border-border/60 p-3 animate-fade-in">
        <div className="flex flex-col items-stretch gap-1.5">
          <div className="flex items-start gap-2">
            <span
              className="h-2 w-2 mt-1.5 rounded-full shrink-0"
              style={{ background: nodeColors[source.type] }}
            />
            <span
              className="flex-1 rounded-md bg-background border border-border/70 px-2.5 py-1.5 text-xs font-semibold text-foreground break-words whitespace-normal leading-snug shadow-sm"
              style={{ borderColor: nodeColors[source.type] }}
            >
              {tg(source.label)}
            </span>
          </div>

          <div className="flex items-center gap-2 pl-1">
            <ArrowRight
              className="h-4 w-4 rotate-90 shrink-0"
              style={{ color }}
              strokeWidth={2.5}
            />
            <span
              className="text-[10px] uppercase tracking-wider font-semibold px-1.5 py-0.5 rounded"
              style={{ color }}
            >
              {tg(edgeTypeLabels[edge.type] ?? edge.type)}
            </span>
          </div>

          <div className="flex items-start gap-2">
            <span
              className="h-2 w-2 mt-1.5 rounded-full shrink-0"
              style={{ background: nodeColors[target.type] }}
            />
            <span
              className="flex-1 rounded-md bg-background border border-border/70 px-2.5 py-1.5 text-xs font-semibold text-foreground break-words whitespace-normal leading-snug shadow-sm"
              style={{ borderColor: nodeColors[target.type] }}
            >
              {tg(target.label)}
            </span>
          </div>
        </div>
      </div>

      <div>
        <div className="text-[10px] uppercase tracking-wider text-muted-foreground mb-1.5">{t("properties")}</div>
        {definedProps.map((p) => (
          <Row key={p.key} k={tg(p.label)} v={tg(String(edge[p.key]))} />
        ))}
        {(edge.references || edge.reference || edge.pubmedId) && <Row k="Reference" v={<ReferenceLinks references={edge.references as PublicationReference[]} raw={String(edge.reference ?? edge.pubmedId ?? "")} />} />}
        {definedProps.length === 0 && !edge.pubmedId && (
          <div className="text-xs text-muted-foreground italic py-1">No additional properties.</div>
        )}
      </div>

      
    </div>
  );
};
