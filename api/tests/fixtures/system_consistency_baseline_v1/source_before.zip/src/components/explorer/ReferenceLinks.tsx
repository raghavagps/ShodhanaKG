import type { PublicationReference } from '@/lib/types';

export function ReferenceLinks({ references, raw }: { references?: PublicationReference[]; raw?: string }) {
  if (!references?.length) return raw ? <span>Reference: {raw} (unclassified)</span> : null;
  return <>{references.map((ref, index) => {
    const classified = ref.namespace && ['verified', 'declared'].includes(ref.status);
    const text = classified ? `${ref.namespace === 'AYUSH' ? 'AYUSH ID' : ref.namespace} ${ref.identifier}` : `Reference: ${ref.raw} (${ref.status === 'conflict' ? 'conflicting identifiers' : 'unclassified'}; review required)`;
    const href = !classified ? undefined : ref.namespace === 'PMID'
      ? `https://pubmed.ncbi.nlm.nih.gov/${encodeURIComponent(ref.identifier)}/`
      : ref.namespace === 'DOI' ? `https://doi.org/${encodeURIComponent(ref.identifier)}`
        : 'https://arp.ayush.gov.in/research_advance_search';
    return <span key={index} className="inline-block break-all mr-2">
      {href ? <a href={href} target="_blank" rel="noopener noreferrer" className="text-primary underline" title={ref.namespace === 'AYUSH' ? `Search the AYUSH portal for ${ref.identifier}` : undefined}>{text}</a> : text}
      {ref.status === 'declared' && <span className="text-muted-foreground"> (registry not verified)</span>}
      {ref.resolution_status === 'unresolved' && <span className="text-muted-foreground"> (registry lookup unresolved)</span>}
    </span>;
  })}</>;
}
