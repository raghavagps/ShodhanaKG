import { NavLink, Link } from "react-router-dom";
import { Leaf, ChevronDown, Home, Activity, FlaskConical, Network, Share2, HelpCircle, MessageCircle, Eye, Info, BookOpen, Terminal } from "lucide-react";
import { cn } from "@/lib/utils";
import { useColorblind } from "@/hooks/useColorblind";
import { useLanguage } from "@/context/LanguageContext";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export const TopNav = () => {
  const { isColorblind, toggleColorblind } = useColorblind();
  const { language, setLanguage, t } = useLanguage();

  return (
    <header className="sticky top-0 z-40 w-full border-b-2 border-herbal/20 bg-secondary/95 backdrop-blur-md shadow-sm">
      <div className="container flex h-16 items-center justify-between gap-4">
        <Link to="/" className="flex items-center gap-2.5 group shrink-0">
          <span className="flex h-9 w-9 items-center justify-center rounded-md bg-gradient-herbal shadow-sm">
            <Leaf className="h-4.5 w-4.5 text-primary-foreground" strokeWidth={2.2} />
          </span>
          <div className="leading-tight">
            <div className="font-display text-lg font-semibold text-bark">
              ShodhanaKG
            </div>
            <div className="text-[10px] uppercase tracking-[0.18em] text-muted-foreground font-medium">
              {t("ayurvedicBiomedicalKg")}
            </div>
          </div>
        </Link>

        {/* Spacer to push nav to the right */}
        <div className="flex-1" />

        <nav className="hidden md:flex items-center gap-6">
          <Link 
            to="/" 
            className="flex items-center gap-1.5 text-[15px] font-semibold text-bark hover:text-herbal transition-smooth"
          >
            <Home className="h-4 w-4" />
            {t("home")}
          </Link>

          <DropdownMenu>
            <DropdownMenuTrigger className="flex items-center gap-1.5 text-[15px] font-semibold text-bark hover:text-herbal outline-none transition-smooth group">
              {t("explorer")}
              <ChevronDown className="h-4 w-4 transition-transform group-data-[state=open]:rotate-180" />
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48 p-1.5 animate-in fade-in zoom-in-95 duration-200">
              <DropdownMenuItem asChild className="rounded-md">
                <Link to="/explorer/disease" className="flex items-center gap-2 px-2 py-2">
                  <Activity className="h-4 w-4 text-terracotta" />
                  <span className="text-xs font-semibold">{t("diseaseExplorer")}</span>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild className="rounded-md">
                <Link to="/explorer/compound" className="flex items-center gap-2 px-2 py-2">
                  <FlaskConical className="h-4 w-4 text-herbal" />
                  <span className="text-xs font-semibold">{t("compoundExplorer")}</span>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild className="rounded-md">
                <Link to="/explorer/integrated" className="flex items-center gap-2 px-2 py-2">
                  <Network className="h-4 w-4 text-bark" />
                  <span className="text-xs font-semibold">{t("integratedExplorer")}</span>
                </Link>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <DropdownMenu>
            <DropdownMenuTrigger className="flex items-center gap-1.5 text-[15px] font-semibold text-bark hover:text-herbal outline-none transition-smooth group">
              {t("knowledgeGraph")}
              <ChevronDown className="h-4 w-4 transition-transform group-data-[state=open]:rotate-180" />
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-52 p-1.5 animate-in fade-in zoom-in-95 duration-200">
              <DropdownMenuItem asChild className="rounded-md">
                <Link to="/explorer/disease/graph" className="flex items-center gap-2 px-2 py-2">
                  <Share2 className="h-4 w-4 text-terracotta" />
                  <span className="text-xs font-semibold">{t("diseaseGraph")}</span>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild className="rounded-md">
                <Link to="/explorer/compound/graph" className="flex items-center gap-2 px-2 py-2">
                  <Share2 className="h-4 w-4 text-herbal" />
                  <span className="text-xs font-semibold">{t("compoundGraph")}</span>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild className="rounded-md">
                <Link to="/explorer/integrated/graph" className="flex items-center gap-2 px-2 py-2">
                  <Share2 className="h-4 w-4 text-bark" />
                  <span className="text-xs font-semibold">{t("integratedGraph")}</span>
                </Link>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <DropdownMenu>
            <DropdownMenuTrigger className="flex items-center gap-1.5 text-[15px] font-semibold text-bark hover:text-herbal outline-none transition-smooth group">
              {t("help")}
              <ChevronDown className="h-4 w-4 transition-transform group-data-[state=open]:rotate-180" />
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48 p-1.5 animate-in fade-in zoom-in-95 duration-200">
              <DropdownMenuItem asChild className="rounded-md">
                <Link to="/faq" className="flex items-center gap-2 px-2 py-2">
                  <HelpCircle className="h-4 w-4 text-blue-500" />
                  <span className="text-xs font-semibold">{t("faqs")}</span>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild className="rounded-md">
                <Link to="/how-to-use" className="flex items-center gap-2 px-2 py-2">
                  <BookOpen className="h-4 w-4 text-orange-500" />
                  <span className="text-xs font-semibold">{t("howToUse")}</span>
                </Link>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          <DropdownMenu>
            <DropdownMenuTrigger className="flex items-center gap-1.5 text-[15px] font-semibold text-bark hover:text-herbal outline-none transition-smooth group">
              {t("aboutUs")}
              <ChevronDown className="h-4 w-4 transition-transform group-data-[state=open]:rotate-180" />
            </DropdownMenuTrigger>
            <DropdownMenuContent align="end" className="w-48 p-1.5 animate-in fade-in zoom-in-95 duration-200">
              <DropdownMenuItem asChild className="rounded-md">
                <Link to="/team" className="flex items-center gap-2 px-2 py-2">
                  <Info className="h-4 w-4 text-herbal" />
                  <span className="text-xs font-semibold">{t("developers")}</span>
                </Link>
              </DropdownMenuItem>
              <DropdownMenuItem asChild className="rounded-md">
                <Link to="/contact" className="flex items-center gap-2 px-2 py-2">
                  <MessageCircle className="h-4 w-4 text-blue-500" />
                  <span className="text-xs font-semibold">{t("contact")}</span>
                </Link>
              </DropdownMenuItem>
            </DropdownMenuContent>
          </DropdownMenu>

          {/* Minimalist Capsule Toggle */}
          <button
            onClick={() => setLanguage(language === "en" ? "hi" : "en")}
            className="relative flex h-8 w-[64px] items-center rounded-full bg-secondary border border-border/70 p-1 shadow-sm transition-all focus:outline-none shrink-0"
            title={language === "en" ? "हिन्दी में बदलें" : "Switch to English"}
          >
            <div
              className={cn(
                "absolute h-6 w-6 rounded-full bg-primary shadow-sm transition-all duration-300 flex items-center justify-center text-[10px] font-bold text-primary-foreground",
                language === "hi" ? "left-[34px]" : "left-1"
              )}
            >
              {language === "hi" ? "हिं" : "EN"}
            </div>
            <span className="ml-auto mr-2.5 text-[9px] font-extrabold text-muted-foreground/60 select-none">
              {language === "en" ? "हिं" : ""}
            </span>
            <span className="ml-2.5 mr-auto text-[9px] font-extrabold text-muted-foreground/60 select-none">
              {language === "hi" ? "EN" : ""}
            </span>
          </button>

          <button
            onClick={toggleColorblind}
            className={cn(
              "flex items-center gap-1.5 px-3 py-1.5 rounded-full text-xs font-semibold transition-all shadow-sm shrink-0",
              isColorblind 
                ? "bg-blue-600 text-white hover:bg-blue-700 shadow-blue-200" 
                : "bg-secondary text-muted-foreground hover:text-foreground hover:bg-secondary/80"
            )}
            title={isColorblind ? t("colorblindOn") : t("colorblindMode")}
          >
            <Eye className="h-3.5 w-3.5" />
            {isColorblind ? t("colorblindOn") : t("colorblindMode")}
          </button>
        </nav>
      </div>
    </header>
  );
};
