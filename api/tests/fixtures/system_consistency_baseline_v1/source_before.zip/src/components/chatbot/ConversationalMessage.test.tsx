import { fireEvent, render, screen, within } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import { ChatMessage } from './ChatMessage';
import { ChatMessage as Message } from '@/lib/types';

describe('Conversational answers', () => {
  it('opens the cited record, describes its support and distinguishes DOI from PMID', () => {
    const message: Message = {
      role: 'bot', status: 'success', text: 'A recorded association [11]',
      answer_intro: 'Here is the available information.',
      answer_blocks: [{ text: 'Sutshekhar Rasa is recorded under Oral Medication for Vipadika.', citation_ids: ['11'] }],
      context: { status: 'success', question: 'q', retrieval: { status: 'success', entity: { name: 'Vipadika' }, path: [], results: Array.from({ length: 11 }, () => ({ therapy: 'Oral Medication', formulation: 'Sutshekhar Rasa' })) } },
      citations: [{ id: '11', fact_ids: ['f11'], record_indices: [10], attribution: 'record', statement: 'Sutshekhar Rasa is recorded under Oral Medication for Vipadika.', scopes: [
        { description: 'Evidence for this therapy–formulation association', identifiers: { doi: '10.1234/test', references: [{ raw: '10.1234/test', identifier: '10.1234/test', namespace: 'DOI', status: 'declared', resolution_status: 'not_checked', catalog_version: 'test' }] }, properties: { Duration: '7 days' } },
      ] }],
    };
    render(<ChatMessage message={message} />);
    expect(screen.queryByText('What this reference supports')).not.toBeInTheDocument();
    fireEvent.click(screen.getByRole('button', { name: 'View source 11' }));
    const card = screen.getByRole('article', { name: 'Evidence record 11' });
    expect(card).toHaveFocus();
    expect(within(card).getByText('What this reference supports')).toBeInTheDocument();
    expect(within(card).getByText('7 days')).toBeInTheDocument();
    expect(within(card).getByRole('link', { name: 'DOI 10.1234/test' })).toHaveAttribute('href', 'https://doi.org/10.1234%2Ftest');
    expect(within(card).queryByRole('link', { name: /PMID/ })).not.toBeInTheDocument();
    expect(within(card).getByText(/does not include a study outcome/)).toBeInTheDocument();
    expect(within(card).getByText(/separate support for each step is not available/)).toBeInTheDocument();
    expect(screen.getByRole('button', { name: 'View all results and sources' })).toHaveAttribute('aria-expanded', 'true');
  });
});
