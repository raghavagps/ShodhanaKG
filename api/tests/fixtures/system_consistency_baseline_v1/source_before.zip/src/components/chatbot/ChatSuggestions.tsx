import React from 'react';
import { Button } from '@/components/ui/button';

interface ChatSuggestionsProps {
  onSelect: (suggestion: string) => void;
}

const DEFAULT_SUGGESTIONS = [
  "Name 5 media used for Mardana Shodhana.",
  "Which therapies are used to treat Alopecia?",
  "Which compounds use Sesame Oil?",
  "What is the shodhana method used to purify aconitum ferox?",
  "What are the Symptoms of Psoriasis?"
];

export const ChatSuggestions: React.FC<ChatSuggestionsProps> = ({ onSelect }) => {
  return (
    <div className="flex flex-wrap gap-2 mb-4 px-2">
      {DEFAULT_SUGGESTIONS.map((suggestion, index) => (
        <Button
          key={index}
          variant="outline"
          size="sm"
          className="text-xs h-auto py-1.5 px-3 rounded-full border-herbal/30 hover:border-herbal/60 hover:bg-herbal/5 text-bark"
          onClick={() => onSelect(suggestion)}
        >
          {suggestion}
        </Button>
      ))}
    </div>
  );
};
