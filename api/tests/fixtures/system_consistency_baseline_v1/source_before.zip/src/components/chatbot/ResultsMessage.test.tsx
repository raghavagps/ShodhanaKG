import { fireEvent, render, screen, within } from '@testing-library/react';
import { describe, expect, it } from 'vitest';
import sample from '../../../api/tests/fixtures/results_first_psoriasis.json';
import { ChatMessage } from './ChatMessage';
import { ChatMessage as Message } from '@/lib/types';

describe('Results-first answers', () => {
  it('groups 19 symptoms, expands all, and focuses any of the 38 supporting records', () => {
    const message = { ...sample, role: 'bot', text: sample.answer } as unknown as Message;
    render(<ChatMessage message={message} />);
    const list = screen.getByRole('list', { name: 'Retrieved results' });
    expect(within(list).getAllByRole('listitem')).toHaveLength(5);
    fireEvent.click(screen.getByRole('button', { name: 'View all 19 results →' }));
    expect(within(list).getAllByRole('listitem')).toHaveLength(19);
    expect(within(list).getAllByRole('button')).toHaveLength(38);
    fireEvent.click(screen.getByRole('button', { name: 'View source 38', exact: true }));
    const card = screen.getByRole('article', { name: 'Evidence record 38' });
    expect(card).toHaveFocus();
    expect(within(card).getByText('Disease → Symptom')).toBeVisible();
    expect(screen.getByText('Showing sources 38–38 of 38')).toBeVisible();
    expect(within(card).queryByText('Not supplied')).not.toBeInTheDocument();
    expect(within(card).getByText('Technical details')).toBeInTheDocument();
  });

  it('displays arbitrary meaningful edge fields, retaining zero and false', () => {
    const message = structuredClone({ ...sample, role: 'bot', text: sample.answer }) as unknown as Message;
    message.citations![0].scopes[0].properties = {
      custom_measurement: 'Measured value', zero: 0, observed: false,
      missing: null, empty: ' ', absent: 'Not supplied', nested: { blank: null, detail: 'Nested value' },
    };
    render(<ChatMessage message={message} />);
    fireEvent.click(screen.getByRole('button', { name: 'View source 1', exact: true }));
    const card = screen.getByRole('article', { name: 'Evidence record 1' });
    expect(within(card).getByText('Measured value')).toBeVisible();
    expect(within(card).getByText('0')).toBeVisible();
    expect(within(card).getByText('false')).toBeVisible();
    expect(within(card).getByText('Nested value')).toBeVisible();
    expect(within(card).queryByText('missing:')).not.toBeInTheDocument();
    expect(within(card).queryByText('Not supplied')).not.toBeInTheDocument();
  });
});
