import React, { useState } from 'react';
import { ChevronDown, ChevronUp, Database } from 'lucide-react';
import { cn } from '@/lib/utils';
import { ChatMessage as ChatMessageType } from '@/lib/types';
import { ReferenceLinks } from '@/components/explorer/ReferenceLinks';
import { TypingIndicator } from './TypingIndicator';
import { EvidenceRecords } from './EvidenceRecords';

interface ChatMessageProps {
  message: ChatMessageType;
  onRetry?: () => void;
}

const escapeHtml = (unsafe: string) => {
  return unsafe
    .replace(/&/g, "&amp;")
    .replace(/</g, "&lt;")
    .replace(/>/g, "&gt;")
    .replace(/"/g, "&quot;")
    .replace(/'/g, "&#039;");
};

export const ChatMessage: React.FC<ChatMessageProps> = ({ message, onRetry }) => {
  const isBot = message.role === 'bot';
  const [showSources, setShowSources] = useState(false);
  const [showAllResults, setShowAllResults] = useState(false);
  const [focusedRecord, setFocusedRecord] = useState<number | undefined>();
  const [focusRequest, setFocusRequest] = useState(0);
  const openCitation = (id: string) => {
    const citation = message.citations?.find(c => c.id === id);
    if (!citation) return;
    setFocusedRecord(citation.record_indices[0]);
    setFocusRequest(n => n + 1);
    setShowSources(true);
  };

  // Basic parser for **bold** and [PubMed: 12345] citations safely
  const renderText = (text: string) => {
    if (!text) return null;

    // Split by PubMed citations
    const parts = text.split(/\[(?:PubMed|PMID):\s*(\d+)\]/gi);
    
    return parts.map((part, index) => {
      if (index % 2 === 1) {
        return <ReferenceLinks key={index} raw={part} />;
      }
      
      let safeHtml = escapeHtml(part);
      safeHtml = safeHtml
        .replace(/\*\*(.*?)\*\*/g, '<strong>$1</strong>')
        .replace(/\n- (.*?)(?=\n|$)/g, '<br/>• $1')
        .replace(/\n/g, '<br/>');
        
      return <span key={index} dangerouslySetInnerHTML={{ __html: safeHtml }} />;
    });
  };

  const hasContext = message.status === 'success' && message.context?.retrieval?.results && message.context.retrieval.results.length > 0;

  return (
    <div className={cn("flex w-full", isBot ? "justify-start" : "justify-end")}>
      <div
        className={cn(
          "max-w-[85%] rounded-2xl px-4 py-2.5 text-[13px] shadow-sm flex flex-col gap-2",
          isBot 
            ? "bg-secondary/80 text-secondary-foreground rounded-tl-sm" 
            : "bg-primary text-primary-foreground rounded-tr-sm"
        )}
      >
        {(!message.text && message.status !== 'network_error' && message.status !== 'llm_error') ? (
          <TypingIndicator />
        ) : (
          message.status !== 'network_error' && (
            <div className="leading-relaxed break-words min-w-0">
              {message.answer_results?.length && message.status === 'success' ? (
                <div className="space-y-3">
                  {message.answer_heading && <h3 className="font-semibold">{message.answer_heading}</h3>}
                  {message.answer_intro && <p>{message.answer_intro}</p>}
                  <ol aria-label="Retrieved results" className="list-decimal pl-5 space-y-1">
                    {message.answer_results.slice(0, showAllResults ? undefined : 5).map(result => <li key={result.id}>
                      <span>{result.label}</span>{' '}
                      {result.citation_ids.map(id => <button key={id} type="button" aria-label={`View source ${id}`} onClick={() => openCitation(id)} className="text-primary underline px-0.5 text-xs">[{id}]</button>)}
                    </li>)}
                  </ol>
                  {message.answer_results.length > 5 && <button type="button" aria-expanded={showAllResults} className="text-primary underline" onClick={() => setShowAllResults(value => !value)}>
                    {showAllResults ? 'Show fewer results' : `View all ${message.answer_results.length} results →`}
                  </button>}
                </div>
              ) : message.answer_blocks?.length && message.status === 'success' ? (
                <div className="space-y-3">
                  {message.answer_intro && <p>{message.answer_intro}</p>}
                  {message.answer_blocks.map((block, i) => <p key={i}>
                    {block.text}{' '}
                    {block.citation_ids.map(id => <button key={id} type="button" aria-label={`View source ${id}`} onClick={() => openCitation(id)} className="text-primary underline px-0.5">[{id}]</button>)}
                  </p>)}
                </div>
              ) : renderText(message.text)}
            </div>
          )
        )}

        {hasContext && (
          <div className="mt-2 pt-2 border-t border-border/30">
            <button
              aria-expanded={showSources}
              onClick={() => setShowSources(!showSources)}
              className="flex items-center gap-1.5 text-xs text-muted-foreground hover:text-foreground transition-colors"
            >
              <Database className="w-3.5 h-3.5" />
              <span>{message.answer_results?.length ? 'Citations / Evidence' : message.citations?.length ? 'View all results and sources' : 'Evidence / Retrieved Knowledge'}</span>
              {showSources ? <ChevronUp className="w-3.5 h-3.5" /> : <ChevronDown className="w-3.5 h-3.5" />}
            </button>
            
            {showSources && (
              <div className="mt-2 bg-background/50 rounded p-2.5 text-xs space-y-3 overflow-x-auto">
                <p>Evidence for <span className="font-medium">{message.context?.retrieval?.entity?.name ?? message.context?.routing?.entity}</span></p>
                <EvidenceRecords records={message.context?.retrieval?.results ?? []} citations={message.citations} focusedRecord={focusedRecord} focusRequest={focusRequest} />
              </div>
            )}
          </div>
        )}

        {message.status === 'network_error' && (
          <div className="mt-2 text-xs text-destructive font-medium bg-destructive/10 p-2.5 rounded border border-destructive/20 flex flex-col gap-2">
            <span>{message.text || message.error || "A network error occurred."}</span>
            {onRetry && (
              <button 
                onClick={onRetry}
                className="self-start text-[11px] bg-background border border-border px-2 py-1 rounded hover:bg-muted transition-colors text-foreground"
              >
                Retry
              </button>
            )}
          </div>
        )}
      </div>
    </div>
  );
};
