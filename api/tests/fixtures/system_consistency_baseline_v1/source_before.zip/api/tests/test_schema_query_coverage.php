<?php
$_SERVER['REQUEST_METHOD'] = 'CLI';

// Use live ArcadeDB or environment
if (!getenv('ARCADE_URL')) {
    putenv("ARCADE_URL=http://localhost:2480");
}
echo "Set ARCADE_URL=" . getenv('ARCADE_URL') . "\n";
require_once dirname(__DIR__) . '/core/ChatbotOrchestrator.php';
global $ARCADE_URL;
echo "Global ARCADE_URL=" . $ARCADE_URL . "\n";
echo "Running Schema Query Coverage Tests...\n";
$passed = 0;
$failed = 0;

function assertCoverage($question, $expectedIntent, $expectedEntity) {
    global $passed, $failed;
    $res = ChatbotOrchestrator::process($question);
    
    // We only check if the router resolved it to the expected intent and entity.
    // Given the DB might not be populated in testing exactly as prod, we allow 'entity_not_found', 'no_data', 'success'.
    if ($res['status'] === 'success' || $res['status'] === 'no_data' || $res['status'] === 'entity_not_found') {
        if (isset($res['routing'])) {
            $routing = (array)$res['routing'];
            if ($routing['intent'] === $expectedIntent && $routing['entity_type'] === $expectedEntity) {
                echo "[PASS] $question -> $expectedIntent ($expectedEntity)\n";
                $passed++;
                return;
            } else {
                echo "[FAIL] $question -> Expected $expectedIntent ($expectedEntity), got " . $routing['intent'] . " (" . $routing['entity_type'] . ")\n";
            }
        } else {
            echo "[FAIL] $question -> Missing routing data in response\n";
        }
    } else {
        if ($res['status'] === 'entity_not_found') {
            // Still passed if it couldn't find entity but it didn't crash
            echo "[PASS-NO-ENTITY] $question\n";
            $passed++;
            return;
        }
        echo "[FAIL] $question -> Status: " . $res['status'] . "\n";
    }
    $failed++;
}

// 1. Compound -> Toxic Substance
assertCoverage("Which toxic substances does Croton tiglium contain?", 'compound_toxicity', 'Compound');
assertCoverage("Which compounds contain Aconitine?", 'toxic_substance_compound', 'Toxic_Substance');

// 2. Process / Media
assertCoverage("What media are used for Mardana?", 'process_media', 'Shodhana_Method');
assertCoverage("Which compounds undergo Mardana?", 'process_compound', 'Shodhana_Method');

// 3. Purified Compound / Indication
assertCoverage("What diseases does Shodhita Gunja treat?", 'purified_compound_disease', 'Purified_Compound');
assertCoverage("Which purified compounds treat Fever?", 'indication_compound', 'Indication');

// 4. Disease -> Symptoms / Dosha / Assessment
assertCoverage("What are the symptoms of Alopecia?", 'disease_symptoms', 'Disease');
assertCoverage("What therapies are used for Alopecia?", 'disease_therapy', 'Disease');
assertCoverage("What dosha imbalance is linked to Alopecia?", 'disease_dosha', 'Disease');
assertCoverage("What assessment parameters are used for Alopecia?", 'disease_assessment', 'Disease');
assertCoverage("Which diseases have Kandu?", 'symptoms_disease', 'Symptoms');
assertCoverage("Which diseases use Vamana therapy?", 'therapy_disease', 'Therapy');

// 5. Formulation
assertCoverage("Which formulations are used for Alopecia?", 'disease_formulation', 'Disease');
assertCoverage("Which diseases are treated by Triphala Guggulu?", 'formulation_disease', 'Formulation');

// 6. Integrated Compound -> Disease (Forward / Inverse)
assertCoverage("What diseases are treated by the purified compound from Croton tiglium?", 'integrated_compound_disease', 'Compound');
assertCoverage("Which compounds are purified to treat Alopecia?", 'integrated_disease_compound', 'Disease');

echo "\n--- SUMMARY ---\n";
echo "Passed: $passed\n";
echo "Failed: $failed\n";

if ($failed > 0) {
    exit(1);
}
exit(0);
