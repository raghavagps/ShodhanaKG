﻿<?php
// Ensure servers are running
$mockPort = 8086;
$apiPort = 8085;

$mockUrl = "http://localhost:{$mockPort}";
@file_get_contents($mockUrl);
if (!isset($http_response_header) || strpos($http_response_header[0], '200') === false) {
    pclose(popen("start \"\" /B php -S localhost:{$mockPort} " . __DIR__ . "/mock_ollama.php", "r"));
    sleep(1);
}

$apiUrl = "http://localhost:{$apiPort}/health.php";
@file_get_contents($apiUrl);
if (!isset($http_response_header) || strpos($http_response_header[0], '200') === false) {
    pclose(popen("set OLLAMA_BASE_URL=http://localhost:{$mockPort}&& set OLLAMA_TIMEOUT=1&& start \"\" /B php -S localhost:{$apiPort} -t .", "r"));
    sleep(2);
}

function runExtendedTest(string $question, ?array $mockLlmResponse, string $expectedStatus, ?callable $additionalChecks = null, ?array $customPayload = null) {
    if ($mockLlmResponse !== null) {
        file_put_contents(__DIR__ . '/mock_response.json', json_encode($mockLlmResponse));
    } else {
        @unlink(__DIR__ . '/mock_response.json');
    }
    
    $payload = $customPayload !== null ? json_encode($customPayload) : json_encode(['question' => $question]);
    
    $contextOptions = [
        'http' => [
            'method' => 'POST',
            'header' => 'Content-Type: application/json',
            'content' => $payload,
            'ignore_errors' => true
        ]
    ];
    
    $context = stream_context_create($contextOptions);
    $stdout = @file_get_contents("http://localhost:8085/api/chatbot_response.php", false, $context);
    if (strpos((string)$stdout, '<html') !== false || !$stdout) {
        $stdout = @file_get_contents("http://localhost:8085/chatbot_response.php", false, $context);
    }
    
    $jsonStart = strpos((string)$stdout, '{');
    if ($jsonStart !== false) {
        $result = json_decode(substr($stdout, $jsonStart), true);
    } else {
        $result = null;
    }
    
    echo "Testing: '$question' ... ";
    
    if (!$result) {
        echo "[FAIL] Could not parse JSON response\n";
        echo "STDOUT: $stdout\n";
        return false;
    }
    
    if ($result['status'] !== $expectedStatus) {
        echo "[FAIL] Expected status '$expectedStatus', got '{$result['status']}'\n";
        return false;
    }
    
    if ($additionalChecks) {
        if (!$additionalChecks($result)) {
            echo "[FAIL] Additional checks failed.\n";
            return false;
        }
    }
    
    echo "[PASS] Status: {$result['status']}\n";
    return true;
}

$allPass = true;
echo "=== ShodhanaKG Inverse Semantic Routing Tests ===\n\n";

// 1. Process -> Media Tests
$allPass = runExtendedTest("Name any 5 media used for Mardana Shodhana.", null, 'success') && $allPass;
$allPass = runExtendedTest("Name any media used for Nirvapa.", null, 'success') && $allPass;

// 2. Process -> Media Hallucination Test
$allPass = runExtendedTest("Name any 5 media used for Mardana Shodhana.", ['text' => 'It uses Asthma, which is completely fake.'], 'grounding_error') && $allPass;

// 4. Indication -> Purified Compound Tests
$allPass = runExtendedTest("Which purified compound treats fever?", null, 'success') && $allPass;

// 5. Indication -> Purified Compound Hallucination Test
$allPass = runExtendedTest("Which purified compound treats fever?", ['text' => 'It treats fever using Copper'], 'grounding_error') && $allPass;

// 6. No-Data Isolation for Indications
// Find a disease without a purified compound treating it
$allPass = runExtendedTest("Which purified compound treats Acute Prolapsed Inter-Vertebral Disc?", null, 'no_data') && $allPass;

if ($allPass) {
    echo "\n[PASS] All inverse semantic tests passed successfully.\n";
    exit(0);
} else {
    echo "\n[FAIL] Some inverse semantic tests failed.\n";
    exit(1);
}

