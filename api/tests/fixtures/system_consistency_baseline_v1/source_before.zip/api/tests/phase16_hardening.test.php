<?php
require_once __DIR__ . '/../config.php';
require_once __DIR__ . '/../db.php';
require_once __DIR__ . '/../core/ChatbotOrchestrator.php';
require_once __DIR__ . '/../core/EntityResolver.php';

function test_phase16_hardening() {
    echo "Starting Phase 16 - Provenance Hardening & Final Regression Test...\n";
    $allPass = true;

    // Helper to print test result
    $assert = function($condition, $testName) use (&$allPass) {
        if ($condition) {
            echo "PASS: $testName\n";
        } else {
            echo "FAIL: $testName\n";
            $allPass = false;
        }
    };

    // 1. Dysureia (Partial Path) should NOT contain 'Unknown Compound' or 'Unknown Method' placeholders
    $response = ChatbotOrchestrator::process("Which purified compounds are used for Dysureia?");
    $assert($response['status'] === 'success', "Dysureia routing success");
    
    $results = $response['retrieval']['results'] ?? [];
    $hasPraval = false;
    $hasUnknownCompound = false;
    $hasUnknownMethod = false;
    $hasNullMethod = false;

    foreach ($results as $res) {
        if (($res['purified_compound'] ?? '') === 'Praval Bhasma') {
            $hasPraval = true;
        }
        if (($res['compound'] ?? '') === 'Unknown Compound') {
            $hasUnknownCompound = true;
        }
        if (($res['shodhana_method'] ?? '') === 'Unknown Method') {
            $hasUnknownMethod = true;
        }
        if (array_key_exists('shodhana_method', $res) && $res['shodhana_method'] === null) {
            $hasNullMethod = true;
        }
    }
    
    $assert($hasPraval, "Dysureia (Praval Bhasma) fetched successfully");
    $assert(!$hasUnknownCompound, "Dysureia response contains no 'Unknown Compound' literal");
    $assert(!$hasUnknownMethod, "Dysureia response contains no 'Unknown Method' literal");
    $assert($hasNullMethod, "Dysureia response contains structural null for missing path elements");

    // 2. Malicious fuzzy-resolution inputs (Security)
    $maliciousQueries = [
        "What are the Symptoms of <script>alert(1)</script>?",
        "What are the Symptoms of ../../etc/passwd?",
        "What are the Symptoms of OR 1=1?",
        "What are the Symptoms of " . str_repeat("A", 1000) . "?"
    ];

    foreach ($maliciousQueries as $q) {
        $secRes = ChatbotOrchestrator::process($q);
        // It shouldn't crash or throw a raw exception, and it shouldn't execute anything malicious
        $assert(isset($secRes['status']), "Malicious fuzzy resolution handled gracefully: " . substr($q, 0, 50));
    }

    // 3. Complete integrated path vs Cartesian product (Diabetes Mellitus)
    $diabetesRes = ChatbotOrchestrator::process("Which purified compounds are used for Diabetes Mellitus?");
    $assert($diabetesRes['status'] === 'success', "Diabetes Mellitus integration query success");
    
    $diabResults = $diabetesRes['retrieval']['results'] ?? [];
    $hasCorrelatedProps = true;
    foreach ($diabResults as $dres) {
        if (!isset($dres['properties'])) {
            $hasCorrelatedProps = false;
        }
        if (($dres['compound'] ?? '') === 'Unknown Compound' || ($dres['shodhana_method'] ?? '') === 'Unknown Method') {
            $assert(false, "Diabetes Mellitus result contains placeholder 'Unknown ...'");
        }
    }
    $assert($hasCorrelatedProps, "Diabetes Mellitus results contain correlated provenance properties");

    if ($allPass) {
        echo "ALL TESTS PASSED: Phase 16 Hardening\n";
    } else {
        echo "SOME TESTS FAILED in Phase 16 Hardening\n";
        exit(1);
    }
}

test_phase16_hardening();
