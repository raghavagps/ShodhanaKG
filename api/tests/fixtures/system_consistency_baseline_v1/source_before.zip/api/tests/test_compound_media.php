<?php
error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE & ~E_WARNING);
require_once dirname(__DIR__) . '/config.php';

// Helper to simulate calling the API
function call_api($compound, $debug = false) {
    $_GET['compound'] = $compound;
    if ($debug) $_GET['debug'] = '1';
    else unset($_GET['debug']);
    
    ob_start();
    // Use an isolated scope to avoid require_once issues if we call it multiple times
    // Wait, since compound_media uses exit, we must use file_get_contents to the local dev server
    // Actually, calling the script via command line is safer
    $scriptPath = dirname(__DIR__) . '/compound_media.php';
    $cmd = 'php -r "parse_str(\'compound=' . urlencode($compound) . ($debug ? '&debug=1' : '') . '\', $_GET); require \'' . $scriptPath . '\';"';
    $output = shell_exec($cmd);
    
    $jsonStart = strpos($output, '{');
    if ($jsonStart !== false) {
        $output = substr($output, $jsonStart);
    }
    
    return json_decode($output, true);
}

$passed = true;

// 1. Valid Compound Test
echo "Running test: Valid Compound (Croton tiglium Linn.)\n";
$json = call_api('Croton tiglium Linn.');

if (!$json || $json['status'] !== 'success') {
    echo "FAIL: API did not return success status.\n";
    $passed = false;
}

if ($json['entity']['name'] !== 'Croton tiglium Linn.') {
    echo "FAIL: Entity name mismatch.\n";
    $passed = false;
}

if ($json['path'] !== ['Compound', 'UNDERGOES', 'Shodhana_Method', 'USES_MEDIA', 'Media']) {
    echo "FAIL: Graph pattern mismatch.\n";
    $passed = false;
}

if (count($json['results']) !== 4) {
    echo "FAIL: Expected exactly 4 unique valid records for Croton tiglium, got " . count($json['results']) . ".\n";
    $passed = false;
} else {
    // Validate property normalization
    foreach ($json['results'] as $res) {
        if (!isset($res['properties']['procedure']) || !isset($res['properties']['pubmed_id']) || !isset($res['properties']['doi'])) {
            echo "FAIL: Missing canonical properties block in result.\n";
            $passed = false;
        }
    }
}

// 2. Compare against fixture
$fixturePath = __DIR__ . '/fixture_croton_tiglium.json';
if (file_exists($fixturePath)) {
    $fixtureContent = file_get_contents($fixturePath);
    $jsonStart = strpos($fixtureContent, '{');
    if ($jsonStart !== false) {
        $fixtureContent = substr($fixtureContent, $jsonStart);
    }
    $fixture = json_decode($fixtureContent, true);
    
    // Compare json structurally
    if ($json !== $fixture) {
        echo "FAIL: Output does not exactly match fixture_croton_tiglium.json\n";
        $passed = false;
    }
} else {
    echo "FAIL: Fixture file not found.\n";
    $passed = false;
}

// 3. Non-existent compound test
echo "Running test: Non-existent Compound\n";
$jsonMissing = call_api('Fake Compound 123');

if ($jsonMissing['status'] !== 'no_data') {
    echo "FAIL: API did not return 'no_data' for missing compound.\n";
    $passed = false;
}

if ($passed) {
    echo "ALL TESTS PASSED.\n";
    exit(0);
} else {
    echo "TESTS FAILED.\n";
    exit(1);
}
