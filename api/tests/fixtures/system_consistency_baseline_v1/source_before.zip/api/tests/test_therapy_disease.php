<?php
require_once __DIR__ . '/../core/QuestionRouter.php';
require_once __DIR__ . '/../disease_therapy.php';
require_once __DIR__ . '/../therapy_disease.php';

echo "Testing disease/therapy endpoints and routing...\n\n";

$disease_queries = [
    "What therapies are used to treat Alopecia?",
    "Which therapies are used to treat Alopecia?",
    "Alopecia is treated by which therapy?",
    "Which therapies treat Alopecia?"
];

foreach ($disease_queries as $q) {
    $intent = QuestionRouter::route($q);
    if ($intent['primary'] === 'disease_therapy') {
        echo "[PASS] Query correctly routed: $q\n";
    } else {
        echo "[FAIL] Query failed to route to disease_therapy (got {$intent['primary']}): $q\n";
    }
}

$therapy_queries = [
    "Which diseases does Panchakarma treat?",
    "What diseases are treated by Panchakarma?",
    "Which diseases does this therapy treat?"
];

foreach ($therapy_queries as $q) {
    $intent = QuestionRouter::route($q);
    if (isset($intent['routing']['endpoint']) && $intent['routing']['endpoint'] === 'therapy_disease') {
        echo "[PASS] Query correctly routed: $q\n";
    } else {
        echo "[FAIL] Query failed to route to therapy_disease (got " . (isset($intent['routing']['endpoint']) ? $intent['routing']['endpoint'] : '') . "): $q\n";
    }
}

echo "\nTesting cancer (unknown entity)...\n";
$intent = QuestionRouter::route("Which therapies treat Cancer?");
$res_unk = execute_disease_therapy('Cancer', false);
if ($res_unk['status'] === 'entity_not_found') {
    echo "[PASS] Cancer correctly rejected as entity_not_found.\n";
} else {
    echo "[FAIL] Cancer handling failed: " . json_encode($res_unk) . "\n";
}

echo "\nDone testing therapy_disease.\n";
