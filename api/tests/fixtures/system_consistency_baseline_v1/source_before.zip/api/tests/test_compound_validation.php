<?php
error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE & ~E_WARNING);
require_once dirname(__DIR__) . '/config.php';

// Helper to simulate calling the API
function call_api($compound, $debug = false) {
    $scriptPath = dirname(__DIR__) . '/compound_validation.php';
    $cmd = 'php -r "parse_str(\'compound=' . urlencode($compound) . ($debug ? '&debug=1' : '') . '\', $_GET); require \'' . $scriptPath . '\';"';
    $output = shell_exec($cmd);
    
    $jsonStart = strpos($output, '{');
    if ($jsonStart !== false) {
        $output = substr($output, $jsonStart);
    }
    
    return json_decode($output, true);
}

$passed = true;

// 1. Valid Compound Test
echo "Running test: Valid Compound (Croton tiglium Linn.)\n";
$json = call_api('Croton tiglium Linn.');

if (!$json || $json['status'] !== 'success') {
    echo "FAIL: API did not return success status.\n";
    $passed = false;
}

if ($json['entity']['name'] !== 'Croton tiglium Linn.') {
    echo "FAIL: Entity name mismatch.\n";
    $passed = false;
}

if ($json['path'] !== ['Compound', 'UNDERGOES', 'Shodhana_Method', 'VALIDATED_BY', 'Confirmation_Study']) {
    echo "FAIL: Graph pattern mismatch.\n";
    $passed = false;
}

if (count($json['results']) !== 6) {
    echo "FAIL: Expected exactly 6 unique valid records for Croton tiglium, got " . count($json['results']) . ".\n";
    $passed = false;
} else {
    // Validate property normalization and safety evidence
    $hasSafetyEvidence = false;
    foreach ($json['results'] as $res) {
        if (!isset($res['validation_properties']['procedure']) || !isset($res['validation_properties']['pubmed_id']) || !isset($res['validation_properties']['doi'])) {
            echo "FAIL: Missing canonical validation_properties block in result.\n";
            $passed = false;
        }
        if (isset($res['safety_evidence'])) {
            $hasSafetyEvidence = true;
            if (!isset($res['safety_evidence']['target_entity']) || !isset($res['safety_evidence']['result'])) {
                echo "FAIL: safety_evidence block is missing required keys.\n";
                $passed = false;
            }
        }
    }
    
    if (!$hasSafetyEvidence) {
        echo "FAIL: Expected at least one result to contain safety_evidence.\n";
        $passed = false;
    }
}

// 2. Compare against fixture
$fixturePath = __DIR__ . '/fixture_croton_validation.json';
if (file_exists($fixturePath)) {
    $fixtureContent = file_get_contents($fixturePath);
    $jsonStart = strpos($fixtureContent, '{');
    if ($jsonStart !== false) {
        $fixtureContent = substr($fixtureContent, $jsonStart);
    }
    $fixture = json_decode($fixtureContent, true);
    
    // Compare json structurally
    if ($json !== $fixture) {
        echo "FAIL: Output does not exactly match fixture_croton_validation.json\n";
        $passed = false;
    }
} else {
    echo "FAIL: Fixture file not found.\n";
    $passed = false;
}

// 3. Non-existent compound test
echo "Running test: Non-existent Compound\n";
$jsonMissing = call_api('Fake Compound 123');

if ($jsonMissing['status'] !== 'no_data') {
    echo "FAIL: API did not return 'no_data' for missing compound.\n";
    $passed = false;
}

if ($passed) {
    echo "ALL TESTS PASSED.\n";
    exit(0);
} else {
    echo "TESTS FAILED.\n";
    exit(1);
}
