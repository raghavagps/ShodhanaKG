<?php
error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE & ~E_WARNING);
require_once dirname(__DIR__) . '/config.php';

$compounds = ['Croton tiglium Linn.', 'Copper', 'Datura metel L.', 'Zinc'];
$endpoints = [
    'media' => '/compound_media.php',
    'validation' => '/compound_validation.php'
];

$passed = true;
$matrix = [];

// Helper to simulate calling the API
function call_api($endpoint, $compound, $debug = true) {
    $scriptPath = dirname(__DIR__) . $endpoint;
    $cmd = 'php -r "parse_str(\'compound=' . urlencode($compound) . ($debug ? '&debug=1' : '') . '\', $_GET); require \'' . $scriptPath . '\';"';
    $output = shell_exec($cmd);
    
    $jsonStart = strpos($output, '{');
    if ($jsonStart !== false) {
        $output = substr($output, $jsonStart);
    }
    
    return json_decode($output, true);
}

foreach ($compounds as $compound) {
    $safeName = strtolower(str_replace([' ', '.'], ['_', ''], $compound));
    
    foreach ($endpoints as $type => $endpoint) {
        echo "Testing $compound -> $type...\n";
        
        $json = call_api($endpoint, $compound, true);
        
        if (!$json || !isset($json['status'])) {
            echo "FAIL: API did not return a valid status for $compound ($type).\n";
            $passed = false;
            $matrix[] = [$compound, ucfirst($type), 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'FAIL (API Error)'];
            continue;
        }
        
        $fixturePath = __DIR__ . "/fixture_{$safeName}_{$type}.json";
        if (file_exists($fixturePath)) {
            $fixtureContent = file_get_contents($fixturePath);
            $jsonStart = strpos($fixtureContent, '{');
            if ($jsonStart !== false) {
                $fixtureContent = substr($fixtureContent, $jsonStart);
            }
            $fixture = json_decode($fixtureContent, true);
            
            // Compare results array specifically to avoid mismatching debug info run-to-run (like DB timing if it existed, though it doesn't currently)
            if ($json['results'] !== $fixture['results']) {
                echo "FAIL: Output does not exactly match $fixturePath\n";
                $passed = false;
                $matrix[] = [$compound, ucfirst($type), 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'FAIL (Mismatch)'];
                continue;
            }
        } else {
            echo "FAIL: Fixture file not found: $fixturePath\n";
            $passed = false;
            $matrix[] = [$compound, ucfirst($type), 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'FAIL (Missing Fixture)'];
            continue;
        }
        
        // Extract debug metrics
        $debug = isset($json['debug']) ? $json['debug'] : null;
        if ($debug) {
            $raw = $debug['raw_records'];
            $final = $debug['final_count'];
            $rejected = $debug['duplicates_filtered']; // This includes both duplicates and rejected cross-joins
            
            $matrix[] = [$compound, ucfirst($type), $final, $raw, $final, $rejected, $final, 'PASS'];
        } else {
            $matrix[] = [$compound, ucfirst($type), 'N/A', 'N/A', 'N/A', 'N/A', 'N/A', 'PASS (No Debug)'];
        }
        
        echo "  -> PASS\n";
    }
}

echo "\n--- VALIDATION MATRIX ---\n";
echo str_pad("Compound", 25) . " | " . str_pad("Pattern", 15) . " | " . str_pad("Expected", 10) . " | " . str_pad("Raw", 10) . " | " . str_pad("Valid", 10) . " | " . str_pad("Rejected", 10) . " | " . str_pad("Final", 10) . " | Status\n";
echo str_repeat("-", 120) . "\n";
foreach ($matrix as $row) {
    echo str_pad($row[0], 25) . " | " . str_pad($row[1], 15) . " | " . str_pad($row[2], 10) . " | " . str_pad($row[3], 10) . " | " . str_pad($row[4], 10) . " | " . str_pad($row[5], 10) . " | " . str_pad($row[6], 10) . " | {$row[7]}\n";
}
echo "\n";

if ($passed) {
    echo "ALL TESTS PASSED.\n";
    exit(0);
} else {
    echo "TESTS FAILED.\n";
    exit(1);
}
