<?php
error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE & ~E_WARNING);
require_once dirname(__DIR__) . '/config.php';

function call_api($compound, $debug = false) {
    $scriptPath = dirname(__DIR__) . '/compound_toxicity.php';
    $cmd = 'php -r "parse_str(\'compound=' . urlencode($compound) . ($debug ? '&debug=1' : '') . '\', $_GET); require \'' . $scriptPath . '\';"';
    $output = shell_exec($cmd);
    
    $jsonStart = strpos($output, '{');
    if ($jsonStart !== false) {
        $output = substr($output, $jsonStart);
    }
    
    return json_decode($output, true);
}

echo "=== TEST: CP-04 Compound -> Toxicity (CONTAINS) ===\n";
$passed = true;

// 1. Valid Compound Test
echo "Running test: Valid Compound (Croton tiglium Linn.)\n";
$json = call_api('Croton tiglium Linn.', true);

if (!$json || !in_array($json['status'], ['success', 'no_data'])) {
    echo "FAIL: API did not return success or no_data status.\n";
    if ($json) echo "Response: " . json_encode($json) . "\n";
    $passed = false;
} else {
    $count = isset($json['results']) ? count($json['results']) : 0;
    echo "SUCCESS: Retrieved $count toxicity elements for Croton tiglium Linn.\n";
    if (isset($json['debug'])) {
        echo "  Raw records: {$json['debug']['raw_records']}\n";
        echo "  Duplicates filtered: {$json['debug']['duplicates_filtered']}\n";
    }
}

// 2. Non-existent compound test
echo "Running test: Non-existent Compound\n";
$jsonMissing = call_api('Fake Compound 123');

if ($jsonMissing['status'] !== 'no_data') {
    echo "FAIL: API did not return 'no_data' for missing compound.\n";
    $passed = false;
}

if ($passed) {
    echo "ALL TESTS PASSED.\n";
    exit(0);
} else {
    echo "TESTS FAILED.\n";
    exit(1);
}
