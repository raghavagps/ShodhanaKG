<?php
require_once __DIR__ . '/../core/ChatbotOrchestrator.php';
require_once __DIR__ . '/../core/ResponseGenerator.php';
require_once __DIR__ . '/../db.php';

// Ensure mock ollama is running to simulate generation
$mockPort = 8082;
$mockUrl = "http://localhost:{$mockPort}";
@file_get_contents($mockUrl);
if (!isset($http_response_header)) {
    pclose(popen("start /B php -S localhost:{$mockPort} " . __DIR__ . "/mock_ollama.php", "r"));
    sleep(1);
}
putenv("OLLAMA_BASE_URL=http://localhost:{$mockPort}");

echo "=== Context Immutability Test ===\n";

$question = "What media is used for Copper?";

// 1. Supply a mock orchestrator output to avoid DB dependency
$originalContext = [
    'status' => 'success',
    'routing' => [
        'domain' => 'compound',
        'intent' => 'compound_media',
        'entity' => 'Copper',
        'entity_type' => 'Compound',
        'endpoint' => '/api/compound_media.php',
        'confidence' => 1,
        'needs_clarification' => false
    ],
    'retrieval' => [
        'status' => 'success',
        'path' => ['Compound', 'UNDERGOES', 'Shodhana_Method', 'USES_MEDIA', 'Media'],
        'results' => [
            [
                'method' => 'Samanya Shodhana',
                'media' => 'Cow Urine',
                'properties' => ['procedure' => 'Boiled for 3 hours']
            ]
        ]
    ]
];

// 2. Perform a strict deep copy of the original context
$strictCopyBeforeGeneration = unserialize(serialize($originalContext));

// 3. Run the generation pipeline
$mockResponse = ['text' => 'It uses Cow Milk.'];
file_put_contents(__DIR__ . '/mock_response.json', json_encode($mockResponse));

$generationResult = ResponseGenerator::generate($question, $originalContext);
@unlink(__DIR__ . '/mock_response.json');

// 4. In chatbot_response.php, the final API response contains the context directly.
// We must verify $strictCopyBeforeGeneration === $originalContext
if ($strictCopyBeforeGeneration === $originalContext) {
    echo "[PASS] STRICTLY VERIFIED: Context is strictly immutable.\n";
    echo "       The orchestrator response strictly matches the object passed through generation.\n";
    exit(0);
} else {
    echo "[FAIL] Context was mutated during the pipeline!\n";
    exit(1);
}
