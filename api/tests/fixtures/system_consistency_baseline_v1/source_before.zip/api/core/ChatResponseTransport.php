<?php
/** JSON and SSE share the same final status and evidence context. */
class ChatResponseTransport {
    public static function event(string $name, array $data): void {
        echo 'event: ' . $name . "\ndata: " . json_encode($data, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) . "\n\n";
        flush();
    }

    public static function respond(array $response, bool $stream): void {
        if (!$stream) {
            header('Content-Type: application/json');
            echo json_encode($response, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES);
            return;
        }
        self::headers();
        if (isset($response['context'])) self::event('context', $response['context']);
        self::event('message', ['chunk' => $response['answer'] ?? $response['message'] ?? '']);
        self::event('done', ['status' => $response['status'], 'answer' => $response['answer'] ?? $response['message'] ?? '']);
    }

    public static function headers(): void {
        header('Content-Type: text/event-stream');
        header('Cache-Control: no-cache');
        header('X-Accel-Buffering: no');
    }
}
