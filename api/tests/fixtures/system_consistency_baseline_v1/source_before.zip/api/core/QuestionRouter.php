<?php
require_once __DIR__ . '/EntityResolver.php';
require_once __DIR__ . '/GraphRetriever.php';
require_once __DIR__ . '/TraversalCatalog.php';
require_once __DIR__ . '/ConversationEntities.php';

class QuestionRouter {

    /**
     * Detects whether a question is written in a non-English language.
     * Checks for Devanagari Unicode script and common Romanised Hindi words.
     *
     * @param string $question Raw question string
     * @return bool True if non-English is detected
     */
    private static function isNonEnglish(string $question): bool {
        // Detect Devanagari script (Unicode block U+0900-U+097F)
        if (preg_match('/[\x{0900}-\x{097F}]/u', $question)) {
            return true;
        }

        // Detect common Romanised Hindi word patterns
        $hindiPatterns = [
            '/\bke liye\b/i', '/\bkaunsa\b/i', '/\bkaunse\b/i', '/\bkaun\b/i',
            '/\bkaise\b/i',   '/\bkab\b/i',    '/\bkahan\b/i',  '/\bkyun\b/i',
            '/\bkya\b/i',     '/\blakshan\b/i',
            '/\bhota hai\b/i','/\bhoti hai\b/i','/\bhain\b/i',
            '/\bkarta hai\b/i','/\bkarti hai\b/i',
            '/\bkis\b/i',     '/\bkisko\b/i',  '/\bkiski\b/i',
            '/\blekin\b/i',   '/\bnahin\b/i',  '/\bnahi\b/i',
            '/\brog\b/i',     '/\bilaj\b/i',   '/\bupchar\b/i',
            '/\baushadh\b/i', '/\bdavai\b/i',
        ];

        foreach ($hindiPatterns as $pattern) {
            if (preg_match($pattern, $question)) {
                return true;
            }
        }

        return false;
    }

    public static function route($question, $history = [], ?ConversationEntities $matcher = null) {
        $q = self::normalizeIntent($question);

        // English-only guard — reject non-English queries immediately
        if (self::isNonEnglish($question)) {
            return [
                'status'  => 'unsupported',
                'reason'  => 'language_not_supported',
                'message' => 'ShodhanaKG currently supports English language queries only. Please rephrase your question in English.',
                'routing' => (object)[],
            ];
        }

        if (preg_match('/\b(molecular weight|chemical formula|chemical structure|who discovered|history of|dosage|price|buy|guarantee)\b/i', $q)
            || preg_match('/\b(write|compose|generate)\b.*\b(poem|story|song)\b/i', $q)
            || preg_match('/^(please\s+|could you\s+|can you\s+)?(delete|drop|insert|update)\b/i', $q)) {
            return ['status' => 'unsupported', 'reason' => 'no_retrieval_pattern'];
        }

        if (preg_match('/\b(how (do|can|to) (i|we)|navigate|explorer|filter|help|about (this|the) (app|site|explorer)|what does (the|this))\b/i', $q)) {
            return [
                'status' => 'success',
                'routing' => [
                    'domain' => 'general',
                    'intent' => 'platform_help',
                    'entity' => null,
                    'entity_type' => null,
                    'endpoint' => null,
                    'confidence' => 0.9,
                    'needs_clarification' => false
                ]
            ];
        }
        
        $originalQ = trim($question);
        $matcher = $matcher ?? new ConversationEntities();
        $found = $matcher->find($originalQ);
        if (count($found['groups']) > 1) return ['status' => 'needs_clarification', 'reason' => 'multiple_entities'];
        $contextEntity = null; $contextQuestion = null;
        foreach ($history as $turn) {
            if (($turn['role'] ?? '') !== 'user') continue;
            $previous = self::normalizeIntent($turn['text']);
            $match = $matcher->find($turn['text']);
            if (count($match['groups']) > 1 || $match['unresolved']) {
                $contextEntity = null; $contextQuestion = null;
                continue;
            }
            if ($match['groups']) $contextEntity = ConversationEntities::select($match['groups'][0], $turn['text']);
            if ($contextEntity) {
                $intent = self::classifyIntentContextually($previous, $contextEntity['inferred_type']);
                if (self::getEndpointForIntent($contextEntity['inferred_type'], $intent)) $contextQuestion = $previous;
            }
        }
        $resolvedEntity = $found['groups'] ? ConversationEntities::select($found['groups'][0], $originalQ) : null;
        $followup = preg_match('/^(and\b|what about\b)|\b(it|its|this|that|they|them|these|those)\b/i', $originalQ);
        if (!$resolvedEntity && !$found['unresolved'] && $followup) $resolvedEntity = $contextEntity;
        if (!$resolvedEntity) {
            return ['status' => $found['unresolved'] && (preg_match('/\b(symptom|media|therap|formulat)/i', $q) || self::extractEntityCandidates($originalQ)) ? 'entity_not_found' : 'needs_clarification',
                'reason' => 'entity_ambiguous'];
        }
        if ($followup && $contextQuestion && !self::getEndpointForIntent($resolvedEntity['inferred_type'], self::classifyIntentContextually($q, $resolvedEntity['inferred_type']))) {
            $q = $contextQuestion;
        }

        $entityType = $resolvedEntity['inferred_type'];
        $entityName = isset($resolvedEntity['name']) ? $resolvedEntity['name'] : '';
        
        if (in_array($entityType, ['Shodhana_Method', 'Process'], true)
            && TraversalCatalog::intent($q, $entityType) !== null) {
            $otherType = $entityType === 'Process' ? 'Shodhana_Method' : 'Process';
            $other = EntityResolver::resolve($otherType, $entityName);
            if ($other && TraversalCatalog::intent($q, $otherType) !== null) {
                $explicitMethod = preg_match('/\bmethod\s+' . preg_quote($entityName, '/') . '\b/i', $question);
                $explicitProcess = preg_match('/\bprocess\s+' . preg_quote($entityName, '/') . '\b/i', $question);
                if (!$explicitMethod && !$explicitProcess) return ['status' => 'needs_clarification', 'reason' => 'entity_type_ambiguous'];
                $entityType = $explicitMethod ? 'Shodhana_Method' : 'Process';
            }
        }
        $intent = self::classifyIntentContextually($q, $entityType);
        
        if (!$intent) {
            return [
                'status' => 'needs_clarification',
                'reason' => 'intent_ambiguous',
                'debug_entity' => $entityName
            ];
        }
        
        $endpoint = self::getEndpointForIntent($entityType, $intent);
        if (!$endpoint) {
             if (str_ends_with($intent, '_general') || in_array($intent, ['disease', 'compound', 'process', 'media', 'general_info'])) {
                  return [
                     'status' => 'needs_clarification',
                     'reason' => 'intent_ambiguous',
                     'debug_entity' => $entityName
                 ];
             }
             return [
                'status' => 'unsupported',
                'reason' => 'no_retrieval_pattern',
                'debug_entityType' => $entityType,
                'debug_entityName' => $entityName,
                'debug_intent' => $intent
            ];
        }
        
        return [
            'status' => 'success',
            'routing' => [
                'domain' => strtolower($entityType),
                'intent' => $intent,
                'entity' => $entityName,
                'entity_type' => $entityType,
                'endpoint' => $endpoint,
                'confidence' => 0.9,
                'needs_clarification' => false
            ]
        ];
    }
    
    private static function normalizeIntent(string $question): string {
        $q = strtolower(trim($question));
        return preg_replace_callback('/\b[a-z]{6,}\b/', static function ($match) {
            foreach (['symptoms', 'therapies', 'formulations'] as $word) {
                if (levenshtein($match[0], $word) === 1) return $word;
            }
            return $match[0];
        }, $q);
    }

    private static function extractEntityCandidates($question) {
        $candidates = [];
        if (preg_match_all('/\b(?:of|for|about|in|on|with|to|by)\s+([a-zA-Z0-9\s\.\-]+?)(?=\?|,|\.|(?:\s+is\b)|\s*$)/i', $question, $matches)) {
            foreach ($matches[1] as $m) {
                $candidates[] = trim($m);
            }
        }
        
        if (preg_match('/^([a-zA-Z\s]+?),\s*(what|how|is|are|tell)/i', $question, $match)) {
            $candidates[] = trim($match[1]);
        }
        
        return $candidates;
    }
    
    private static function classifyIntentContextually($q, $entityType) {
        $addition = TraversalCatalog::intent($q, $entityType);
        if ($addition !== null) return $addition;
        if ($entityType === 'Process') return 'process_general';
                if ($entityType === 'Compound') {
            if (preg_match('/\b(purified form|purified forms|purified compound|derived|derivatives|produce)/i', $q)) return 'compound_purified_forms';
            // Priority 1: Explicit integrated/multi-hop intents
            if (preg_match('/\b(disease|diseases|condition|linked|treat|treats|treating|treat this disease|rog|bimari|ilaj|chikitsa|upayog)\b/i', $q)) return 'integrated_compound_disease';
            if (preg_match('/\b(complete\s+(shodhana|purification)\s+(process|procedure)|how\s+is\s+.*?\s+purified|how\s+is\s+.*?\s+subjected\s+to\s+shodhana|method\s+and\s+media|purification\s+(process|procedure)|purified\s+using\s+shodhana|shodhana\s+procedure)/i', $q)) return 'compound_shodhana_process';
            
            // Priority 2: Specific single-hop intents
            if (preg_match('/\\b(complete shodhana process|how is .* purified|purification process|purified using shodhana|shodhana procedure)/i', $q)) return 'compound_shodhana_process';
            if (preg_match('/\b(substances?|materials?)\b.*\b(purification|purify)\b/i', $q)) return 'compound_media';
            if (preg_match('/\b(media|medium|liquid|purified with|shodhana media|dravya)/i', $q)) return 'compound_media';
            if (preg_match('/\b(validat|confirm|stud|proof)/i', $q)) return 'compound_validation';
            if (preg_match('/\b(toxic|poison|harmful)/i', $q)) return 'compound_toxicity';
            if (preg_match('/\b(detoxif)/i', $q)) return 'compound_detoxification';
            if (preg_match('/\b(purif|produc|shodhit|undergo|shodhana|method)/i', $q)) return 'compound_purification';
            if (preg_match('/\b(therap|indicat|used for)/i', $q)) return 'compound_therapeutic_use';
            
            // Priority 3: Generic intent
            return 'compound_general';
        }
        
                if ($entityType === 'Toxic_Substance') {
            if (preg_match('/\b(shodhana|method|process|detoxif|remove)/i', $q)) return 'toxic_substance_method';
            if (preg_match('/\b(compound|contain|which)/i', $q)) return 'toxic_substance_compound';
            return 'toxic_substance_general';
        }
        
        if ($entityType === 'Purified_Compound') {
            if (preg_match('/\b(validat|confirm|stud|proof)/i', $q)) return 'purified_compound_validation';
            if (preg_match('/\b(indicat|disease|condition|treat|treats|used for|rog|bimari|ilaj|chikitsa|upayog)/i', $q)) return 'purified_compound_disease';
            if (preg_match('/\b(formulat|medicin|drug|churna|bhasma|vati|rasa|leha|ghrita|taila)/i', $q)) return 'purified_compound_formulation';
            if (preg_match('/\b(compound|raw|source|derived)/i', $q)) return 'purified_compound_source';
            return 'purified_compound_general';
        }
        
                if ($entityType === 'Confirmation_Study') {
            if (preg_match('/\b(method|process|shodhana)/i', $q)) return 'confirmation_study_method';
            if (preg_match('/\b(compound|purified|safe)/i', $q)) return 'confirmation_study_purified_compound';
            return 'confirmation_study_general';
        }
        if ($entityType === 'Ayurvedic_Diagnosis') {
            if (preg_match('/\b(disease|modern|match)/i', $q)) return 'ayurvedic_diagnosis_disease';
            return 'ayurvedic_diagnosis_general';
        }
        if ($entityType === 'Assessment_Parameter') {
            if (preg_match('/\b(disease|assess)/i', $q)) return 'assessment_disease';
            return 'assessment_general';
        }
        if ($entityType === 'Shodhana_Type') {
            if (preg_match('/\b(method|process|classif)/i', $q)) return 'classification_process';
            return 'classification_general';
        }
        if ($entityType === 'Disease') {
            if (preg_match('/\b(compound|purif|shodhit)/i', $q)) return 'integrated_disease_compound'; // integrated
            if (preg_match('/\b(symptom|sign|manifest|lakshan)/i', $q)) return 'disease_symptoms';
            if (preg_match('/\b(therap|treat|treats|cure|heal)\b.*\b(formulat|medicin|drug|preparation|churna|bhasma|vati)\b/i', $q) || preg_match('/\b(formulat|medicin|drug|preparation|churna|bhasma|vati)\b.*\b(therap|treat|treats|cure|heal)\b/i', $q)) return 'disease_formulation';
            if (preg_match('/\b(formulat|medicin|drug|preparation|churna|bhasma|vati)/i', $q)) return 'disease_formulation';
            if (preg_match('/\b(therap|treat|treats|cure|heal|is treated by)/i', $q)) return 'disease_therapy';
            if (preg_match('/\b(dosha|imbalance)/i', $q)) return 'disease_dosha';
            if (preg_match('/\b(assess|parameter|measure)/i', $q)) return 'disease_assessment';
            if (preg_match('/\b(ayurved|diagnosis|diagnos)/i', $q)) return 'disease_diagnosis';
            
            return 'disease_general';
        }
        
        if ($entityType === 'Indication') {
            if (preg_match('/\b(treat|treats|therapy|therapeutic|compound|purified|use|shodhit)/i', $q)) return 'indication_compound';
            return 'indication_general';
        }
        
        if ($entityType === 'Symptom') {
            if (preg_match('/\b(disease|condition|indicat)/i', $q)) return 'symptoms_disease';
            return 'symptoms_general';
        }

        if ($entityType === 'Therapy') {
            if (preg_match('/\b(disease|diseases|condition|indicat|used for|treat|treats|treating|cure|heal)\b/i', $q)) return 'therapy_disease';
            return 'therapy_general';
        }

                if ($entityType === 'Formulation' || $entityType === 'Ayurvedic_Formulation') {
            if (preg_match('/\b(disease|diseases|condition|indicat|used for|treat|treats|treating|cure|heal|rog|bimari|ilaj|chikitsa|upayog)\b/i', $q)) return 'formulation_disease';
            if (preg_match('/\b(compound|compounds|contain|contains|ingredient|ingredients|dravya)\b/i', $q)) return 'formulation_compound';
            if (preg_match('/\b(therapy|therapies|use|uses)\b/i', $q)) return 'formulation_therapy';
            return 'formulation_general';
        }

        if ($entityType === 'Dosha') {
            if (preg_match('/\b(disease|condition|indicat)/i', $q)) return 'dosha_disease';
            return 'dosha_general';
        }
        
                if ($entityType === 'Shodhana_Method') {
            if (preg_match('/\b(classif|type|category)/i', $q)) return 'process_classification';
            if (preg_match('/\b(purified compound|produce|result)/i', $q)) return 'process_purified_compound';
            if (preg_match('/\b(validat|confirm|stud|proof)/i', $q)) return 'shodhana_method_validation';
            if (preg_match('/\b(disease|diseases|condition|indicat|treat|treats|treating|cure|heal)/i', $q)) return 'therapy_disease';
            if (preg_match('/\b(media|medium|liquid|material|substance)/i', $q)) return 'process_media';
            if (preg_match('/\b(compound|purif|undergo|used for|produc)/i', $q)) return 'process_compound';
            return 'process_general';
        }

        if ($entityType === 'Media') {
            if (preg_match('/\b(compound|purif|undergo|shodhana|used|use|using|method)/i', $q)) return 'media_compound';
            return 'media_general';
        }
        
        return null;
    }
    
    private static function getEndpointForIntent($entityType, $intent) {
        $spec = TraversalCatalog::all()[$intent] ?? null;
        if ($spec && in_array($entityType, $spec['input'], true)) return $intent;
        $map = [
            'Compound' => [
                'compound_media' => 'compound_media',
                'compound_validation' => 'compound_validation',
                'compound_toxicity' => 'compound_toxicity',
                'compound_shodhana_process' => 'compound_shodhana_process',
                'compound_detoxification' => 'compound_detoxification',
                'compound_purification' => 'compound_purification',
                'compound_therapeutic_use' => 'compound_therapeutic_use',
                'compound_purified_forms' => 'compound_purified_forms',
                'integrated_compound_disease' => 'integrated_compound_disease'
            ],
            'Toxic_Substance' => [
                'toxic_substance_compound' => 'toxic_substance_compound',
                'toxic_substance_method' => 'toxic_substance_method'
            ],
            'Purified_Compound' => [
                'purified_compound_disease' => 'purified_compound_disease',
                'purified_compound_formulation' => 'purified_compound_formulation',
                'purified_compound_source' => 'purified_compound_source',
                'purified_compound_validation' => 'purified_compound_validation'
            ],
                          'Confirmation_Study' => [
                  'confirmation_study_method' => 'confirmation_study_method',
                  'confirmation_study_purified_compound' => 'confirmation_study_purified_compound'
              ],
              'Ayurvedic_Diagnosis' => [
                  'ayurvedic_diagnosis_disease' => 'ayurvedic_diagnosis_disease'
              ],
              'Assessment_Parameter' => [
                  'assessment_disease' => 'assessment_disease'
              ],
              'Shodhana_Type' => [
                  'classification_process' => 'classification_process'
              ],
              'Disease' => [
                'disease_symptoms' => 'disease_symptoms',
                'disease_therapy' => 'disease_therapy',
                'disease_formulation' => 'disease_formulation',
                'integrated_disease_compound' => 'integrated_disease_compound',
                'disease_dosha' => 'disease_dosha',
                'disease_diagnosis' => 'disease_diagnosis',
                'disease_assessment' => 'disease_assessment'
            ],
            'Indication' => [
                'indication_compound' => 'indication_compound'
            ],
            'Symptom' => [
                'symptoms_disease' => 'symptoms_disease'
            ],
            'Therapy' => [
                'therapy_disease' => 'therapy_disease'
            ],
            'Formulation' => [
                'formulation_disease' => 'formulation_disease',
                'formulation_compound' => 'formulation_compound',
                'formulation_therapy' => 'formulation_therapy'
            ],
            'Ayurvedic_Formulation' => [
                'formulation_disease' => 'formulation_disease',
                'formulation_compound' => 'formulation_compound',
                'formulation_therapy' => 'formulation_therapy'
            ],
            'Dosha' => [
                'dosha_disease' => 'dosha_disease'
            ],
            'Shodhana_Method' => [
                'process_media' => 'process_media',
                'shodhana_method_validation' => 'shodhana_method_validation',
                'therapy_disease' => 'therapy_disease',
                'process_compound' => 'process_compound',
                'process_purified_compound' => 'process_purified_compound',
                'process_classification' => 'process_classification'
            ],
            'Media' => [
                'media_compound' => 'media_compound'
            ]
        ];
        
        return isset($map[$entityType][$intent]) ? $map[$entityType][$intent] : null;
    }
}

