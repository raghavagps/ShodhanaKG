<?php
require_once __DIR__ . '/GraphRetriever.php';
require_once __DIR__ . '/EntityResolver.php';

/** Matches complete graph labels/aliases, never an arbitrary LIKE substring. */
final class ConversationEntities {
    public const TYPES = ['Compound', 'Disease', 'Indication', 'Shodhana_Method', 'Purified_Compound',
        'Media', 'Symptom', 'Therapy', 'Formulation', 'Toxic_Substance', 'Dosha', 'Ayurvedic_Diagnosis',
        'Assessment_Parameter', 'Process', 'Confirmation_Study', 'Shodhana_Type', 'Ayurvedic_Formulation'];
    private $labels = [];

    public static function normalize(string $text): string {
        return trim(preg_replace('/[^a-z0-9]+/', ' ', strtolower($text)));
    }

    public function __construct(?array $nodes = null) {
        if ($nodes === null) {
            $nodes = [];
            foreach (self::TYPES as $type) $nodes = array_merge($nodes, GraphRetriever::execute('SELECT FROM `' . $type . '`'));
        }
        foreach ($nodes as $node) {
            $type = $node['@type'];
            $node['inferred_type'] = $type;
            $node['rid'] = $node['@rid'];
            $node['name'] = vertex_label($node);
            foreach (label_fields_for_type($type) as $field) {
                $value = $node[trim($field, '`')] ?? '';
                if (!is_string($value) || trim($value) === '') continue;
                foreach (array_merge([$value], explode(',', $value)) as $alias) {
                    $label = self::normalize($alias);
                    if (strlen($label) < 3 || self::residual($label) === '') continue;
                    $this->labels[$label][$node['rid']] = $node;
                }
            }
        }
    }

    /** Remove only conversational/intent vocabulary before whole-name typo matching. */
    public static function residual(string $text): string {
        $stop = 'what which how is are was were do does did can could would should the a an and or of for about in on with to by from as at please tell show list me i we you it its this that they them these those now switch mean okay all have has during used use uses using associated linked recorded records graph available symptoms symptom signs sign therapies therapy treatments treatment treated treat formulations formulation media medium substances substance purification purify purified compounds compound disease diseases methods method process processes processed toxic toxicity validate validation studies study follow follows following former latter give exist does contain contains ingredients';
        $stop .= ' undergo undergoes detoxified detoxification shodhana';
        $words = explode(' ', self::normalize($text));
        return implode(' ', array_values(array_diff($words, explode(' ', $stop))));
    }

    public function find(string $question): array {
        $q = self::normalize($question);
        // In this phrase imbalance is an intent qualifier, not a second symptom.
        $q = preg_replace('/\bdosha imbalance\b/', 'dosha relation', $q);
        $hits = [];
        foreach ($this->labels as $label => $nodes) {
            if (preg_match_all('/(?<![a-z0-9])' . preg_quote($label, '/') . '(?![a-z0-9])/', $q, $matches, PREG_OFFSET_CAPTURE)) {
                foreach ($matches[0] as $match) $hits[] = ['start' => $match[1], 'length' => strlen($label), 'nodes' => $nodes];
            }
        }
        usort($hits, static function ($a, $b) { return $b['length'] <=> $a['length']; });
        $selected = []; $groups = [];
        foreach ($hits as $hit) {
            foreach ($selected as $previous) if ($hit['start'] < $previous['start'] + $previous['length'] && $previous['start'] < $hit['start'] + $hit['length']) continue 2;
            $selected[] = $hit;
            foreach ($hit['nodes'] as $node) $groups[self::normalize($node['name'])][$node['rid']] = $node;
        }
        if ($groups) return ['groups' => array_values($groups), 'unresolved' => false];
        $candidate = self::residual($q);
        if (strlen($candidate) < 4) return ['groups' => [], 'unresolved' => $candidate !== ''];
        $best = null; $near = [];
        foreach ($this->labels as $label => $nodes) {
            $length = max(strlen($candidate), strlen($label));
            $distance = levenshtein($candidate, $label);
            // A complete multiword botanical name may omit its author suffix.
            $prefix = count(explode(' ', $candidate)) >= 2 && strlen($candidate) >= 10 && strpos($label, $candidate . ' ') === 0;
            if (!$prefix && ($distance > 2 || $distance / $length > 0.25)) continue;
            $rank = $prefix ? 0 : $distance;
            if ($best === null || $rank < $best) { $best = $rank; $near = []; }
            if ($rank === $best) foreach ($nodes as $node) $near[self::normalize($node['name'])][$node['rid']] = $node;
        }
        return ['groups' => array_values($near), 'unresolved' => !$near];
    }

    public static function select(array $group, string $question): array {
        foreach ($group as $node) {
            $qualifier = $node['inferred_type'] === 'Process' ? 'process' : ($node['inferred_type'] === 'Shodhana_Method' ? 'method' : null);
            if ($qualifier && preg_match('/\b' . $qualifier . '\s+' . preg_quote($node['name'], '/') . '\b/i', $question)) return $node;
        }
        return reset($group);
    }
}
