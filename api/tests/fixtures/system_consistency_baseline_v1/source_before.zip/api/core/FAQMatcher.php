<?php

class FAQMatcher {
    
    private static $faqs = [
        [
            'pattern' => '/what is shadhanakg|what is shodhanakg/i',
            'answer' => 'ShodhanaKG is a comprehensive Knowledge Graph Explorer that visualizes Ayurvedic purification processes. It allows you to explore the relationships between raw poisonous compounds, their purification (Shodhana) methods, and the resulting therapeutic uses and formulations.'
        ],
        [
            'pattern' => '/what is shodhana\b/i',
            'answer' => 'Shodhana is a foundational Ayurvedic process of purification and detoxification. It involves treating toxic or raw natural substances (botanical or mineral) with specific media (like milk, cow urine, or herbal decoctions) using distinct processes (like boiling, frying, or trituration) to eliminate toxicity and enhance therapeutic efficacy.'
        ],
        [
            'pattern' => '/what is panchkarma|what is panchakarma/i',
            'answer' => 'Panchakarma (meaning "five actions") is a primary Ayurvedic detoxification and rejuvenation treatment program. It encompasses five major therapeutic procedures designed to clear toxins (Ama) from the body and balance the Doshas.'
        ],
        [
            'pattern' => '/what is ayurveda\b/i',
            'answer' => 'Ayurveda is a traditional system of medicine with historical roots in the Indian subcontinent. It focuses on balancing the body, mind, and spirit to promote health and prevent disease, often using natural herbs, minerals, dietary changes, and lifestyle practices.'
        ],
        [
            'pattern' => '/what are doshas\b|what is a dosha\b/i',
            'answer' => 'Doshas are the three fundamental bio-elements in Ayurveda: Vata (air and space), Pitta (fire and water), and Kapha (earth and water). Health is achieved when these three doshas are in balance, while imbalance leads to disease.'
        ],
        [
            'pattern' => '/difference between (a )?compound and (a )?formulation/i',
            'answer' => 'In ShodhanaKG, a **Compound** refers to a raw material (like Copper or Datura) that often undergoes purification. A **Formulation** refers to a finished, prepared medicine that may contain one or more purified compounds and is used to treat specific diseases.'
        ],
        [
            'pattern' => '/how to navigate|how to use( the)? website|how to use( the)? explorer/i',
            'answer' => "You can navigate ShodhanaKG using three main explorers:\n1. **Compound Explorer:** Search for a specific compound (e.g., Copper or Datura) to view its purification processes and toxicity.\n2. **Disease Explorer:** Search for a disease to see associated symptoms, formulations, and therapies.\n3. **Integrated Explorer:** View the full end-to-end path from a raw compound, through its purification, to its final therapeutic use for a specific disease."
        ],
        [
            'pattern' => '/how to export|how to save|export( the)? graph/i',
            'answer' => 'In any of the Explorers, you can click the **Export** button in the top right corner of the Graph View. You can export the current view as a PNG image, a JSON file containing the raw nodes and edges, or a CSV file for spreadsheet analysis.'
        ],
        [
            'pattern' => '/what (kinds of )?questions can( this)? chatbot answer/i',
            'answer' => 'I can answer specific questions about Ayurvedic compounds, their purification (Shodhana) media and processes, diseases, symptoms, and therapies based on the data in ShodhanaKG. You can ask things like "What media is used for Copper?" or "What are the symptoms of Alopecia?". Note that I cannot answer general knowledge questions outside of this domain.'
        ]
    ];

    public static function match(string $question): ?string {
        foreach (self::$faqs as $faq) {
            if (preg_match($faq['pattern'], $question)) {
                return $faq['answer'];
            }
        }
        return null;
    }
}
