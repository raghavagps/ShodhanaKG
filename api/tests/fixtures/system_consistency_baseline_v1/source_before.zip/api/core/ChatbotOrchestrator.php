<?php
require_once __DIR__ . '/QuestionRouter.php';

class ChatbotOrchestrator {
    
    private static $allowlist = [
        'compound_shodhana_process' => 'execute_compound_shodhana_process',
        'compound_media' => 'execute_compound_media',
        'compound_validation' => 'execute_compound_validation',
        'compound_toxicity' => 'execute_compound_toxicity',
        'compound_detoxification' => 'execute_compound_detoxification',
        'compound_purification' => 'execute_compound_purification',
        'compound_therapeutic_use' => 'execute_compound_therapeutic_use',
        'disease_symptoms' => 'execute_disease_symptoms',
        'disease_therapy' => 'execute_disease_therapy',
        'disease_formulation' => 'execute_disease_formulation',
        'integrated_compound_disease' => 'execute_integrated_compound_disease',
        'process_media' => 'execute_process_media',
          'shodhana_method_validation' => 'execute_shodhana_method_validation',
        'indication_compound' => 'execute_indication_compound',
        
        // New Schema Endpoints
        'toxic_substance_compound' => 'execute_toxic_substance_compound',
          'process_purified_compound' => 'execute_process_purified_compound',
          'confirmation_study_method' => 'execute_confirmation_study_method',
          'confirmation_study_purified_compound' => 'execute_confirmation_study_purified_compound',
          'compound_purified_forms' => 'execute_compound_purified_forms',
          'formulation_compound' => 'execute_formulation_compound',
          'ayurvedic_diagnosis_disease' => 'execute_ayurvedic_diagnosis_disease',
          'formulation_therapy' => 'execute_formulation_therapy',
          'assessment_disease' => 'execute_assessment_disease',
          'toxic_substance_method' => 'execute_toxic_substance_method',
          'process_classification' => 'execute_process_classification',
          'classification_process' => 'execute_classification_process',
        'purified_compound_disease' => 'execute_purified_compound_disease',
        'purified_compound_formulation' => 'execute_purified_compound_formulation',
        'purified_compound_source' => 'execute_purified_compound_source',
          'purified_compound_validation' => 'execute_purified_compound_validation',
        'integrated_disease_compound' => 'execute_integrated_disease_compound',
        'disease_dosha' => 'execute_disease_dosha',
        'disease_diagnosis' => 'execute_disease_diagnosis',
        'disease_assessment' => 'execute_disease_assessment',
        'symptoms_disease' => 'execute_symptoms_disease',
        'therapy_disease' => 'execute_therapy_disease',
        'formulation_disease' => 'execute_formulation_disease',
        'dosha_disease' => 'execute_dosha_disease',
        'process_compound' => 'execute_process_compound',
        'media_compound' => 'execute_media_compound',
        'therapy_formulation' => 'execute_therapy_formulation',
        'media_process' => 'execute_media_process',
        'shodhana_method_process' => 'execute_shodhana_method_process',
        'process_shodhana_method' => 'execute_process_shodhana_method',
        'purified_compound_process' => 'execute_purified_compound_process',
        'method_toxic_substance' => 'execute_method_toxic_substance',
        'process_next_process' => 'execute_process_next_process',
        'next_process_process' => 'execute_next_process_process',
        'provenance_compound_method_media' => 'execute_provenance_compound_method_media',
        'provenance_media_method_compound' => 'execute_provenance_media_method_compound',
        'provenance_disease_therapy_formulation' => 'execute_provenance_disease_therapy_formulation',
        'provenance_formulation_therapy_disease' => 'execute_provenance_formulation_therapy_disease'
    ];

    public static function process($question, $history = []) {
        $routing = QuestionRouter::route($question, $history);
        
        $status = $routing['status'];
        
        if ($status === 'needs_clarification') {
            return [
                'status' => 'needs_clarification',
                'reason' => isset($routing['reason']) ? $routing['reason'] : 'intent_ambiguous',
                'routing' => $routing['routing'] ?? (object)[],
                'message' => self::buildClarificationMessage($routing)
            ];
        }
        
        if ($status === 'unsupported') {
            return [
                'status' => 'unsupported',
                'reason' => isset($routing['reason']) ? $routing['reason'] : 'no_retrieval_pattern',
                'routing' => $routing['routing'] ?? (object)[],
                'message' => 'That question is outside the currently supported ShodhanaKG knowledge retrieval patterns.'
            ];
        }
        
        // Entity ambiguous due to not found
        if ($status === 'entity_not_found') {
            return [
                'status' => 'entity_not_found',
                'message' => 'The requested compound or disease could not be found in ShodhanaKG.'
            ];
        }
        
        // If router succeeded, we must execute the deterministic retrieval
        if ($status === 'success') {
            $endpoint = $routing['routing']['endpoint'];
            $entityName = $routing['routing']['entity'];
            
            if (!isset(self::$allowlist[$endpoint])) {
                return [
                    'status' => 'unsupported',
                    'reason' => 'invalid_retrieval_endpoint',
                    'routing' => $routing['routing'],
                    'message' => 'The requested endpoint is not allowlisted.'
                ];
            }
            
            $functionName = self::$allowlist[$endpoint];
            $endpointFile = __DIR__ . '/../' . $endpoint . '.php';
            
            if (!file_exists($endpointFile)) {
                return [
                    'status' => 'error',
                    'message' => 'Endpoint file not found.'
                ];
            }
            
            // Require the file which now contains the function definition
            require_once $endpointFile;
            
            if (!function_exists($functionName)) {
                return [
                    'status' => 'error',
                    'message' => 'Retrieval function not found in endpoint.'
                ];
            }
            
            try {
                // Execute the function
                $retrievalData = $functionName($entityName, false);
                
                // Determine no_data or error
                $finalStatus = 'success';
                if (isset($retrievalData['status']) && $retrievalData['status'] === 'error') {
                    $finalStatus = 'error';
                } else if (isset($retrievalData['status']) && $retrievalData['status'] === 'no_data') {
                    $finalStatus = 'no_data';
                } else if (isset($retrievalData['status']) && $retrievalData['status'] === 'entity_not_found') {
                    $finalStatus = 'entity_not_found';
                } else if (isset($retrievalData['results']) && empty($retrievalData['results'])) {
                    // Fallback check if the normalizer output an empty array but kept status 'success'
                    $finalStatus = 'no_data';
                    $retrievalData['status'] = 'no_data';
                }
                
                return [
                    'status' => $finalStatus,
                    'question' => $question,
                    'routing' => $routing['routing'],
                    'retrieval' => $retrievalData,
                    'reason' => $retrievalData['reason'] ?? null
                ];
                
            } catch (Exception $e) {
                return [
                    'status' => 'error',
                    'message' => 'Retrieval execution failed: ' . $e->getMessage()
                ];
            }
        }
        
        // Fallback for unknown router state
        return [
            'status' => 'error',
            'message' => 'Unknown routing status.'
        ];
    }
    
    private static function buildClarificationMessage($routing) {
        if (isset($routing['debug_entity'])) {
            return "What would you like to know about " . $routing['debug_entity'] . "?";
        }
        return "Could you please clarify your question?";
    }
}

