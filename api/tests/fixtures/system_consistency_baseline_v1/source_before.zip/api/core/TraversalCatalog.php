<?php
/** Schema-verified additions. Direction is relative to the input node. */
class TraversalCatalog {
    public static function all(): array {
        $step = static function ($edges, $direction, $types) {
            return ['edges' => (array)$edges, 'direction' => $direction, 'types' => (array)$types];
        };
        $method = ['Shodhana_Method', 'Process'];
        $treatment = ['TREATED_BY', 'PRE_TREATED_BY', 'POST_TREATED_BY'];
        return [
            'therapy_formulation' => ['input' => ['Therapy'], 'steps' => [$step('USES_FORMULATION', 'out', 'Formulation')]],
            'media_process' => ['input' => ['Media'], 'steps' => [$step('USES_MEDIA', 'in', $method)]],
            'shodhana_method_process' => ['input' => ['Shodhana_Method'], 'steps' => [$step('FOLLOWED_BY', 'out', 'Process')]],
            'process_shodhana_method' => ['input' => ['Process'], 'steps' => [$step('FOLLOWED_BY', 'in', 'Shodhana_Method')]],
            'purified_compound_process' => ['input' => ['Purified_Compound'], 'steps' => [$step('PRODUCES', 'in', $method)]],
            'method_toxic_substance' => ['input' => ['Shodhana_Method'], 'steps' => [$step('DETOXIFIES', 'out', 'Toxic_Substance')]],
            'process_next_process' => ['input' => ['Process'], 'steps' => [$step('FOLLOWED_BY', 'out', 'Process')]],
            'next_process_process' => ['input' => ['Process'], 'steps' => [$step('FOLLOWED_BY', 'in', 'Process')]],
            'provenance_compound_method_media' => ['input' => ['Compound'], 'steps' => [$step('UNDERGOES', 'out', 'Shodhana_Method'), $step('USES_MEDIA', 'out', 'Media')]],
            'provenance_media_method_compound' => ['input' => ['Media'], 'steps' => [$step('USES_MEDIA', 'in', 'Shodhana_Method'), $step('UNDERGOES', 'in', 'Compound')]],
            'provenance_disease_therapy_formulation' => ['input' => ['Disease'], 'steps' => [$step($treatment, 'out', 'Therapy'), $step('USES_FORMULATION', 'out', 'Formulation')]],
            'provenance_formulation_therapy_disease' => ['input' => ['Formulation'], 'steps' => [$step('USES_FORMULATION', 'in', 'Therapy'), $step($treatment, 'in', 'Disease')]],
        ];
    }

    public static function intent(string $q, string $type): ?string {
        $evidence = preg_match('/\b(evidence|provenance|same study|same publication|shared reference)\b/i', $q);
        if ($evidence) {
            if ($type === 'Compound' && preg_match('/\b(media|medium)\b/i', $q)) return 'provenance_compound_method_media';
            if ($type === 'Media' && preg_match('/\bcompounds?\b/i', $q)) return 'provenance_media_method_compound';
            if ($type === 'Disease' && preg_match('/\bformulations?\b/i', $q)) return 'provenance_disease_therapy_formulation';
            if ($type === 'Formulation' && preg_match('/\bdiseases?\b/i', $q)) return 'provenance_formulation_therapy_disease';
        }
        if ($type === 'Therapy' && preg_match('/\bformulations?\b/i', $q)) return 'therapy_formulation';
        if ($type === 'Media' && preg_match('/\b(methods?|process(?:es)?)\b/i', $q) && !preg_match('/\bcompounds?\b/i', $q)) return 'media_process';
        if ($type === 'Purified_Compound' && preg_match('/\b(methods?|process(?:es)?)\b/i', $q) && !preg_match('/\b(stud(?:y|ies)|validat\w*)\b/i', $q)) return 'purified_compound_process';
        if ($type === 'Shodhana_Method') {
            if (preg_match('/\b(detoxif\w*|toxic substances?|removes?)\b/i', $q)) return 'method_toxic_substance';
            if (preg_match('/\b(follows?|after|next|subsequent|followed by)\b/i', $q)) return 'shodhana_method_process';
        }
        if ($type === 'Process') {
            if (preg_match('/\b(before|previous|prior|precedes?|preceding)\b/i', $q) || preg_match('/\b(?:is|are)\s+followed\s+by\s+(?!what\b|which\b)/i', $q)) {
                return preg_match('/\bmethods?\b/i', $q) ? 'process_shodhana_method' : 'next_process_process';
            }
            if (preg_match('/\b(follows?|after|next|subsequent|followed by)\b/i', $q)) return 'process_next_process';
        }
        return null;
    }
}
