<?php

class LLMClient {
    public static function checkHealth(): bool {
        $baseUrl = isset($_ENV['OLLAMA_BASE_URL']) ? $_ENV['OLLAMA_BASE_URL'] : (getenv('OLLAMA_BASE_URL') !== false ? getenv('OLLAMA_BASE_URL') : 'http://127.0.0.1:11434');
        $url = rtrim($baseUrl, '/') . '/api/tags';
        $timeout = 5;

        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, min(5, $timeout));
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            curl_close($ch);
            return $response !== false && $httpCode === 200;
        } else {
            $context = stream_context_create(['http' => ['method' => 'GET', 'timeout' => $timeout, 'ignore_errors' => true]]);
            $response = @file_get_contents($url, false, $context);
            if ($response === false) return false;
            $httpCode = 200;
            $headers = function_exists('http_get_last_response_headers') ? http_get_last_response_headers() : @$http_response_header;
            if (count($headers) > 0 && preg_match('#HTTP/[0-9\.]+\s+([0-9]+)#', $headers[0], $m)) {
                $httpCode = intval($m[1]);
            }
            return $httpCode === 200;
        }
    }

    public static function generateStream(string $prompt, callable $onToken): array {
        $baseUrl = isset($_ENV['OLLAMA_BASE_URL']) ? $_ENV['OLLAMA_BASE_URL'] : (getenv('OLLAMA_BASE_URL') !== false ? getenv('OLLAMA_BASE_URL') : 'http://127.0.0.1:11434');
        $model   = isset($_ENV['OLLAMA_MODEL'])    ? $_ENV['OLLAMA_MODEL']    : (getenv('OLLAMA_MODEL')    !== false ? getenv('OLLAMA_MODEL')    : 'llama3.2');
        $timeout = 600;

        if (!function_exists('curl_init')) {
            $result = self::generate($prompt);
            if ($result['status'] === 'success') { $onToken($result['text']); }
            return $result;
        }

        $url = rtrim($baseUrl, '/') . '/api/generate';
        $payload = json_encode([
            'model'   => $model,
            'prompt'  => $prompt,
            'stream'  => true,
            'options' => ['temperature' => 0.0],
        ]);

        $fullText = '';
        $carry    = '';

        $ch = curl_init($url);
        curl_setopt($ch, CURLOPT_POST, true);
        curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
        curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
        curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, min(5, $timeout));
        curl_setopt($ch, CURLOPT_WRITEFUNCTION,
            function ($ch, string $data) use (&$carry, &$fullText, $onToken): int {
                $carry .= $data;
                $lines = explode("\n", $carry);
                $carry = (string) array_pop($lines);
                foreach ($lines as $line) {
                    if (trim($line) === '') continue;
                    $parsed = json_decode($line, true);
                    if (is_array($parsed) && isset($parsed['response'])) {
                        $chunk = $parsed['response'];
                        $fullText .= $chunk;
                        $onToken($chunk);
                    }
                }
                return strlen($data);
            }
        );

        $response = curl_exec($ch);
        $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
        $error = curl_error($ch);
        curl_close($ch);

        if ($response === false) { return ['status' => 'llm_error', 'message' => 'Ollama connection failed: ' . $error]; }
        if ($httpCode !== 200) { return ['status' => 'llm_error', 'message' => "Ollama returned HTTP $httpCode"]; }

        if (trim($carry) !== '') {
            $parsed = json_decode($carry, true);
            if (is_array($parsed) && isset($parsed['response'])) {
                $chunk = $parsed['response'];
                $fullText .= $chunk;
                $onToken($chunk);
            }
        }

        if (trim($fullText) === '') { return ['status' => 'llm_error', 'message' => 'Empty model response']; }
        return ['status' => 'success', 'text' => trim($fullText), 'model' => $model];
    }

    public static function generate(string $prompt, ?int $timeoutSeconds = null, bool $jsonMode = false, ?array $schema = null): array {
        $baseUrl = isset($_ENV['OLLAMA_BASE_URL']) ? $_ENV['OLLAMA_BASE_URL'] : (getenv('OLLAMA_BASE_URL') !== false ? getenv('OLLAMA_BASE_URL') : 'http://127.0.0.1:11434');
        $model = isset($_ENV['OLLAMA_MODEL']) ? $_ENV['OLLAMA_MODEL'] : (getenv('OLLAMA_MODEL') !== false ? getenv('OLLAMA_MODEL') : 'llama3.2');
        $timeout = $timeoutSeconds ?? (isset($_ENV['OLLAMA_TIMEOUT']) ? (int)$_ENV['OLLAMA_TIMEOUT'] : 120);
        $url = rtrim($baseUrl, '/') . '/api/generate';
        
        $payload = json_encode([
            'model' => $model,
            'prompt' => $prompt,
            'stream' => false,
            'format' => $schema ?? ($jsonMode ? 'json' : ''),
            'options' => ['temperature' => 0.0]
        ]);

        if (function_exists('curl_init')) {
            $ch = curl_init($url);
            curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
            curl_setopt($ch, CURLOPT_POST, true);
            curl_setopt($ch, CURLOPT_POSTFIELDS, $payload);
            curl_setopt($ch, CURLOPT_HTTPHEADER, ['Content-Type: application/json']);
            curl_setopt($ch, CURLOPT_TIMEOUT, $timeout);
            curl_setopt($ch, CURLOPT_CONNECTTIMEOUT, min(5, $timeout));
            $response = curl_exec($ch);
            $httpCode = curl_getinfo($ch, CURLINFO_HTTP_CODE);
            $error = curl_error($ch);
            curl_close($ch);
            if ($response === false) { return ['status' => 'llm_error', 'message' => 'Ollama connection failed: ' . $error]; }
            if ($httpCode !== 200) { return ['status' => 'llm_error', 'message' => "Ollama returned HTTP $httpCode"]; }
        } else {
            $context = stream_context_create(['http' => ['method' => 'POST', 'header' => "Content-Type: application/json\r\n", 'content' => $payload, 'timeout' => $timeout, 'ignore_errors' => true]]);
            $response = @file_get_contents($url, false, $context);
            if ($response === false) { return ['status' => 'llm_error', 'message' => 'Ollama connection failed via file_get_contents']; }
            $httpCode = 200;
            $headers = function_exists('http_get_last_response_headers') ? http_get_last_response_headers() : @$http_response_header;
            if (count($headers) > 0 && preg_match('#HTTP/[0-9\.]+\s+([0-9]+)#', $headers[0], $m)) { $httpCode = intval($m[1]); }
            if ($httpCode !== 200) { return ['status' => 'llm_error', 'message' => "Ollama returned HTTP $httpCode"]; }
        }

        $decoded = json_decode($response, true);
        if (!$decoded || !isset($decoded['response'])) { return ['status' => 'llm_error', 'message' => 'Malformed response from Ollama']; }
        if (trim($decoded['response']) === '') { return ['status' => 'llm_error', 'message' => 'Empty model response']; }
        return ['status' => 'success', 'text' => trim($decoded['response']), 'model' => $model];
    }
}
