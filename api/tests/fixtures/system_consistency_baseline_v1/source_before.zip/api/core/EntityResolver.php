<?php
require_once dirname(__DIR__) . '/db.php';
require_once dirname(__DIR__) . '/graph_service.php';

/**
 * Resolves a given entity string to its canonical node representation
 * in ArcadeDB.
 */
class EntityResolver {
    
    /**
     * Resolve entity by canonical name.
     * 
     * @param string $type The node class type (e.g., 'Compound', 'Disease')
     * @param string $name The requested name
     * @param array &$debugCollector Reference to debug array to capture telemetry
     * @return array|null Node data ['rid' => ..., 'name' => ...] or null if not found
     */
        public static function resolve($type, $name, &$debugCollector = null) {
        $fields = label_fields_for_type($type);
        
        $orConditions = [];
        foreach ($fields as $field) {
            $orConditions[] = "{$field}.toLowerCase() = :name";
        }
        $whereClause = implode(" OR ", $orConditions);
        
        $sql = "SELECT FROM `{$type}` WHERE {$whereClause} LIMIT 1";
        $params = ['name' => strtolower(trim($name))];
        
        if (is_array($debugCollector)) {
            if (!isset($debugCollector['sql_queries'])) $debugCollector['sql_queries'] = [];
            $debugCollector['sql_queries'][] = ['sql' => $sql, 'params' => $params];
        }
        
        $res = arcade_command($sql, 'sql', $params);
        
        if (empty($res['result'])) {
            return null;
        }
        
        $node = $res['result'][0];
        
        if (!isset($node['rid']) && isset($node['@rid'])) {
            $node['rid'] = $node['@rid'];
        }
        
        return $node;
    }

    public static function fuzzyResolve($type, $name, &$debugCollector = null) {
        $n = strtolower(trim($name));
        $genericTerms = [
            'shodhana', 'compound', 'compounds', 'disease', 'diseases', 
            'media', 'medium', 'process', 'processes', 'method', 'methods', 
            'therapy', 'therapies', 'symptom', 'Symptom', 'formulation', 
            'formulations', 'purified compound', 'purified compounds', 
            'toxic substance', 'ayurvedic diagnosis', 'assessment parameter', 'assessment parameters', 
            'dosha', 'doshas', 'drug', 'medicine'
        ];
        
        if (in_array($n, $genericTerms, true)) {
            return null; // Do not fuzzy match generic domain concepts to specific entities
        }

        $fields = label_fields_for_type($type);
        
        $orConds = [];
        foreach ($fields as $field) {
            $orConds[] = "{$field}.toLowerCase() LIKE :pattern";
        }
        $whereExpr = implode(' OR ', $orConds);
        
        $sql = "SELECT FROM `{$type}` WHERE {$whereExpr} LIMIT 1";
        $params = ['pattern' => '%' . strtolower(trim($name)) . '%'];
        
        if (is_array($debugCollector)) {
            if (!isset($debugCollector['sql_queries'])) $debugCollector['sql_queries'] = [];
            $debugCollector['sql_queries'][] = ['sql' => $sql, 'params' => $params];
        }
        
        $res = arcade_command($sql, 'sql', $params);
        
        if (empty($res['result'])) {
            // Fallback to Levenshtein distance on full list
            $coalesceExpr = "''";
            foreach (array_reverse($fields) as $field) {
                $coalesceExpr = "coalesce({$field}, {$coalesceExpr})";
            }
            
            $fallbackSql = "SELECT @rid, {$coalesceExpr} as name, @type FROM `{$type}`";
            $fallbackRes = arcade_command($fallbackSql, 'sql');
            
            if (empty($fallbackRes['result'])) {
                return null;
            }
            
            $bestMatch = null;
            $bestDist = -1;
            
            foreach ($fallbackRes['result'] as $rec) {
                $recName = strtolower(trim($rec['name'] ?? ''));
                if ($recName === '') continue;
                
                $dist = levenshtein($n, $recName);
                
                // Allowable distance based on string length
                $len = strlen($n);
                $allowed = ($len < 5) ? 1 : (($len < 8) ? 2 : 3);
                
                if ($dist <= $allowed && ($bestDist === -1 || $dist < $bestDist)) {
                    $bestDist = $dist;
                    $bestMatch = $rec;
                }
            }
            
            if (!$bestMatch) {
                return null;
            }
            
            $node = $bestMatch;
            
        } else {
            $node = $res['result'][0];
        }
        
        if (!isset($node['rid']) && isset($node['@rid'])) {
            $node['rid'] = $node['@rid'];
        }
        
        $actualName = vertex_label($node);
        if ($actualName !== '') {
            $node['name'] = $actualName;
        } else if (isset($node['name']) && trim($node['name']) !== '') {
            $node['name'] = trim($node['name']);
        } else {
            $node['name'] = trim($name);
        }
        
        if (is_array($debugCollector)) {
            $debugCollector['entity_resolution'] = $node;
        }
        
        return $node;
    }
}
