<?php

require_once __DIR__ . '/cors.php';
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/response.php';
require_once __DIR__ . '/graph_service.php';

api_handle_cors_preflight();

$method = isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : '';
if ($method !== 'GET') {
  api_fail('method_not_allowed', 'Use GET', 405);
}

$limit = min(max(isset($_GET['limit']) ? (int)$_GET['limit'] : 50, 1), 200);
$offset = max(isset($_GET['offset']) ? (int)$_GET['offset'] : 0, 0);

try {
  // Fetch only PurifiedCompounds that have direct disease bridge (USED_FOR_TREATMENT)
  $sql = "SELECT @rid, @type, id, name, description FROM Purified_Compound WHERE out('USED_FOR_TREATMENT').size() > 0 ORDER BY name ASC LIMIT $limit SKIP $offset";
  $res = arcade_command($sql, 'sql');
  $purifiedNodes = isset($res['result']) ? $res['result'] : array();

  $totalSql = "SELECT COUNT(*) AS cnt FROM Purified_Compound WHERE out('USED_FOR_TREATMENT').size() > 0";
  $totalRes = arcade_command($totalSql, 'sql');
  $totalResults = isset($totalRes['result']) ? $totalRes['result'] : array();
  $total = (int) (isset($totalResults[0]['cnt']) ? $totalResults[0]['cnt'] : 0);

  if (empty($purifiedNodes)) {
    api_ok(array('rows' => array(), 'total' => $total, 'limit' => $limit, 'offset' => $offset));
  }

  $pcRids = array();
  foreach ($purifiedNodes as $n) {
    if (isset($n['@rid'])) $pcRids[] = $n['@rid'];
  }
  $pcRidCsv = implode(',', $pcRids);

  // Fetch DERIEVED_FROM edges where @in = PurifiedCompound (Compound -> PurifiedCompound)
  $compoundMap = array(); // pcRid => [comRid, ...]
  if ($pcRidCsv) {
    $sql = sprintf(
      "SELECT @in AS com_rid, @out AS pc_rid FROM DERIEVED_FROM WHERE @out IN [%s] LIMIT %d",
      $pcRidCsv, $limit * 10
    );
    try {
      $res = arcade_command($sql, 'sql');
      $rows = isset($res['result']) ? $res['result'] : array();
      foreach ($rows as $row) {
        $pcRid = isset($row['pc_rid']) ? $row['pc_rid'] : '';
        $comRid = isset($row['com_rid']) ? $row['com_rid'] : '';
        if ($pcRid && $comRid) {
          if (!isset($compoundMap[$pcRid])) $compoundMap[$pcRid] = array();
          $compoundMap[$pcRid][] = $comRid;
        }
      }
    } catch (Exception $e) { /* skip */ }
  }

  // Fetch USED_FOR_TREATMENT edges where @out = PurifiedCompound
  $diseaseMap = array(); // pcRid => [diseaseRid, ...]
  if ($pcRidCsv) {
    $sql = sprintf(
      "SELECT @out AS pc_rid, @in AS dis_rid FROM USED_FOR_TREATMENT WHERE @out IN [%s] LIMIT %d",
      $pcRidCsv, $limit * 10
    );
    try {
      $res = arcade_command($sql, 'sql');
      $rows = isset($res['result']) ? $res['result'] : array();
      foreach ($rows as $row) {
        $pcRid = isset($row['pc_rid']) ? $row['pc_rid'] : '';
        $disRid = isset($row['dis_rid']) ? $row['dis_rid'] : '';
        if ($pcRid && $disRid) {
          if (!isset($diseaseMap[$pcRid])) $diseaseMap[$pcRid] = array();
          $diseaseMap[$pcRid][] = $disRid;
        }
      }
    } catch (Exception $e) { /* skip */ }
  }

  // Fetch USED_IN_FORMULATION edges where @out = PurifiedCompound
  $formulationMap = array(); // pcRid => [formRid, ...]
  if ($pcRidCsv) {
    $sql = sprintf(
      "SELECT @out AS pc_rid, @in AS form_rid FROM USED_IN_FORMULATION WHERE @out IN [%s] LIMIT %d",
      $pcRidCsv, $limit * 10
    );
    try {
      $res = arcade_command($sql, 'sql');
      $rows = isset($res['result']) ? $res['result'] : array();
      foreach ($rows as $row) {
        $pcRid = isset($row['pc_rid']) ? $row['pc_rid'] : '';
        $formRid = isset($row['form_rid']) ? $row['form_rid'] : '';
        if ($pcRid && $formRid) {
          if (!isset($formulationMap[$pcRid])) $formulationMap[$pcRid] = array();
          $formulationMap[$pcRid][] = $formRid;
        }
      }
    } catch (Exception $e) { /* skip */ }
  }

  // Collect all neighbor RIDs and fetch their labels
  $allNeighborRids = array();
  foreach ($compoundMap as $rids) { foreach ($rids as $r) { $allNeighborRids[$r] = true; } }
  foreach ($diseaseMap as $rids) { foreach ($rids as $r) { $allNeighborRids[$r] = true; } }
  foreach ($formulationMap as $rids) { foreach ($rids as $r) { $allNeighborRids[$r] = true; } }

  $neighborLabels = array();
  if (!empty($allNeighborRids)) {
    $nRidCsv = implode(',', array_keys($allNeighborRids));
    $neighborMap = fetch_vertex_map($nRidCsv);
    foreach ($neighborMap as $rid => $node) {
      $neighborLabels[$rid] = $node['label'];
    }
  }

  $rows = array();
  foreach ($purifiedNodes as $pc) {
    $rid = isset($pc['@rid']) ? $pc['@rid'] : '';
    $comRids = isset($compoundMap[$rid]) ? $compoundMap[$rid] : array();
    $disRids = isset($diseaseMap[$rid]) ? $diseaseMap[$rid] : array();
    $formRids = isset($formulationMap[$rid]) ? $formulationMap[$rid] : array();

    $compoundLabels = array();
    foreach ($comRids as $r) {
      $compoundLabels[] = isset($neighborLabels[$r]) ? $neighborLabels[$r] : $r;
    }
    $compoundLabels = array_values(array_unique($compoundLabels));

    $diseaseLabels = array();
    foreach ($disRids as $r) {
      $diseaseLabels[] = isset($neighborLabels[$r]) ? $neighborLabels[$r] : $r;
    }
    $diseaseLabels = array_values(array_unique($diseaseLabels));

    $formulationLabels = array();
    foreach ($formRids as $r) {
      $formulationLabels[] = isset($neighborLabels[$r]) ? $neighborLabels[$r] : $r;
    }
    $formulationLabels = array_values(array_unique($formulationLabels));

    $rows[] = array(
      'purifiedId' => isset($pc['id']) ? $pc['id'] : '',
      'purifiedLabel' => trim((string) (isset($pc['name']) ? $pc['name'] : '')),
      'purifiedDescription' => vertex_description($pc),
      'compoundIds' => $compoundLabels,
      'diseaseCount' => count($disRids),
      'formulationCount' => count($formRids),
      'diseaseLabels' => $diseaseLabels,
      'formulationLabels' => $formulationLabels,
    );
  }

  api_ok(array(
    'rows' => $rows,
    'total' => $total,
    'limit' => $limit,
    'offset' => $offset,
  ));
} catch (Exception $e) {
  api_fail('bridge_stats_failed', 'Bridge stats query failed', 500, array(
    'message' => $e->getMessage(),
  ));
}
