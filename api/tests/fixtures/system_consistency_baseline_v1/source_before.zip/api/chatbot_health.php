<?php
error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE & ~E_WARNING);
ini_set('display_errors', '0');
// api/chatbot_health.php
// Graph-answer readiness; Ollama is not required for constructed evidence answers.

require_once __DIR__ . '/cors.php';
require_once __DIR__ . '/db.php';
require_once __DIR__ . '/config.php';

if (function_exists('api_handle_cors_preflight')) {
    api_handle_cors_preflight();
}
header('Content-Type: application/json');

try {
    $result = arcade_command('SELECT 1');
    if (!isset($result['result'])) throw new RuntimeException('Missing database response');
    echo json_encode(['ok' => true, 'service' => 'graph-answer', 'status' => 'online', 'message' => 'Graph answers are available']);
} catch (Throwable $e) {
    http_response_code(503);
    echo json_encode(['ok' => false, 'service' => 'graph-answer', 'status' => 'offline', 'message' => 'Graph database is unavailable']);
}
