<?php
error_reporting(E_ALL & ~E_DEPRECATED & ~E_NOTICE & ~E_WARNING);
ini_set('display_errors', '0');
set_time_limit(120);
require_once __DIR__ . '/cors.php';
require_once __DIR__ . '/core/ChatbotOrchestrator.php';
require_once __DIR__ . '/core/ResponseGenerator.php';
require_once __DIR__ . '/core/FAQMatcher.php';
require_once __DIR__ . '/core/ChatResponseTransport.php';

header('Content-Type: application/json');

if (function_exists('api_handle_cors_preflight')) {
    api_handle_cors_preflight();
}

$method = isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : '';

if ($method !== 'POST') {
    echo json_encode(['status' => 'error', 'message' => 'Use POST']);
    exit;
}

$input = json_decode(file_get_contents('php://input'), true);
$stream = filter_var($input['stream'] ?? false, FILTER_VALIDATE_BOOLEAN);
$question = isset($input['question']) ? trim($input['question']) : '';

if ($question === '') {
    echo json_encode(['status' => 'error', 'message' => 'Question is required']);
    exit;
}

$history = [];
if (isset($input['history']) && is_array($input['history'])) {
    foreach ($input['history'] as $turn) {
        if (!is_array($turn)) continue;
        $role = (($turn['role'] ?? '') === 'user') ? 'user' : 'bot';
        $text = isset($turn['text']) && is_string($turn['text'])
            ? mb_substr(trim($turn['text']), 0, 500) : '';
        if ($text !== '') $history[] = ['role' => $role, 'text' => $text];
        if (count($history) >= 6) break;
    }
}

try {
    $faqMatch = FAQMatcher::match($question);
    if ($faqMatch !== null) {
        ChatResponseTransport::respond([
            'question' => $question,
            'answer' => $faqMatch,
            'status' => 'success',
            'context' => ['type' => 'faq_static_response']
        ], $stream);
        exit;
    }

    if ($stream) {
        ChatResponseTransport::headers();

        $orchestratorResponse = ChatbotOrchestrator::process($question, $history);
        
        ChatResponseTransport::event('context', $orchestratorResponse);

        $generationResult = ResponseGenerator::generateStream($question, $orchestratorResponse, $history, function($token) {
            echo "data: " . json_encode(['chunk' => $token], JSON_UNESCAPED_UNICODE) . "\n\n";
            flush();
        });

        // The authoritative final status
        $finalStatus = $generationResult['status'];
        ChatResponseTransport::event('done', $generationResult);
        exit;
    }

    // Traditional JSON path
    $orchestratorResponse = ChatbotOrchestrator::process($question, $history);
    $generationResult = ResponseGenerator::generate($question, $orchestratorResponse, $history);
    
    // Preserve the orchestrator status if it's an error, otherwise use generation status
    $finalStatus = $generationResult['status'];
    
    echo json_encode(array_merge($generationResult, [
        'question' => $question,
        'answer' => $generationResult['answer'],
        'status' => $finalStatus,
        'context' => $orchestratorResponse
    ]), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE);

} catch (Throwable $e) {
    ChatResponseTransport::respond([
        'status' => 'error',
        'answer' => 'Chatbot response generation failed.'
    ], $stream);
}



