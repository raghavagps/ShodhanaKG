<?php

require_once __DIR__ . '/config.php';

function arcade_command($command, $language = 'sql', $params = array()) {
  global $ARCADE_URL, $ARCADE_DB, $ARCADE_USER, $ARCADE_PASS, $last_arcade_command;
  $last_arcade_command = $command;

  $url = rtrim($ARCADE_URL, '/') . '/api/v1/command/' . rawurlencode($ARCADE_DB);
  $body = array('language' => $language, 'command' => $command);
  if (!empty($params)) $body['params'] = $params;
  $payload = json_encode($body);

    // Try cURL if available
  if (function_exists('curl_init')) {
    static $ch = null;
    if ($ch === null) {
      $ch = curl_init();
    }
    curl_setopt($ch, CURLOPT_URL, $url);
    curl_setopt_array($ch, array(
      CURLOPT_RETURNTRANSFER => true,
      CURLOPT_POST => true,
      CURLOPT_HTTPHEADER => array(
        'Content-Type: application/json; charset=utf-8',
        'Connection: keep-alive'
      ),
      CURLOPT_POSTFIELDS => $payload,
      CURLOPT_USERPWD => $ARCADE_USER . ':' . $ARCADE_PASS,
      CURLOPT_CONNECTTIMEOUT => 5,
      CURLOPT_TIMEOUT => 30,
      CURLOPT_FORBID_REUSE => false,
      CURLOPT_FRESH_CONNECT => false
    ));
    $raw = curl_exec($ch);
    $httpCode = (int) curl_getinfo($ch, CURLINFO_HTTP_CODE);
    // Do NOT close the handle
    if ($raw !== false) {
      return handle_arcade_response($raw, $httpCode);
    }
  }

  // Fallback to file_get_contents if cURL fails or is missing
  $auth = base64_encode($ARCADE_USER . ':' . $ARCADE_PASS);
  $options = array(
    'http' => array(
      'method'  => 'POST',
      'header'  => array(
        'Content-Type: application/json; charset=utf-8',
        "Authorization: Basic $auth"
      ),
      'content' => $payload,
      'timeout' => 30,
      'ignore_errors' => true
    )
  );

  $context = stream_context_create($options);
  $raw = @file_get_contents($url, false, $context);
  
  if ($raw !== false) {
    $httpCode = 0;
    if (@$http_response_header && preg_match('{HTTP\/\S+\s+(\d+)}', @$http_response_header[0], $matches)) {
      $httpCode = (int) $matches[1];
    }
    if ($httpCode !== 0) {
      return handle_arcade_response($raw, $httpCode);
    }
  }

  // Fallback to raw sockets
  if (function_exists('fsockopen')) {
    return arcade_command_socket($url, $payload, $ARCADE_USER, $ARCADE_PASS);
  }

  $err = error_get_last();
  $msg = isset($err['message']) ? $err['message'] : 'unknown';
  throw new Exception('All ArcadeDB connection methods failed (cURL missing, url_fopen disabled, and sockets failed). Last error: ' . $msg);
}

function arcade_command_socket($url, $payload, $user, $pass) {
  $parts = parse_url($url);
  $host = isset($parts['host']) ? $parts['host'] : '127.0.0.1';
  $port = isset($parts['port']) ? $parts['port'] : 80;
  $path = (isset($parts['path']) ? $parts['path'] : '/') . (isset($parts['query']) ? '?' . $parts['query'] : '');
  
  $auth = base64_encode("$user:$pass");
  $timeout = 30;
  
  $fp = @fsockopen($host, $port, $errno, $errstr, $timeout);
  if (!$fp) {
    throw new Exception("ArcadeDB connection failed: $errstr ($errno)");
  }
  
  $out = "POST $path HTTP/1.1\r\n";
  $out .= "Host: $host\r\n";
  $out .= "Authorization: Basic $auth\r\n";
  $out .= "Content-Type: application/json; charset=utf-8\r\n";
  $out .= "Content-Length: " . strlen($payload) . "\r\n";
  $out .= "Connection: Close\r\n\r\n";
  $out .= $payload;
  
  fwrite($fp, $out);
  
  $response = '';
  while (!feof($fp)) {
    $response .= fgets($fp, 128);
  }
  fclose($fp);
  
  $resParts = explode("\r\n\r\n", $response, 2);
  $headerLines = explode("\r\n", $resParts[0]);
  $body = isset($resParts[1]) ? $resParts[1] : '';
  
  $isChunked = false;
  foreach ($headerLines as $line) {
    if (stripos($line, 'Transfer-Encoding: chunked') !== false) {
      $isChunked = true;
      break;
    }
  }

  if ($isChunked) {
    $dechunked = '';
    $offset = 0;
    while ($offset < strlen($body)) {
      $next = strpos($body, "\r\n", $offset);
      if ($next === false) break;
      $size = hexdec(substr($body, $offset, $next - $offset));
      if ($size == 0) break;
      $dechunked .= substr($body, $next + 2, $size);
      $offset = $next + 2 + $size + 2;
    }
    $body = $dechunked;
  }

  $httpCode = 0;
  if (preg_match('{HTTP\/\S+\s+(\d+)}', $headerLines[0], $matches)) {
    $httpCode = (int) $matches[1];
  }
  
  return handle_arcade_response($body, $httpCode);
}

function handle_arcade_response($raw, $httpCode) {
  $json = json_decode((string)$raw, true);
  if (!is_array($json)) {
    throw new Exception('ArcadeDB returned non-JSON');
  }
  if ($httpCode < 200 || $httpCode >= 300) {
    global $last_arcade_command;
    throw new Exception('ArcadeDB error: ' . (isset($json['error']) ? $json['error'] : 'unknown') . ' (' . $httpCode . ') [Query: ' . $last_arcade_command . ']');
  }
  return $json;
}

