<?php
require_once __DIR__ . '/cors.php';
require_once __DIR__ . '/core/EntityResolver.php';
require_once __DIR__ . '/core/EvidenceCorrelator.php';
require_once __DIR__ . '/core/GraphRetriever.php';
require_once __DIR__ . '/core/KnowledgeNormalizer.php';

function execute_integrated_disease_compound($disease, $debugMode = false) {
    if ($disease === '') { return ['status' => 'error', 'message' => 'Missing parameter']; }

    $debug = [
        'entity_resolution' => [],
        'sql_queries' => [],
        'raw_records' => 0,
        'duplicates_filtered' => 0,
        'final_count' => 0
    ];

    try {
        $entityNode = EntityResolver::resolve('Disease', $disease, $debug);
        $entity = ['name' => isset($entityNode['name']) ? $entityNode['name'] : $disease, 'type' => 'Disease'];
        if (!$entityNode) { return ['status' => 'entity_not_found', 'message' => 'Entity not found', 'entity' => $entity]; }
        
        $entity['_evidence'] = new LegacyEvidence($entityNode);
        
        $diseaseRid = $entityNode['rid'];

        // Layer 1: Disease <-[USED_FOR_TREATMENT|TREATS]- Purified_Compound
        $sqlTreats1 = "SELECT @rid as edge_rid, @out as purified_rid, pubmedId, doi, ref, ayush_id, Ayush_ID, ayushId FROM `USED_FOR_TREATMENT` WHERE @in = :disease_rid";
        $sqlTreats2 = "SELECT @rid as edge_rid, @out as purified_rid, pubmedId, doi, ref, ayush_id, Ayush_ID, ayushId FROM `TREATS` WHERE @in = :disease_rid";
        $treatsEdges = array_merge(
            GraphRetriever::execute($sqlTreats1, ['disease_rid' => $diseaseRid], $debug),
            GraphRetriever::execute($sqlTreats2, ['disease_rid' => $diseaseRid], $debug)
        );

        if (empty($treatsEdges)) return KnowledgeNormalizer::formatCanonical($entity, [], [], $debugMode ? $debug : null);
        
        $purifiedRids = array_unique(array_column($treatsEdges, 'purified_rid'));
        $purifiedNameMap = GraphRetriever::fetchNodeNames($purifiedRids, $debug, 'Purified_Compound');

        $uniqueResults = [];
        $rawCount = 0;
        
        // Layer 2: Purified_Compound <-[PRODUCES]- Shodhana_Method
        foreach ($treatsEdges as $tEdge) {
            $purifiedRid = $tEdge['purified_rid'];
            $purifiedName = isset($purifiedNameMap[$purifiedRid]) ? $purifiedNameMap[$purifiedRid] : 'Unknown Purified Compound';
            $tProps = EvidenceCorrelator::extractIdentifiers($tEdge);
            
            $sqlProduces = "SELECT @rid as edge_rid, @out as shodhana_rid, pubmedId, doi, ref, ayush_id, Ayush_ID, ayushId FROM `PRODUCES` WHERE @in = :purified_rid";
            $producesEdges = GraphRetriever::execute($sqlProduces, ['purified_rid' => $purifiedRid], $debug);
            
            if (empty($producesEdges)) {
                $rawCount++;
                $dedupKey = KnowledgeNormalizer::generateDeduplicationKey(null, null, $tProps);
                if (!isset($uniqueResults[$dedupKey])) {
                    $uniqueResults[$dedupKey] = [
                        'compound' => null,
                        'shodhana_method' => null,
                        'purified_compound' => $purifiedName,
                        'properties' => $tProps
                    ];
                }
$entity['_evidence']->record($uniqueResults[$dedupKey], [$tEdge]);
            } else {
                foreach ($producesEdges as $pEdge) {
                    $pProps = EvidenceCorrelator::extractIdentifiers($pEdge);
                    
                    // DEDUPLICATION / GRAPH SEMANTIC FIX
                    if (!EvidenceCorrelator::correlate($tProps, $pProps)) {
                        continue; // Prevent cross-join contamination
                    }
                    
                    $shodhanaRid = $pEdge['shodhana_rid'];
                    
                    // Layer 3: Shodhana_Method <-[UNDERGOES]- Compound
                    $sqlUndergoes = "SELECT @rid as edge_rid, @out as compound_rid, pubmedId, doi, ref, ayush_id, Ayush_ID, ayushId, procedure FROM `UNDERGOES` WHERE @in = :shodhana_rid";
                    $undergoesEdges = GraphRetriever::execute($sqlUndergoes, ['shodhana_rid' => $shodhanaRid], $debug);
                    
                    if (empty($undergoesEdges)) {
                        $rawCount++;
                        // PRODUCES may originate from a Process or Shodhana_Method.
                        $shodhanaNameMap = GraphRetriever::fetchNodeNames([$shodhanaRid], $debug);
                        $shodhanaName = isset($shodhanaNameMap[$shodhanaRid]) ? $shodhanaNameMap[$shodhanaRid] : null;
                        
                        $dedupKey = KnowledgeNormalizer::generateDeduplicationKey(null, $shodhanaName, $pProps);
                        if (!isset($uniqueResults[$dedupKey])) {
                            $uniqueResults[$dedupKey] = [
                                'compound' => null,
                                'shodhana_method' => $shodhanaName,
                                'purified_compound' => $purifiedName,
                                'properties' => $pProps
                            ];
                        }
$entity['_evidence']->record($uniqueResults[$dedupKey], [$tEdge, $pEdge]);
                    } else {
                        foreach ($undergoesEdges as $uEdge) {
                            $uProps = EvidenceCorrelator::extractIdentifiers($uEdge);
                            
                            if (!EvidenceCorrelator::correlate($pProps, $uProps)) {
                                continue; 
                            }
                            
                            $rawCount++;
                            
                            $shodhanaNameMap = GraphRetriever::fetchNodeNames([$shodhanaRid], $debug);
                            $shodhanaName = isset($shodhanaNameMap[$shodhanaRid]) ? $shodhanaNameMap[$shodhanaRid] : null;
                            
                            $compoundRid = $uEdge['compound_rid'];
                            $compoundNameMap = GraphRetriever::fetchNodeNames([$compoundRid], $debug, 'Compound');
                            $compoundName = isset($compoundNameMap[$compoundRid]) ? $compoundNameMap[$compoundRid] : null;
                            
                            $finalProps = $uProps;
                            if (isset($uEdge['procedure'])) {
                                $finalProps['procedure'] = $uEdge['procedure'];
                            }
                            
                            $dedupKey = KnowledgeNormalizer::generateDeduplicationKey($compoundName, $shodhanaName, $finalProps);
                            
                            if (!isset($uniqueResults[$dedupKey])) {
                                $uniqueResults[$dedupKey] = [
                                    'compound' => $compoundName,
                                    'shodhana_method' => $shodhanaName,
                                    'purified_compound' => $purifiedName,
                                    'properties' => $finalProps
                                ];
                            }
$entity['_evidence']->record($uniqueResults[$dedupKey], [$tEdge, $pEdge, $uEdge]);
                        }
                    }
                }
            }
        }
        
        $debug['raw_records'] = $rawCount;
        $debug['duplicates_filtered'] = $rawCount - count($uniqueResults);
        $debug['final_count'] = count($uniqueResults);
        
        $path = ['Disease', '<- USED_FOR_TREATMENT/TREATS', 'Purified_Compound', '<- PRODUCES', 'Shodhana_Method', '<- UNDERGOES', 'Compound'];
        return KnowledgeNormalizer::formatCanonical($entity, $path, $uniqueResults, $debugMode ? $debug : null);

    } catch (Exception $e) {
        return ['status' => 'error', 'message' => $e->getMessage(), 'debug' => $debug];
    }
}

if (basename(__FILE__) === basename($_SERVER['SCRIPT_FILENAME'])) {
    header('Content-Type: application/json');
    $disease = isset($_GET['disease']) ? trim($_GET['disease']) : '';
    $debugMode = isset($_GET['debug']) && $_GET['debug'] == '1';
    if ($disease === '') { echo json_encode(['status' => 'error', 'message' => 'Missing parameter']); exit; }
    echo json_encode(execute_integrated_disease_compound($disease, $debugMode), JSON_PRETTY_PRINT | JSON_UNESCAPED_SLASHES);
}
