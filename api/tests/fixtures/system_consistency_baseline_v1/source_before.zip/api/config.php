<?php

// Central configuration for the PHP API.
// Use environment variables in deployment; defaults are for local testing.

$ARCADE_URL = getenv('ARCADE_URL') ?: 'http://localhost:2480';
$ARCADE_DB = getenv('ARCADE_DB') ?: 'IntegratedKG';
$ARCADE_USER = getenv('ARCADE_USER') ?: 'readonly';
$ARCADE_PASS = getenv('ARCADE_PASS') ?: 'readonly';

$OLLAMA_URL = getenv('OLLAMA_URL') ?: 'http://127.0.0.1:11434';
$OLLAMA_MODEL = getenv('OLLAMA_MODEL') ?: 'llama3.2';

// Comma-separated list, or '*' to allow all origins (local dev).
$ALLOWED_ORIGINS = getenv('ALLOWED_ORIGINS') ?: '*';

// Storage directories for optional caching/rate limiting (create on the server).
$API_STORAGE_DIR = getenv('API_STORAGE_DIR') ?: (__DIR__ . '/storage');
$API_CACHE_DIR = getenv('API_CACHE_DIR') ?: ($API_STORAGE_DIR . '/cache');
$API_RATE_DIR = getenv('API_RATE_DIR') ?: ($API_STORAGE_DIR . '/rate-limit');

// API version string for client display/debug.
$API_VERSION = getenv('API_VERSION') ?: 'v1';
