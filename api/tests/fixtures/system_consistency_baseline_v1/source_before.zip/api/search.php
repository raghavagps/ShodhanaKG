<?php

require_once __DIR__ . '/cors.php';
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/response.php';
require_once __DIR__ . '/graph_service.php';

api_handle_cors_preflight();

$method = isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : '';
if ($method !== 'GET') {
  api_fail('method_not_allowed', 'Use GET', 405);
}

$domain = isset($_GET['domain']) ? trim($_GET['domain']) : '';
$q = isset($_GET['q']) ? trim($_GET['q']) : '';
$limit = max(isset($_GET['limit']) ? (int)$_GET['limit'] : 100, 1);
$typeFilter = isset($_GET['type']) ? trim($_GET['type']) : '';

if (!in_array($domain, array('disease', 'compound', 'integrated'), true)) {
  api_fail('invalid_domain', 'Domain must be disease, compound, or integrated', 400);
}
if ($q === '') {
  api_fail('empty_query', 'Search query is required', 400);
}

try {
  $escaped = arcade_escape($q);
  $nodes = array();
  $limitPerType = $limit * 2;

  $allowedTypes = vertex_types_for_domain($domain);
  if ($typeFilter !== '') {
    $mappedType = db_type_for_frontend_type($typeFilter);
    if (!in_array($mappedType, $allowedTypes, true)) {
      api_ok(array('nodes' => array()));
    }
    $typesToSearch = array($mappedType);
  } else {
    $typesToSearch = $allowedTypes;
  }

  $debug = array();
  foreach ($typesToSearch as $type) {
    $labelFields = search_fields_for_type($type);

    $orConds = array();
    $lowerQ = strtolower($escaped);
    foreach ($labelFields as $f) {
      $col = (strpos($f, ' ') !== false || strpos($f, '.') !== false) ? "`$f`" : $f;
      $orConds[] = sprintf("coalesce(%s, '').toLowerCase() LIKE '%%%s%%'", $col, $lowerQ);
    }
    $where = implode(' OR ', $orConds);

    if ($domain === 'integrated' && $type === 'Purified_Compound') {
      $where = sprintf("(%s) AND out('USED_FOR_TREATMENT').size() > 0", $where);
    }

    $sql = sprintf(
      "SELECT FROM `%s` WHERE %s LIMIT %d",
      $type,
      $where,
      $limitPerType
    );

    $debug[$type] = array('sql' => $sql, 'error' => null, 'count' => 0);

    try {
      $res = arcade_command($sql, 'sql');
      $results = isset($res['result']) ? $res['result'] : array();
      $debug[$type]['count'] = count($results);
      foreach ($results as $rec) {
        $nodes[] = build_node($rec);
        if (count($nodes) >= $limit) break 2;
      }
    } catch (Exception $e) {
      $debug[$type]['error'] = $e->getMessage();
      continue;
    }
  }

  api_ok(array('nodes' => $nodes, 'debug' => $debug));
} catch (Exception $e) {
  api_fail('search_failed', 'Search query failed', 500, array(
    'message' => $e->getMessage(),
  ));
}
