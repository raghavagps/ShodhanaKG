<?php

require_once __DIR__ . '/cors.php';
require_once __DIR__ . '/config.php';
require_once __DIR__ . '/response.php';
require_once __DIR__ . '/graph_service.php';

api_handle_cors_preflight();

$method = isset($_SERVER['REQUEST_METHOD']) ? $_SERVER['REQUEST_METHOD'] : '';
if ($method !== 'GET') {
  api_fail('method_not_allowed', 'Use GET', 405);
}

$domain     = isset($_GET['domain']) ? trim($_GET['domain']) : '';
$seedsRaw   = isset($_GET['seeds']) ? trim($_GET['seeds']) : '';
$limitNodes = min(max(isset($_GET['limitNodes']) ? (int)$_GET['limitNodes'] : 120, 1), 500);
$limitEdges = min(max(isset($_GET['limitEdges']) ? (int)$_GET['limitEdges'] : 300, 1), 2000);

$integratedMode = isset($_GET['integratedMode']) ? trim($_GET['integratedMode']) : '1hop';
$depth = min(max(isset($_GET['depth']) ? (int)$_GET['depth'] : 1, 0), 2);

if (!in_array($domain, array('disease', 'compound', 'integrated'), true)) {
  api_fail('invalid_domain', 'Domain must be disease, compound, or integrated', 400);
}
if ($seedsRaw === '') {
  api_fail('no_seeds', 'At least one seed ID is required', 400);
}

$seedIds = array_filter(array_map('trim', explode(',', $seedsRaw)));

function get_bridge_edges() {
  return array('USED_FOR_TREATMENT', 'USED_IN_FORMULATION');
}
function get_compound_edges() {
  return array(
    'UNDERGOES', 'CONTAINS', 'VALIDATED_BY', 'USES_MEDIA', 'CONFIRMS_SAFETY_OF',
    'DERIEVED_FROM', 'DETOXIFIES', 'CLASSIFIED_AS', 'PRODUCES', 'FOLLOWED_BY',
  );
}
function get_disease_edges() {
  return array(
    'ASSESS', 'HAS_AYURVEDIC_DIAGNOSIS', 'HAS_DOSHA_IMBALANCE', 'HAS_SYMPTOM',
    'POST_TREATED_BY', 'PRE_TREATED_BY', 'RESOLVED_BY', 'TREATED_BY', 'USES',
  );
}
function get_compound_db_types() {
  return array(
    'Compound', 'Shodhana_Method', 'Toxic_Substance', 'Confirmation_Study',
    'Media', 'Purified_Compound', 'Shodhana_Type', 'Process',
    'Indication', 'Ayurvedic_Formulation',
  );
}
function get_disease_db_types() {
  return array(
    'Disease', 'Dosha', 'Ayurvedic_Diagnosis', 'Symptoms',
    'Therapy', 'Formulation', 'Assessment_Parameter',
  );
}

function query_edges($frontierRids, $edgeTypes, $limit) {
  if (empty($frontierRids) || empty($edgeTypes)) return array();
  $ridCsv  = implode(',', $frontierRids);
  $results = array();
  foreach ($edgeTypes as $et) {
    $sql = sprintf(
      "SELECT FROM `%s` WHERE @out IN [%s] OR @in IN [%s] LIMIT %d",
      $et, $ridCsv, $ridCsv, $limit
    );
    try {
      $res     = arcade_command($sql, 'sql');
      $resResults = isset($res['result']) ? $res['result'] : array();
      $results = array_merge($results, $resResults);
    } catch (Exception $e) { /* skip */ }
  }
  return $results;
}

function integrate_edges($rawEdges, &$nodeMap, &$edgeMap, $limitNodes, $limitEdges, &$rawTypeMap) {
  $newRids = array();
  foreach ($rawEdges as $e) {
    foreach (array('@out', '@in') as $side) {
      $r = isset($e[$side]) ? $e[$side] : '';
      if ($r && !isset($nodeMap[$r])) {
        $newRids[$r] = true;
      }
    }
  }
  if (empty($newRids)) {
    _flush_edges($rawEdges, $nodeMap, $edgeMap, $limitEdges);
    return array(array(), array());
  }

  $nRidCsv = implode(',', array_keys($newRids));
  $sql = sprintf('SELECT FROM %s LIMIT 2000', $nRidCsv);
  try {
    $res = arcade_command($sql, 'sql');
  } catch (Exception $e) {
    _flush_edges($rawEdges, $nodeMap, $edgeMap, $limitEdges);
    return array(array(), array());
  }

  $newCompound = array();
  $newDisease  = array();
  $results = isset($res['result']) ? $res['result'] : array();
  foreach ($results as $rec) {
    if (count($nodeMap) >= $limitNodes) break;
    $rid = isset($rec['@rid']) ? $rec['@rid'] : '';
    if (!$rid) continue;
    $rawType = isset($rec['@type']) ? $rec['@type'] : '';
    $rawTypeMap[$rid] = $rawType;
    $nodeMap[$rid]    = build_node($rec);

    $compTypes = get_compound_db_types();
    if (in_array($rawType, $compTypes, true)) {
      $newCompound[] = $rid;
    } else {
      $newDisease[] = $rid;
    }
  }

  _flush_edges($rawEdges, $nodeMap, $edgeMap, $limitEdges);
  return array($newCompound, $newDisease);
}

function _flush_edges($rawEdges, &$nodeMap, &$edgeMap, $limitEdges) {
  foreach ($rawEdges as $e) {
    if (count($edgeMap) >= $limitEdges) break;
    $edge = build_edge($e, $nodeMap);
    if ($edge !== null) {
      $edgeMap[$edge['id']] = $edge;
    }
  }
}

try {
  $startTime = microtime(true);

  $seedVertices = resolve_seeds($seedIds, $domain);
  if (empty($seedVertices)) {
    api_fail('seeds_not_found', 'No seed vertices could be resolved', 404);
  }

  $nodeMap    = array();
  $edgeMap    = array();
  $truncated  = false;
  $truncReason = null;

  if ($domain === 'integrated') {
    $rawTypeMap     = array();
    $compoundFront  = array();
    $diseaseFront   = array();

    foreach ($seedVertices as $v) {
      $rid = isset($v['@rid']) ? $v['@rid'] : '';
      if (!$rid) continue;
      $rawType = isset($v['@type']) ? $v['@type'] : '';
      $rawTypeMap[$rid] = $rawType;
      $nodeMap[$rid]    = build_node($v);
      $compTypes = get_compound_db_types();
      if (in_array($rawType, $compTypes, true)) {
        $compoundFront[] = $rid;
      } else {
        $diseaseFront[] = $rid;
      }
    }

    $bridgeRaw = query_edges(array_merge($compoundFront, $diseaseFront), get_bridge_edges(), $limitEdges);
    $res = integrate_edges($bridgeRaw, $nodeMap, $edgeMap, $limitNodes, $limitEdges, $rawTypeMap);
    $nc = $res[0]; $nd = $res[1];
    $compoundFront = array_unique(array_merge($compoundFront, $nc));
    $diseaseFront  = array_unique(array_merge($diseaseFront, $nd));

    if ($integratedMode !== 'bridge') {
      $hops = 1;
      for ($h = 0; $h < $hops; $h++) {
        if (count($nodeMap) >= $limitNodes) { $truncated = true; $truncReason = 'node_cap'; break; }

        $newCompFront = array();
        if (!empty($compoundFront)) {
          $edges = query_edges($compoundFront, get_compound_edges(), $limitEdges);
          $res2 = integrate_edges($edges, $nodeMap, $edgeMap, $limitNodes, $limitEdges, $rawTypeMap);
          $newCompFront = $res2[0];
        }

        $newDisFront = array();
        if (!empty($diseaseFront)) {
          $edges = query_edges($diseaseFront, get_disease_edges(), $limitEdges);
          $res3 = integrate_edges($edges, $nodeMap, $edgeMap, $limitNodes, $limitEdges, $rawTypeMap);
          $newDisFront = $res3[1];
        }

        $compoundFront = array_unique($newCompFront);
        $diseaseFront  = array_unique($newDisFront);

        if (empty($compoundFront) && empty($diseaseFront)) break;
        if (count($edgeMap) >= $limitEdges) { $truncated = true; $truncReason = 'edge_cap'; break; }
      }
    }

  } else {
    $edgeTypes = edge_types_for_domain($domain);
    $frontier  = array();

    foreach ($seedVertices as $v) {
      $rid = isset($v['@rid']) ? $v['@rid'] : '';
      if ($rid && !isset($nodeMap[$rid])) {
        $nodeMap[$rid] = build_node($v);
        $frontier[]    = $rid;
      }
    }

    for ($d = 0; $d < $depth; $d++) {
      if (empty($frontier)) break;

      $allEdges = query_edges($frontier, $edgeTypes, $limitEdges);

      $neighborRids = array();
      foreach ($allEdges as $e) {
        foreach (array('@out', '@in') as $side) {
          $r = isset($e[$side]) ? $e[$side] : '';
          if ($r && !isset($nodeMap[$r])) $neighborRids[$r] = true;
        }
      }
      if (empty($neighborRids)) break;

      $neighborMap = fetch_vertex_map(implode(',', array_keys($neighborRids)));
      $newFrontier = array();
      foreach ($neighborMap as $rid => $node) {
        if (count($nodeMap) >= $limitNodes) { $truncated = true; $truncReason = 'node_cap'; break; }
        $nodeMap[$rid] = $node;
        $newFrontier[] = $rid;
      }

      foreach ($allEdges as $e) {
        if (count($edgeMap) >= $limitEdges) { $truncated = true; $truncReason = 'edge_cap'; break; }
        $edge = build_edge($e, $nodeMap);
        if ($edge !== null) $edgeMap[$edge['id']] = $edge;
      }

      if ($truncated) break;
      if (count($nodeMap) >= $limitNodes) { $truncated = true; $truncReason = 'node_cap'; break; }
      if (count($edgeMap) >= $limitEdges) { $truncated = true; $truncReason = 'edge_cap'; break; }

      $frontier = $newFrontier;
    }
  }

  $elapsed  = (int) ((microtime(true) - $startTime) * 1000);
  $nodesOut = array_slice(array_values($nodeMap), 0, $limitNodes);
  $edgesOut = array_slice(array_values($edgeMap), 0, $limitEdges);
  if (count($nodesOut) < count($nodeMap) || count($edgesOut) < count($edgeMap)) {
    $truncated = true;
    $truncReason = $truncReason !== null ? $truncReason : (count($nodesOut) < count($nodeMap) ? 'node_cap' : 'edge_cap');
  }

  api_ok(array(
    'nodes' => $nodesOut,
    'edges' => $edgesOut,
    'meta'  => array(
      'depth'         => $domain === 'integrated' ? $integratedMode : $depth,
      'truncated'     => $truncated,
      'truncatedReason' => $truncReason,
      'totalNodes'    => count($nodesOut),
      'totalEdges'    => count($edgesOut),
      'queryMs'       => $elapsed,
    ),
  ));
} catch (Exception $e) {
  api_fail('graph_failed', 'Graph query failed', 500, array(
    'message' => $e->getMessage(),
  ));
}
