<?php
require_once __DIR__ . '/EntityResolution.php';
require_once __DIR__ . '/QueryUnderstanding.php';

/** Node fields only: never traverses an edge or invokes a language model. */
final class NodePropertyAnswer {
    public static function subjectQuestion(string $question): string {
        // Keep field names out of entity matching (e.g. Weight is itself a KG node).
        if (preg_match('/^(?:(?:please|and)\s+)?(?:what (?:is|are)|show(?: me)?|give(?: me)?)\s+(?:its|their)\s+.+[?.!]*$/i', trim($question))) return 'it';
        if (QueryUnderstanding::target($question) && !preg_match('/\b(?:property|attribute|field|description|definition|information|details)\b/i', $question)) return $question;
        if (preg_match('/^(?:(?:please|and)\s+)?(?:what (?:is|are)|show(?: me)?|give(?: me)?|tell me)\s+(?:the\s+)?(.+?)\s+(?:of|for|about|on)\s+(.+?)[?.!]*$/i', trim($question), $m)) return $m[2];
        if (preg_match('/^(?:(?:please|and)\s+)?(?:describe|define|explain|tell me (?:more )?about|what do you know about)\s+(.+?)[?.!]*$/i', trim($question), $m)) return $m[1];
        return $question;
    }
    public static function requested(string $question, array $node): ?string {
        $q = EntityResolution::normalize($question);
        $mention = EntityResolution::normalize($node['_resolution_mention'] ?? $node['name']);
        $q = preg_replace('/(?<![\p{L}\p{N}])' . preg_quote($mention, '/') . '(?![\p{L}\p{N}])/u', 'NODE', $q);
        $type = EntityResolution::normalize($node['inferred_type']);
        $q = str_replace($type . ' NODE', 'NODE', $q);
        if ($node['inferred_type'] === 'Shodhana_Method') $q = str_replace('method NODE', 'NODE', $q);
        $q = preg_replace('/\b(it|its|this|that)\b/', 'NODE', $q);
        $q = preg_replace('/^(and |please |can you |could you )+/', '', $q);
        if (preg_match('/^(?:what is|define|describe|explain|tell me (?:more )?about|what do you know about|(?:show|give)(?: me)? (?:information|details) (?:about|on)) NODE$/', $q)) return 'description';
        if (preg_match('/^(?:what (?:is|are)|show(?: me)?|give(?: me)?|tell me) (?:the )?(.+?) (?:of|for|about|on) NODE$/', $q, $m)
            || preg_match('/^(?:what (?:is|are)|show(?: me)?|give(?: me)?|tell me) NODE s? ?(.+)$/', $q, $m)) {
            $property = trim($m[1]);
            $explicit = preg_match('/^(?:stored |node )?(?:property|attribute|field) /', $property);
            $property = preg_replace('/^(?:stored |node )?(?:property|attribute|field) /', '', $property);
            if ($explicit) return $property;
            foreach (array_keys($node) as $field) if ($field !== '' && $field[0] !== '@' && $field[0] !== '_' && EntityResolution::normalize($field) === $property) return $property;
            if (in_array($property, ['description','definition','information','details'], true)) return 'description';
            if (in_array($property, ['properties','stored properties','node properties','attributes'], true)) return '*';
            // Ordinary relationship questions retain their existing retrieval path.
            if (!$explicit && (QueryUnderstanding::target($question) || preg_match('/\b(?:symptoms?|therapies|therapy|treatments?|formulations?|methods?|media|medium|diseases?|indications?|compounds?|process(?:es)?|therapeutic uses?|purification|detoxification|validation|toxicity)\b/i', $property))) return null;
            return $property;
        }
        if (preg_match('/^(?:description|definition|information|details) (?:of|for|about|on) NODE$/', $q)) return 'description';
        return null;
    }

    public static function build(array $raw, string $property): array {
        $fields = [];
        foreach ($raw as $key => $value) {
            if ($key === '' || $key[0] === '@' || $key[0] === '_' || preg_match('/^(?:in|out)(?:_|$)/i', $key)) continue;
            if ($value === null || (is_string($value) && trim($value) === '') || $value === []) continue;
            $normalized = EntityResolution::normalize($key);
            $description = preg_match('/(?:^|[_. ])description(?:[. ]\d+)?$/i', $key);
            if ($property === '*' || ($property === 'description' && $description) || $normalized === EntityResolution::normalize($property)) $fields[$key] = $value;
        }
        $label = vertex_label($raw);
        $answer = $fields ? $label . " - stored node " . ($property === '*' ? 'properties' : $property) . ":\n\n" : 'No information is available for ' . $property . ' on the ' . $label . ' node. You can ask about its associated relationships.';
        foreach ($fields as $key => $value) $answer .= $key . ': ' . (is_string($value) ? $value : json_encode($value, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES)) . "\n";
        return ['status' => $fields ? 'success' : 'no_data', 'answer' => trim($answer),
            'node_evidence' => ['source' => 'stored_node_properties', 'node_id' => $raw['@rid'], 'node_type' => $raw['@type'], 'requested_property' => $property, 'properties' => $fields],
            'citations' => [], 'evidence_records' => []];
    }
}
