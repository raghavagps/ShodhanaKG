<?php
require_once __DIR__ . '/ConversationalAnswer.php';
require_once __DIR__ . '/ResultsPresentation.php';

class ResponseGenerator {
    public static function generateStream(string $question, array $orchestratorResponse, array $history, callable $onToken): array {
        $result = self::generate($question, $orchestratorResponse, $history);
        // Build and validate everything before emitting any answer text.
        foreach (explode("\n", $result['answer']) as $i => $line) {
            $onToken(($i ? "\n" : '') . $line);
        }
        return $result;
    }

    public static function generate(string $question, array $orchestratorResponse, array $history = []): array {
        if (is_array($orchestratorResponse['routing'] ?? null) && ($orchestratorResponse['routing']['endpoint'] ?? '') === 'node_property' && isset($orchestratorResponse['node_answer'])) return $orchestratorResponse['node_answer'];
        $status = $orchestratorResponse['status'] ?? 'error';
        
        // Deterministic gates (LLM bypassed)
        if ($status === 'needs_clarification') {
            return [
                'status' => 'needs_clarification',
                'answer' => $orchestratorResponse['message'] ?? 'Could you please clarify your question?'
            ];
        }
        if ($status === 'unsupported') {
            return [
                'status' => 'unsupported',
                'answer' => $orchestratorResponse['message'] ?? 'That question is outside the currently supported ShodhanaKG knowledge retrieval patterns.'
            ];
        }
        if ($status === 'entity_not_found') {
            return [
                'status' => 'entity_not_found',
                'answer' => $orchestratorResponse['message'] ?? 'The requested compound or disease could not be found in ShodhanaKG.'
            ];
        }
        if ($status === 'no_data') {
            return [
                'status' => 'no_data',
                'answer' => 'I couldn’t find information about that in the available records.'
            ];
        }
        
        if ($status === 'success') return ResultsPresentation::build($orchestratorResponse['retrieval'] ?? []);
        if (($orchestratorResponse['retrieval']['reason'] ?? '') === 'query_limit') return [
            'status' => 'error', 'answer' => 'There are too many matching graph paths to retrieve completely. Please narrow the query with an entity or treatment constraint.'
        ];

        return [
            'status' => 'error',
            'answer' => 'An unknown error occurred during orchestration.'
        ];
    }
    
}
