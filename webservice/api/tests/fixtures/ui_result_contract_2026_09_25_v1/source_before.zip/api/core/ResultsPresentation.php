<?php
require_once __DIR__ . '/ConversationalAnswer.php';

/** Deterministic view model over validated retrieval. Never changes retrieval. */
final class ResultsPresentation {
    private static function typeLabel(string $type): string {
        $label = trim(str_replace('_', ' ', $type));
        $singular = ['Symptoms' => 'Symptom', 'Doshas' => 'Dosha', 'Assessment Parameters' => 'Assessment Parameter'];
        return $singular[$label] ?? $label;
    }

    private static function field(string $type): string {
        return strtolower(preg_replace('/[^a-zA-Z0-9]/', '', self::typeLabel($type)));
    }

    private static function schema(): array {
        static $schema;
        return $schema ?? ($schema = json_decode(file_get_contents(__DIR__ . '/relationship_metadata.json'), true)['edges']);
    }

    private static function entityType(string $key, array $path): ?string {
        if ($key === 'related_entity') return self::typeLabel((string)(end($path) ?: 'Entity'));
        $aliases = ['method' => 'Shodhana Method', 'study' => 'Confirmation Study'];
        if (isset($aliases[$key])) return $aliases[$key];
        foreach (self::schema() as $pairs) foreach ($pairs as $pair) foreach ($pair as $type) {
            if (self::field($key) === self::field($type)) return self::typeLabel($type);
        }
        return null;
    }

    private static function entities(array $row, array $path): array {
        if (isset($row['nodes'])) return array_map(static function ($node) {
            return ['type' => self::typeLabel($node['type']), 'label' => $node['label'], 'id' => $node['id']];
        }, $row['nodes']);
        $entities = [];
        foreach ($row as $key => $value) {
            $type = self::entityType($key, $path);
            if (!$type || !is_string($value) || trim($value) === '') continue;
            $entities[] = ['type' => self::typeLabel($type), 'label' => $value];
        }
        return $entities;
    }

    private static function pathTypes(string $declared): array {
        $types = [];
        foreach (explode('/', $declared) as $part) {
            $type = self::entityType(strtolower(str_replace(' ', '_', $part)), []);
            if ($type) $types[] = self::field($type);
        }
        return array_values(array_unique($types));
    }

    private static function relationships(array $path, array $row): array {
        $schema = self::schema(); $choices = []; $hops = [];
        for ($i = 0; $i < count($path); $i += 2) $choices[$i] = self::pathTypes($path[$i]);
        for ($i = 1; $i + 1 < count($path); $i += 2) {
            $edge = trim($path[$i], '<-> ');
            $edgeTypes = [$edge];
            // Legacy traversal notation declares an optional prefix family.
            // Expand only schema-known members; retain the raw path unchanged.
            if (preg_match('/^\[([A-Z]+(?:\/[A-Z]+)*)\]_(.+)$/', $edge, $match)) {
                $edgeTypes = [$match[2]];
                foreach (explode('/', $match[1]) as $prefix) $edgeTypes[] = $prefix . '_' . $match[2];
            }
            $pairs = [];
            foreach ($edgeTypes as $type) foreach ($schema[$type] ?? [] as $pair) $pairs[json_encode($pair)] = $pair;
            $hops[$i] = array_values($pairs);
        }
        // Resolve union node types using the entire connected schema path. For
        // example, UNDERGOES constrains Method/Process to Shodhana Method before
        // resolving USES_MEDIA. Do not guess when multiple directed pairs remain.
        for ($pass = 0; $pass < count($choices); $pass++) {
            $before = $choices;
            foreach ($hops as $i => $pairs) {
                $valid = []; $left = []; $right = [];
                foreach ($pairs as $pair) {
                    $source = self::field($pair['source']); $target = self::field($pair['target']);
                    foreach ([[$source, $target], [$target, $source]] as [$a, $b]) {
                        if (in_array($a, $choices[$i - 1], true) && in_array($b, $choices[$i + 1], true)) {
                            $valid[json_encode($pair)] = $pair; $left[$a] = true; $right[$b] = true;
                        }
                    }
                }
                $hops[$i] = array_values($valid);
                if ($valid) { $choices[$i - 1] = array_keys($left); $choices[$i + 1] = array_keys($right); }
            }
            if ($choices === $before) break;
        }
        $relationships = [];
        foreach ($hops as $pairs) if (count($pairs) === 1) {
            // Always label stored schema direction, including inverse traversal.
            $relationships[] = self::typeLabel($pairs[0]['source']) . ' → ' . self::typeLabel($pairs[0]['target']);
        }
        return $relationships;
    }

    public static function build(array $retrieval): array {
        // Includes connectivity, direction, seed identity and raw-reference checks.
        $validated = EvidenceAnswerBuilder::build($retrieval);
        if ($validated['status'] !== 'success') return $validated;
        $citations = ConversationalAnswer::packet($retrieval);
        $results = []; $types = []; $groups = [];
        $path = $retrieval['path'] ?? [];
        $attributed = array_column($retrieval['evidence_paths'] ?? [], 'paths', 'result_index');
        foreach ($retrieval['results'] as $i => $row) {
            $entities = self::entities($row, $path);
            $target = null;
            if (isset($row['nodes'])) $target = end($entities);
            else {
                $wanted = self::field((string)(end($path) ?: ''));
                foreach ($entities as $entity) if (self::field($entity['type']) === $wanted) $target = $entity;
                if (!$target && count($entities) === 1) $target = $entities[0];
            }
            $label = $target['label'] ?? implode(' · ', array_column($entities, 'label'));
            if ($label === '') return ['status' => 'error', 'answer' => 'The retrieved results could not be displayed consistently.'];
            if ($target) $types[$target['type']] = true;
            // Group entity identity, never evidence. Every supporting fact remains
            // in its own citation, even when the visible entity is listed once.
            $key = json_encode([$target['id'] ?? null, $target['type'] ?? null, $label]);
            if (!isset($groups[$key])) {
                $groups[$key] = count($results);
                $results[] = ['id' => 'f' . ($i + 1), 'label' => $label, 'fact_ids' => [], 'citation_ids' => [], 'record_indices' => []];
            }
            $group = $groups[$key];
            $results[$group]['fact_ids'][] = 'f' . ($i + 1);
            $results[$group]['citation_ids'][] = (string)($i + 1);
            $results[$group]['record_indices'][] = $i;
            $citations[$i]['entities'] = $entities;
            if (isset($row['evidence_groups'])) $citations[$i]['evidence_groups'] = $row['evidence_groups'];
            if (isset($row['edges'])) {
                $nodes = array_column($row['nodes'], null, 'id');
                foreach ($row['edges'] as $j => $edge) {
                    $source = $nodes[$edge['source']]; $targetNode = $nodes[$edge['target']];
                    $citations[$i]['scopes'][$j]['relationship'] = self::typeLabel($source['type']) . ' → ' . self::typeLabel($targetNode['type']);
                    $citations[$i]['scopes'][$j]['edge_id'] = $edge['id'] ?? null;
                    $citations[$i]['scopes'][$j]['edge_type'] = $edge['type'];
                    $citations[$i]['scopes'][$j] += EdgePresentation::metadata($edge);
                    $citations[$i]['scopes'][$j]['source_id'] = $edge['source'];
                    $citations[$i]['scopes'][$j]['target_id'] = $edge['target'];
                    $citations[$i]['scopes'][$j]['entities'] = [
                        ['type' => self::typeLabel($source['type']), 'label' => $source['label']],
                        ['type' => self::typeLabel($targetNode['type']), 'label' => $targetNode['label']]];
                }
            } elseif (isset($attributed[$i])) {
                $scopes = []; $relations = [];
                foreach ($attributed[$i] as $support) {
                    $nodes = array_column($support['nodes'], null, 'id');
                    foreach ($support['edges'] as $edge) {
                        $source = $nodes[$edge['source']]; $targetNode = $nodes[$edge['target']];
                        $relation = self::typeLabel($source['type']) . ' → ' . self::typeLabel($targetNode['type']);
                        $relations[$relation] = true;
                        $scopes[$edge['id']] = ['description' => $source['label'] . ' → ' . $targetNode['label'],
                            'relationship' => $relation, 'edge_id' => $edge['id'], 'edge_type' => $edge['type'],
                            'source_id' => $edge['source'], 'target_id' => $edge['target'],
                            'identifiers' => $edge['evidence'], 'properties' => $edge['properties'],
                            'display_properties' => EdgePresentation::properties($edge['properties']), 'treatment_phase' => EdgePresentation::phase($edge['type']),
                            'entities' => [['type' => self::typeLabel($source['type']), 'label' => $source['label']],
                                ['type' => self::typeLabel($targetNode['type']), 'label' => $targetNode['label']]]];
                    }
                }
                $citations[$i]['scopes'] = array_values($scopes);
                $citations[$i]['relationships'] = array_keys($relations);
                $citations[$i]['attribution'] = 'per_edge';
            } else {
                // Keep every supplied flat property, including future keys.
                // These are record scopes: no unavailable edge identity is invented.
                $scopes = []; $properties = [];
                foreach ($row as $key => $value) {
                    if (self::entityType($key, $path) || $key === 'relationship') continue;
                    if (is_array($value)) $scopes[] = ['description' => ucwords(str_replace('_', ' ', $key)),
                        'identifiers' => EvidenceCorrelator::extractIdentifiers($value), 'properties' => $value];
                    else $properties[$key] = $value;
                }
                if ($properties || !$scopes) $scopes[] = ['description' => 'Recorded association',
                    'identifiers' => EvidenceCorrelator::extractIdentifiers($properties), 'properties' => $properties];
                $citations[$i]['scopes'] = $scopes;
                $relations = self::relationships($path, $row);
                $citations[$i]['relationships'] = $relations;
                foreach ($citations[$i]['scopes'] as &$scope) {
                    // A flat row cannot attribute a property to an individual hop.
                    // Keep it scoped to the original record, not a fabricated edge.
                    $scope['entities'] = $entities;
                    if (count($path) === 3 && count($relations) === 1) $scope['relationship'] = $relations[0];
                }
                unset($scope);
            }
        }
        $seed = $retrieval['entity']['name'];
        $kind = count($types) === 1 ? array_keys($types)[0] : 'Result';
        $plurals = ['Symptom' => 'Symptoms', 'Therapy' => 'Therapies', 'Disease' => 'Diseases', 'Process' => 'Processes', 'Media' => 'Media'];
        $plural = $plurals[$kind] ?? $kind . 's';
        $heading = $plural . ' associated with ' . $seed;
        $intro = 'The available records associate ' . $seed . ' with the following ' . strtolower($plural) . ':';
        $constraints = $retrieval['query_plan']['constraints'] ?? [];
        if ($constraints) $intro .= ' Filtered to ' . implode(', ', array_map(static function ($c) { return $c['name'] . ' (' . str_replace('_', ' ', $c['type']) . ')'; }, $constraints)) . '.';
        if (array_filter($citations, static function($c) { return count($c['evidence_groups'] ?? []) > 1; })) $intro .= ' Different studies may support different steps; each citation identifies its own edge.';
        $lines = [];
        foreach ($results as $i => $result) $lines[] = ($i + 1) . '. ' . $result['label'] . ' [' . implode(', ', $result['citation_ids']) . ']';
        return ['status' => 'success', 'answer' => $heading . "\n\n" . $intro . "\n\n" . implode("\n", $lines),
            'pagination' => $retrieval['pagination'] ?? null, 'query_plan' => $retrieval['query_plan'] ?? null,
            'answer_heading' => $heading, 'answer_intro' => $intro, 'answer_results' => $results,
            'answer_blocks' => [], 'citations' => $citations,
            'generation' => ['mode' => 'deterministic', 'fallback_reason' => null, 'latency_ms' => 0]];
    }
}
