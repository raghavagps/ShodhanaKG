<?php

class FAQMatcher {
    
    private static $faqs = [
        [
            'pattern' => '/what is shadhanakg|what is shodhanakg/i',
            'answer' => 'ShodhanaKG is a comprehensive Knowledge Graph Explorer that visualizes Ayurvedic purification processes. It allows you to explore the relationships between raw poisonous compounds, their purification (Shodhana) methods, and the resulting therapeutic uses and formulations.'
        ],
        [
            'pattern' => '/difference between (a )?compound and (a )?formulation/i',
            'answer' => 'In ShodhanaKG, a **Compound** refers to a raw material (like Copper or Datura) that often undergoes purification. A **Formulation** refers to a finished, prepared medicine that may contain one or more purified compounds and is used to treat specific diseases.'
        ],
        [
            'pattern' => '/how to navigate|how to use( the)? website|how to use( the)? explorer/i',
            'answer' => "You can navigate ShodhanaKG using three main explorers:\n1. **Compound Explorer:** Search for a specific compound (e.g., Copper or Datura) to view its purification processes and toxicity.\n2. **Disease Explorer:** Search for a disease to see associated symptoms, formulations, and therapies.\n3. **Integrated Explorer:** View the full end-to-end path from a raw compound, through its purification, to its final therapeutic use for a specific disease."
        ],
        [
            'pattern' => '/how to export|how to save|export( the)? graph/i',
            'answer' => 'In any of the Explorers, you can click the **Export** button in the top right corner of the Graph View. You can export the current view as a PNG image, a JSON file containing the raw nodes and edges, or a CSV file for spreadsheet analysis.'
        ],
        [
            'pattern' => '/what (kinds of )?questions can( this)? chatbot answer/i',
            'answer' => 'I can answer specific questions about Ayurvedic compounds, their purification (Shodhana) media and processes, diseases, symptoms, and therapies based on the data in ShodhanaKG. You can ask things like "What media is used for Copper?" or "What are the symptoms of Alopecia?". Note that I cannot answer general knowledge questions outside of this domain.'
        ]
    ];

    public static function match(string $question): ?string {
        foreach (self::$faqs as $faq) {
            if (preg_match($faq['pattern'], $question)) {
                return $faq['answer'];
            }
        }
        return null;
    }
}
