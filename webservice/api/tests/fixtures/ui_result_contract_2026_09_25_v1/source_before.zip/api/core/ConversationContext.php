<?php
require_once __DIR__ . '/ConversationEntities.php';
require_once __DIR__ . '/NodePropertyAnswer.php';

/** Conversational hints only. Every selected subject is resolved against the KG again. */
final class ConversationContext {
    public static function validate($state): array {
        if (!is_array($state) || !in_array($state['version'] ?? null, [1, 2], true)) return ['version' => 2, '_provided' => true, '_invalid' => true];
        $clean = ['version' => 2, '_provided' => true]; $subject = $state['subject'] ?? [];
        if (is_array($subject) && in_array($subject['type'] ?? '', ConversationEntities::TYPES, true) && is_string($subject['name'] ?? null) && is_string($subject['id'] ?? null)) {
            $node = EntityResolver::resolve($subject['type'], $subject['id'] ?? '');
            if ($node && $node['@type'] === $subject['type'] && vertex_label($node) === $subject['name']) $clean['subject'] = ['id' => $node['rid'], 'name' => vertex_label($node), 'type' => $node['@type']];
        }
        if ($subject && empty($clean['subject'])) $clean['_invalid'] = true;
        foreach (['last_question', 'pending_question'] as $key) if (isset($state[$key]) && is_string($state[$key])) $clean[$key] = mb_substr($state[$key], 0, 500);
        $clean['constraints'] = [];
        foreach (array_slice(is_array($state['constraints'] ?? null) ? $state['constraints'] : [], 0, 3) as $constraint) {
            if (!is_array($constraint)) continue;
            if (in_array($constraint['type'] ?? '', ConversationEntities::TYPES, true) && is_string($constraint['name'] ?? null)) {
                $node = EntityResolver::resolve($constraint['type'], $constraint['id'] ?? $constraint['name']);
                if ($node && $node['@type'] === $constraint['type'] && vertex_label($node) === $constraint['name']) $clean['constraints'][] = ['id' => $node['rid'], 'name' => vertex_label($node), 'type' => $node['@type']];
                else $clean['_invalid'] = true;
            }
        }
        if (!is_array($state['constraints'] ?? []) || count($clean['constraints']) !== count($state['constraints'] ?? [])) $clean['_invalid'] = true;
        if (in_array($state['result_type'] ?? '', ConversationEntities::TYPES, true)) $clean['result_type'] = $state['result_type'];
        foreach (['intent', 'property'] as $key) if (is_string($state[$key] ?? null)) $clean[$key] = mb_substr($state[$key], 0, 100);
        if (is_array($state['pending_clarification'] ?? null)) {
            $pending = $state['pending_clarification'];
            if (in_array($pending['result_type'] ?? '', ConversationEntities::TYPES, true)) $clean['pending_clarification']['result_type'] = $pending['result_type'];
            if (is_string($pending['property'] ?? null)) $clean['pending_clarification']['property'] = mb_substr($pending['property'], 0, 100);
        }
        return $clean;
    }
    public static function prepare(string $question, array $history, $state): array {
        $state = self::validate($state);
        $matcher = new ConversationEntities(); $found = $matcher->find(NodePropertyAnswer::subjectQuestion($question));
        $followup = preg_match('/^(and\b|what about\b)|\b(it|its|this|that|they|them|these|those)\b/i', $question);
        // Context is passed as typed routing input, never as synthetic chat messages.
        $history = [];
        $clearPattern = '/\b(?:without|ignore|clear|remove)\s+(?:the\s+)?(?:previous\s+)?(?:constraints?|filters?)\b/i';
        if (preg_match($clearPattern, $question)) {
            $state['constraints'] = [];
            $question = trim(preg_replace($clearPattern, '', $question));
            if (trim($question, " \t\n\r?.!") === '') {
                $target = $state['pending_clarification']['result_type'] ?? ($state['result_type'] ?? null);
                $question = $target ? 'What about its ' . str_replace('_', ' ', $target) . '?' : 'What about it?';
            }
            unset($state['pending_question'], $state['pending_clarification']);
        }
        if (isset($state['pending_question']) && $found['groups'] && !SemanticQuery::target($question)) {
            // Resolve an entity-only clarification against the previous requested intent.
            $pendingTarget = SemanticQuery::target($state['pending_question']);
            if ($pendingTarget && count($found['groups']) === 1) {
                $selected = ConversationEntities::select($found['groups'][0], $question);
                if ($selected) $question = 'Which ' . str_replace('_', ' ', $pendingTarget) . ' is associated with ' . str_replace('_', ' ', $selected['inferred_type']) . ' ' . $selected['name'] . '?';
            }
        }
        return [$question, array_slice($history, -20), $state, $found];
    }
    public static function finish(array $response, string $question, array $previous): array {
        $state = ['version' => 2]; $r = is_array($response['routing'] ?? null) ? $response['routing'] : [];
        if (is_array($r) && isset($r['entity_type'], $r['entity']) && in_array($r['entity_type'], ConversationEntities::TYPES, true)) {
            $node = EntityResolver::resolve($r['entity_type'], $r['entity_id'] ?? $r['entity']);
            if ($node) {
                $state['subject'] = ['id' => $node['rid'], 'name' => vertex_label($node), 'type' => $node['@type']];
                // A self-contained routing question is stored, not answer prose.
                $label = vertex_label($node);
                $state['last_question'] = $question . (stripos($question, $label) === false ? ' for ' . $label : '');
                $state['constraints'] = $r['constraints'] ?? [];
                $state['result_type'] = $r['result_type'] ?? ($response['retrieval']['query_plan']['result_type'] ?? SemanticQuery::target($question));
                $path = $response['retrieval']['path'] ?? [];
                if (!$state['result_type'] && $path && in_array(end($path), ConversationEntities::TYPES, true)) $state['result_type'] = end($path);
                $state['intent'] = $r['intent'] ?? null;
                if (isset($r['property'])) $state['property'] = $r['property'];
                $state['constraints'] = self::validate($state)['constraints'] ?? [];
                $state['resolved_entities'] = array_merge([$state['subject']], $state['constraints']);
            }
        } elseif (($response['status'] ?? '') === 'needs_clarification') {
            $state = $previous; $state['pending_question'] = $question;
            $state['pending_clarification'] = ['result_type' => SemanticQuery::target($question) ?? ($previous['result_type'] ?? null), 'property' => $r['property'] ?? null];
        } elseif (in_array($response['status'] ?? '', ['unsupported', 'no_data'], true)) {
            $state = $previous;
        }
        unset($state['_provided'], $state['_invalid']);
        $state['version'] = 2;
        return $state;
    }
}
