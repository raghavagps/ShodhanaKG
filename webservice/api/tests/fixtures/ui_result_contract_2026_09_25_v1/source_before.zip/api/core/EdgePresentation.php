<?php
/** Display metadata derived from a stored edge, never inferred from its nodes. */
final class EdgePresentation {
    public static function phase(string $type): ?string {
        return ['PRE_TREATED_BY' => 'pre-treated', 'TREATED_BY' => 'treated', 'POST_TREATED_BY' => 'post-treated'][$type] ?? null;
    }
    public static function meaningful($value): bool {
        if ($value === null) return false;
        if (is_string($value)) return !in_array(strtolower(trim($value)), ['', 'null', 'not supplied'], true);
        if (is_array($value)) return count(array_filter($value, [self::class, 'meaningful'])) > 0;
        return true;
    }
    public static function properties(array $raw): array {
        $result = [];
        foreach ($raw as $key => $value) {
            if (strpos($key, '@') === 0 || preg_match('/^(ref|references|reference|pubmed[_ ]?id|doi|ayush[_ ]?id|unclassified_reference|phase)$/i', $key)) continue;
            if (self::meaningful($value)) $result[] = ['key' => $key, 'label' => ucfirst(str_replace('_', ' ', $key)), 'value' => $value];
        }
        return $result;
    }
    public static function metadata(array $edge): array {
        return ['display_properties' => self::properties($edge['properties']), 'treatment_phase' => self::phase($edge['type'])];
    }
}
