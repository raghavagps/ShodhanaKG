import { EdgeProperties } from "@/components/explorer/EdgeProperties";
import { ReferenceLinks } from "@/components/explorer/ReferenceLinks";
import { useEffect, useRef, useState } from 'react';
import { AnswerCitation } from '@/lib/types';

const isRecord = (value: unknown): value is Record<string, unknown> =>
  value !== null && typeof value === 'object' && !Array.isArray(value);
const label = (value: string) => value.replace(/_/g, ' ');
const meaningful = (value: unknown): boolean => {
  if (value == null) return false;
  if (typeof value === 'string') return value.trim() !== '' && !/^(null|not supplied)$/i.test(value.trim());
  if (Array.isArray(value)) return value.some(meaningful);
  if (isRecord(value)) return Object.values(value).some(meaningful);
  return true;
};

/** Preserve nested evidence scopes rather than flattening references across records. */
function Fields({ value }: { value: unknown }) {
  if (!meaningful(value)) return null;
  if (Array.isArray(value)) return <ol className="space-y-1 pl-3 list-decimal">{value.filter(meaningful).map((item, i) => <li key={i}><Fields value={item} /></li>)}</ol>;
  if (isRecord(value)) return (
    <dl className="space-y-1">
      {Object.entries(value).filter(([, item]) => meaningful(item)).map(([key, item]) => (
        <div key={key} className="border-l border-border pl-2">
          <dt className="text-muted-foreground">{label(key)}</dt>
          <dd className="break-words whitespace-pre-wrap"><Fields value={item} /></dd>
        </div>
      ))}
    </dl>
  );
  return <>{String(value)}</>;
}

function EvidenceRecord({ record }: { record: Record<string, unknown> }) {
  const nodes = Array.isArray(record.nodes) ? record.nodes.filter(isRecord) : [];
  const edges = Array.isArray(record.edges) ? record.edges.filter(isRecord) : [];
  if (!nodes.length || !edges.length) return <Fields value={record} />;
  const nodeName = (id: unknown) => {
    const node = nodes.find(node => node.id === id);
    return node ? `${String(node.label)} (${label(String(node.type))})` : 'Unknown node';
  };
  return (
    <div className="space-y-3">
      {edges.map((edge, i) => (
        <div key={i} className="rounded border border-border p-2 space-y-2">
          <p className="font-medium break-words">{nodeName(edge.source)} → {label(String(edge.type)).toLowerCase()} → {nodeName(edge.target)}</p>
          <div><p className="font-medium">Edge evidence</p><Fields value={edge.evidence} /></div>
          <div><p className="font-medium">Recorded properties</p><Fields value={edge.properties} /></div>
        </div>
      ))}
      {record.matched_evidence !== undefined && <div><p className="font-medium">Shared reference within this path</p><Fields value={record.matched_evidence} /></div>}
      {record.phase !== undefined && <div><p className="font-medium">Treatment phase</p><Fields value={record.phase} /></div>}
      <details><summary className="cursor-pointer text-muted-foreground">Raw evidence record</summary><pre className="whitespace-pre-wrap break-all mt-1">{JSON.stringify(record, null, 2)}</pre></details>
    </div>
  );
}

function DescriptiveEvidence({ citation, record }: { citation: AnswerCitation; record: Record<string, unknown> }) {
  const hasOutcome = citation.scopes.some(scope => Object.entries(scope.properties).some(([key, value]) => /^(result|outcome|outcome measure|outputmeasure)$/i.test(key) && value != null && value !== ''));
  const referenceKeys = /^(references|ref|pubmedid|pubmed_id|pubmed id|doi|ayush_id|ayushid|unclassified_reference)$/i;
  const propertyValue = (key: string, value: unknown) => key.toLowerCase() === 'phase'
    ? ({ TREATED_BY: 'treatment', PRE_TREATED_BY: 'pretreatment', POST_TREATED_BY: 'post-treatment' }[String(value)] ?? value)
    : value;
  return <div className="space-y-3">
    <div><h5 className="font-medium">What this reference supports</h5><p>{citation.statement}</p></div>
    {citation.scopes.map((scope, i) => <div key={i} className="space-y-1 border-l border-border pl-2">
      <p className="font-medium">{scope.description}</p>
      {Object.entries(scope.properties).filter(([key, value]) => !referenceKeys.test(key) && value != null && value !== '').map(([key, value]) => <div key={key}><span className="text-muted-foreground">Recorded {label(key).toLowerCase()}: </span><Fields value={propertyValue(key, value)} /></div>)}
      <div className="flex flex-wrap gap-2">
        <ReferenceLinks references={scope.identifiers.references} raw={scope.identifiers.unclassified_reference || scope.identifiers.pubmed_id || scope.identifiers.doi || scope.identifiers.ayush_id} />
        {!['pubmed_id', 'doi', 'ayush_id', 'unclassified_reference'].some(key => scope.identifiers[key]) && <span className="text-muted-foreground">No publication reference supplied for this part.</span>}
      </div>
    </div>)}
    {!hasOutcome && <p className="text-muted-foreground">This record describes the association but does not include a study outcome.</p>}
    {citation.attribution === 'record' && <p className="text-muted-foreground">References are attached to this recorded association; separate support for each step is not available.</p>}
    <details><summary className="cursor-pointer text-muted-foreground">Technical details</summary><Fields value={record} /></details>
  </div>;
}

function CompactEvidence({ citation, record }: { citation: AnswerCitation; record: Record<string, unknown> }) {
  const referenceKey = /^(references|ref|pubmedid|pubmed_id|pubmed id|doi|ayush_id|ayushid|unclassified_reference)$/i;
  const phase = (value: unknown) => ({ TREATED_BY: 'Treatment', PRE_TREATED_BY: 'Pretreatment', POST_TREATED_BY: 'Post-treatment' }[String(value)] ?? value);
  return <div className="space-y-2">
    {citation.evidence_groups && citation.evidence_groups.length > 1 && <p className="text-muted-foreground">Different studies support different steps. Each reference below applies only to its own relationship.</p>}
    {citation.scopes.map((scope, i) => <div key={scope.edge_id ?? i} className={i ? 'border-t border-border/40 pt-2 space-y-1' : 'space-y-1'}>
      <div className="flex flex-wrap gap-x-2 gap-y-1 font-medium">
        <span>[{citation.id}]</span>
        <ReferenceLinks references={scope.identifiers.references} raw={scope.identifiers.unclassified_reference || scope.identifiers.pubmed_id || scope.identifiers.doi || scope.identifiers.ayush_id} />
      </div>
      {(scope.entities ?? citation.entities ?? []).map((entity, j) => <p key={j}><span className="font-medium">{entity.type}:</span> {entity.label}</p>)}
      {scope.relationship && <p><span className="font-medium">Relationship:</span> {scope.relationship}</p>}
      {!scope.relationship && citation.relationships?.length > 0 && <p><span className="font-medium">Relationships:</span> {citation.relationships.join('; ')}</p>}
      {citation.attribution === 'record' && citation.scopes.length > 1 && meaningful(scope.description) && <p className="font-medium">{scope.description}</p>}
      {scope.display_properties ? <EdgeProperties properties={scope.display_properties} phase={scope.treatment_phase} /> : Object.entries(scope.properties).filter(([key, value]) => !referenceKey.test(key) && !key.startsWith('@') && meaningful(value)).map(([key, value]) => <div key={key}>
        <span className="font-medium">{key.toLowerCase() === 'phase' ? 'Treatment phase' : label(key)}: </span>
        <Fields value={key.toLowerCase() === 'phase' ? phase(value) : value} />
      </div>)}
    </div>)}
    <details><summary className="cursor-pointer text-muted-foreground">Technical details</summary><pre className="whitespace-pre-wrap break-all mt-1">{JSON.stringify({ record, fact_ids: citation.fact_ids, record_indices: citation.record_indices, attribution: citation.attribution, scopes: citation.scopes }, null, 2)}</pre></details>
  </div>;
}

export function EvidenceRecords({ records, citations, focusedRecord, focusRequest }: { records: Record<string, unknown>[]; citations?: AnswerCitation[]; focusedRecord?: number; focusRequest?: number }) {
  const [start, setStart] = useState(0);
  const section = useRef<HTMLElement>(null);
  useEffect(() => {
    if (focusedRecord !== undefined && focusedRecord >= 0 && focusedRecord < records.length) setStart(focusedRecord);
  }, [focusedRecord, focusRequest, records.length]);
  useEffect(() => {
    if (focusedRecord === undefined || start !== focusedRecord) return;
    const card = section.current?.querySelector<HTMLElement>(`[data-record-index="${focusedRecord}"]`);
    card?.focus();
    card?.scrollIntoView?.({ block: 'nearest' });
  }, [start, focusedRecord, focusRequest]);
  const count = records.length;
  const first = Math.min(start, Math.max(0, count - 1));
  const end = Math.min(first + 10, count);
  if (!count) return null;
  return (
    <section ref={section} aria-label="Retrieved evidence" className="min-w-0 space-y-3">
      <label className="flex flex-wrap gap-2 items-center">
        {citations?.length ? 'Jump to source' : 'Start at record'}
        <input aria-label="Start at evidence record" type="number" min={1} max={count} value={first + 1}
          className="w-20 rounded border border-border bg-background px-2 py-1"
          onChange={event => {
            const value = Number(event.target.value);
            if (Number.isInteger(value) && value >= 1 && value <= count) setStart(value - 1);
          }} />
      </label>
      <p aria-live="polite">Showing {citations?.length ? 'sources' : 'records'} {first + 1}–{end} of {count}</p>
      {records.slice(first, end).map((record, i) => {
        const citation = citations?.find(c => c.record_indices.includes(first + i));
        return (
        <article key={first + i} data-record-index={first + i} tabIndex={-1} aria-label={`Evidence record ${first + i + 1}`} className="border-l-2 border-primary/40 pl-2 py-1 min-w-0">
          {!citations?.length && <h4 className="font-medium mb-2">Evidence record {first + i + 1}</h4>}
          {citation ? (
            citation.relationships !== undefined || citation.scopes.some(scope => scope.relationship)
              ? <CompactEvidence citation={citation} record={record} />
              : <DescriptiveEvidence citation={citation} record={record} />
          ) : <EvidenceRecord record={record} />}
        </article>
      ); })}
      <div className="flex gap-3">
        <button type="button" disabled={first === 0} onClick={() => setStart(Math.max(0, first - 10))} className="underline disabled:opacity-40">Previous {citations?.length ? 'sources' : 'records'}</button>
        <button type="button" disabled={end === count} onClick={() => setStart(end)} className="underline disabled:opacity-40">Next {citations?.length ? 'sources' : 'records'}</button>
      </div>
    </section>
  );
}
