import schema from '@/data/schemaReference.json';
import { I_NODE_COLORS } from '@/data/integratedGraph';
import { entityType } from '@/lib/entityNavigation';

const label = (value: string) => value.replace(/_/g, ' ');
export function SchemaVertexRows({ print = false }: { print?: boolean }) {
  return <>{schema.vertices.map(type => <tr key={type}>
    <td className={print ? 'p-2 font-bold border-r border-gray-300' : 'p-3 font-semibold text-foreground'}>{label(type)}</td>
    <td className={print ? 'p-2 border-r border-gray-300' : 'p-3'}><span className="inline-block h-2.5 w-2.5 rounded-full" style={{ background: I_NODE_COLORS[entityType(type)] }} aria-label={`${label(type)} node color`} /></td>
    <td className={print ? 'p-2 text-gray-700' : 'p-3 text-muted-foreground'}>KG entity category: {label(type)}.</td>
  </tr>)}</>;
}
export function SchemaEdgeRows({ print = false }: { print?: boolean }) {
  return <>{schema.edges.map(edge => <tr key={edge.type}>
    <td className={print ? 'p-2 font-bold border-r border-gray-300' : 'p-3 font-semibold text-foreground'}>{edge.type}</td>
    <td className={print ? 'p-2 border-r border-gray-300' : 'p-3'}>{edge.pairs.map(pair => <div key={`${pair.source}:${pair.target}`}>{label(pair.source)} → {label(pair.target)}</div>)}</td>
    <td className={print ? 'p-2 text-gray-700' : 'p-3 text-muted-foreground'}>{edge.pairs.length ? 'Stored directed relationship; properties and references belong to each individual edge.' : 'Declared relationship; no stored edges observed in the current KG.'}</td>
  </tr>)}</>;
}
