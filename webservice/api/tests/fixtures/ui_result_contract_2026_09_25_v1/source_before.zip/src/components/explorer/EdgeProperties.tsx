import type { DisplayProperty } from '@/lib/types';

export function EdgeProperties({ properties, phase }: { properties?: DisplayProperty[]; phase?: string | null }) {
  const rows = [...(phase ? [{ key: '__phase', label: 'Treatment phase', value: phase }] : []), ...(properties ?? [])];
  return <dl className="divide-y divide-border/60 rounded-lg border border-border/70 bg-secondary/20 text-sm overflow-hidden">
    {rows.map((item, index) => <div key={`${item.key}:${index}`} className="px-3 py-2.5 space-y-1">
      <dt className="text-xs font-semibold text-muted-foreground">{item.label}:</dt>
      <dd className="m-0 text-foreground leading-relaxed whitespace-pre-wrap [overflow-wrap:anywhere]">{typeof item.value === 'object' ? JSON.stringify(item.value, null, 2) : String(item.value)}</dd>
    </div>)}
  </dl>;
}
