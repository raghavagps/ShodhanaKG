import { useState, useRef, useEffect } from "react";
import { MessageCircle, X, Leaf, RefreshCw } from "lucide-react";
import { useLocation } from "react-router-dom";
import { cn } from "@/lib/utils";
import { ChatMessage as ChatMessageType, ChatHistoryTurn } from "@/lib/types";
import { fetchChatStream, checkChatHealth } from "@/lib/chatApi";
import { ChatMessage } from "./ChatMessage";
import { ChatInput } from "./ChatInput";
import { ChatSuggestions } from "./ChatSuggestions";

const WELCOME: ChatMessageType = {
  role: "bot",
  text: "Hello. I'm the ShodhanaKG Assistant. Ask me about diseases, compounds, therapies, or how to navigate the graph.",
};

export const ChatbotWidget = () => {
  const [open, setOpen] = useState(false);
  const [announce, setAnnounce] = useState(false);
  useEffect(() => {
    try {
      if (sessionStorage.getItem('chatbot-launcher-noticed')) return;
      sessionStorage.setItem('chatbot-launcher-noticed', 'true');
      if (!window.matchMedia('(prefers-reduced-motion: reduce)').matches) setAnnounce(true);
    } catch { return; }
    const timer = setTimeout(() => setAnnounce(false), 700);
    return () => clearTimeout(timer);
  }, []);
  const [messages, setMessages] = useState<ChatMessageType[]>([WELCOME]);
  const [isStreaming, setIsStreaming] = useState(false);
  const [chatAvailable, setChatAvailable] = useState<boolean | null>(null);
  
  // Use a ref for conversation ID so it persists across renders without triggering effects
  const conversationIdRef = useRef(crypto.randomUUID());
  const scrollRef = useRef<HTMLDivElement>(null);
  const location = useLocation();

  // Check health on mount
  useEffect(() => {
    checkChatHealth().then(isAvailable => setChatAvailable(isAvailable));
  }, []);

  // Session persistence
  useEffect(() => {
    const saved = sessionStorage.getItem('chatbot-messages');
    if (saved) {
      try {
        setMessages(JSON.parse(saved));
      } catch (e) {
        // ignore
      }
    }
  }, []);

  useEffect(() => {
    if (messages.length > 1) { // Don't just save the welcome message
      sessionStorage.setItem('chatbot-messages', JSON.stringify(messages));
    }
  }, [messages]);

  // Auto-scroll
  useEffect(() => {
    scrollRef.current?.scrollTo({ top: scrollRef.current.scrollHeight, behavior: "smooth" });
  }, [messages, open]);

  const send = async (text: string, pageOffset = 0, pageContext?: ChatMessageType['conversation_context'], selectedEntity?: import('@/lib/types').EntityCandidate) => {
    if (isStreaming) return;
    if (chatAvailable === false) {
       setMessages(m => [
           ...m, 
           { role: "user", text }, 
           { role: "bot", text: "I'm sorry, the AI assistant is currently offline. Please try again later.", status: "network_error" }
       ]);
       return;
    }

    setMessages((m) => [
      ...m,
      { role: "user", text },
      { role: "bot", text: "", isStreaming: true }
    ]);
    setIsStreaming(true);

    try {
      const history: ChatHistoryTurn[] = messages
        .filter(m => m.role === "user" || (m.role === "bot" && ['success', 'needs_clarification'].includes(m.status)))
        .slice(-20)
        .map(m => ({ role: m.role as "user" | "bot", text: m.text }));

      let currentAnswer = "";
      
      const response = await fetchChatStream(
        text, 
        history,
        conversationIdRef.current,
        (chunk) => {
          currentAnswer += chunk;
          setMessages((prev) => {
            const updated = [...prev];
            const last = updated[updated.length - 1];
            if (last && last.role === 'bot') {
              last.text = currentAnswer;
            }
            return updated;
          });
        },
        (context) => {
          setMessages((prev) => {
            const updated = [...prev];
            const last = updated[updated.length - 1];
            if (last && last.role === 'bot') {
              last.context = context;
            }
            return updated;
          });
        },
        pageContext ?? [...messages].reverse().find(m => m.conversation_context)?.conversation_context,
        pageOffset,
        selectedEntity
      );
      
      setMessages((prev) => {
        const updated = [...prev];
        const last = updated[updated.length - 1];
        if (last && last.role === 'bot') {
          last.isStreaming = false;
          last.text = response.answer || last.text;
          last.resolution = response.resolution;
          last.clarification = response.clarification;
          last.answer_intro = response.answer_intro;
          last.answer_heading = response.answer_heading;
          last.answer_results = response.answer_results;
          last.answer_blocks = response.answer_blocks;
          last.citations = response.citations;
          last.conversation_context = response.conversation_context;
          last.pagination = response.pagination;
          if (response.context) last.context = response.context;
          if (response.status !== 'success' && response.status !== 'no_data') {
             // Fallback text if grounding error or similar
             last.text = response.answer || "An error occurred while generating the response.";
          }
          last.status = response.status;
        }
        return updated;
      });
      setIsStreaming(false);
    } catch {
      setMessages((prev) => {
        const updated = [...prev];
        const last = updated[updated.length - 1];
        if (last && last.role === 'bot') {
          last.isStreaming = false;
          last.text = "An unexpected error occurred while communicating with the server.";
          last.status = "network_error";
        }
        return updated;
      });
      setIsStreaming(false);
    }
  };

  const handleClear = () => {
    setMessages([WELCOME]);
    sessionStorage.removeItem('chatbot-messages');
    conversationIdRef.current = crypto.randomUUID();
  };

  return (
    <>
      {/* Floating button */}
      <button
        onClick={() => setOpen((o) => !o)}
        className={cn(
          "fixed bottom-6 right-6 z-50 flex h-14 w-14 items-center justify-center rounded-full",
          "bg-gradient-herbal text-primary-foreground shadow-elevated transition-smooth",
          "hover:scale-105 active:scale-95",
          announce && !open && "chat-launcher-entrance"
        )}
        aria-label={open ? "Close assistant" : "Open assistant"}
      >
        {open ? <X className="h-5 w-5" /> : <MessageCircle className="h-5 w-5" />}
      </button>

      {/* Panel */}
      <div
        className={cn(
          "fixed bottom-24 right-6 z-50 w-[min(400px,calc(100vw-2rem))] origin-bottom-right",
          "rounded-xl border border-border bg-card shadow-elevated transition-smooth flex flex-col",
          open ? "scale-100 opacity-100" : "pointer-events-none scale-95 opacity-0",
          "h-[min(550px,calc(100vh-8rem))]"
        )}
      >
        {/* Header */}
        <div className="flex items-center gap-2.5 border-b border-border/70 px-4 py-3 bg-gradient-warm rounded-t-xl shrink-0">
          <span className="flex h-8 w-8 items-center justify-center rounded-md bg-gradient-herbal">
            <Leaf className="h-4 w-4 text-primary-foreground" />
          </span>
          <div className="leading-tight flex-1">
            <div className="font-display text-sm font-semibold text-bark">ShodhanaKG Assistant</div>
            <div className="text-[10px] text-muted-foreground flex items-center gap-1">
              {chatAvailable === false && <span className="text-destructive font-semibold">(Offline)</span>}
            </div>
          </div>
          <button 
            onClick={handleClear}
            className="p-1.5 text-muted-foreground hover:text-foreground rounded-full hover:bg-black/5 transition-colors"
            title="Start new conversation"
          >
            <RefreshCw className="w-3.5 h-3.5" />
          </button>
        </div>

        {/* Messages area */}
        <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4">
          {messages.map((m, i) => (
            <ChatMessage 
              key={i} 
              message={m} 
              onSelectEntity={candidate => send(candidate.label, 0, m.conversation_context, candidate)}
              onNextPage={m.pagination?.has_more ? () => send(messages[i - 1]?.text ?? '', m.pagination.next_offset, m.conversation_context) : undefined}
              onRetry={m.status === 'network_error' ? () => {
                const userMsg = messages[i - 1]?.text;
                if (userMsg) {
                  setMessages(prev => prev.slice(0, i));
                  send(userMsg);
                }
              } : undefined}
            />
          ))}
          
          {messages.length === 1 && chatAvailable !== false && (
            <ChatSuggestions onSelect={send} />
          )}
        </div>

        {/* Input area */}
        <div className="p-3 border-t border-border/70 bg-card rounded-b-xl shrink-0">
          <ChatInput onSend={send} disabled={isStreaming || chatAvailable === false} />
        </div>
      </div>
    </>
  );
};




